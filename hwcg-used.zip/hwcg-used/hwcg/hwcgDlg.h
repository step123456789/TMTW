
// hwcgDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "perceptionaw.h"
struct PART
{
	int top,left,right,bot;
	char partname[100];
};

// ChwcgDlg �Ի���
class ChwcgDlg : public CDialogEx
{
// ����
public:
	ChwcgDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_HWCG_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CButton m_btn_heng_lr;
	afx_msg void OnBnClickedBtnOk();
//	CString m_editChar;
	POINT old;
	CString m_editString;
	CButton m_btn_henghf_lr;
	CButton m_btn_henghf_rl;
	CButton m_btn_heng_rl;
	CButton m_btn_na_bt;
	CButton m_btn_na_tb;
	CButton m_btn_nahf_bt;
	CButton m_btn_nahf_tb;
	CButton m_btn_pie_bt;
	CButton m_btn_pie_tb;
	CButton m_btn_piehf_bt;
	CButton m_btn_piehf_tb;
	CButton m_btn_shu_bt;
	CButton m_btn_shu_tb;
	CButton m_btn_shuhf_bt;
	CButton m_btn_shuhf_tb;

	CPoint m_partpnt[200];//��ʱ��űʻ���
	int m_cntPartPnt;//��ʱ
	int m_cntPartPnt_Pre;//��ʱ
	int eachsize;
	int rownum;
	int m_slider_con_val;
	int m_slider_var_val;
	int bgimg_idx;
	int styleidx;
	char rootpath[1024];
	CString m_editChar;
	CString m_editPart;
	char m_curhanzi[1024];//char to learn
	char m_curpart[1024];//used part
	char m_curstring[1024];//string to write
	//CString	m_curChar;//char to learn
	//CString	m_partName;
	bool is_start_show;
	unsigned char *showimg;
	//unsigned char *hwcharimg;
	bool m_has_det_part_pos;//It has fixed part position or not
	bool m_has_seld_part;   //It has selected a part or not
	PART m_grp[100];//groups used to counstruct the character
	int m_curGrp_num;// coutn the group number;
	bool m_islbup;//draw parts if this is true
	int left,top,width,height;
	afx_msg void OnBnClickedBtnHenghfLr();
	CPoint down_point;
	
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnBnClickedBtnSelpart();
	afx_msg void OnBnClickedButtonFix();
	afx_msg void OnBnClickedBtnStartlearning();
	afx_msg void OnBnClickedBtnFinishlearning();
	int ReadPartPts(char* m_partName, int m_cntPartPnt_Pre, PART* tgtpart);
	void Scale_Shift_Part(CPoint * m_partpnt, int si, int ei, PART * curgrp);
	
	afx_msg void OnBnClickedBtnWrite();
	afx_msg void OnBnClickedBtnHengLr();
	afx_msg void OnBnClickedBtnHenghfRl();
	afx_msg void OnBnClickedBtnHengRl();
	afx_msg void OnBnClickedBtnShuhfTb();
	afx_msg void OnBnClickedBtnShuTb();
	afx_msg void OnBnClickedBtnShuhfBt();
	afx_msg void OnBnClickedBtnShuBt();
	afx_msg void OnBnClickedBtnPiehfTb();
	afx_msg void OnBnClickedBtnPieTb();
	afx_msg void OnBnClickedBtnPiehfBt();
	afx_msg void OnBnClickedBtnPieBt();
	afx_msg void OnBnClickedBtnNahfTb();
	afx_msg void OnBnClickedBtnNaTb();
	afx_msg void OnBnClickedBtnNahfBt();
	afx_msg void OnBnClickedBtnNaBt();
	afx_msg void OnBnClickedBtnBatchwrite();
	afx_msg void OnBnClickedBtnWritestring();
//	afx_msg void OnEnChangeEditString();
	void AdjustWindowsSize(void);
	void Resize(void);
//	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedBtnWriteEng();
	CSliderCtrl m_sliderCon;
	CSliderCtrl m_sliderVar;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnSetfocusEditChar();
	afx_msg void OnSetfocusEditPart();
	afx_msg void OnSetfocusEditString();
	afx_msg void OnBnClickedBtnOk2();
	afx_msg void OnBnClickedBtnBatchwrite2();
//	afx_msg void OnBnClickedBtnWriteerrorstr();
	afx_msg void OnBnClickedBtnWritechistr();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedBtnBatchwritestr();
};
