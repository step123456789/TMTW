
#include "stdio.h"
#include "math.h"

typedef struct spt
{
	int ptsrow,ptscol,pterow,ptecol;//
}StrokeSyntax;

typedef struct dc
{
	int x[500];//curve��Լ����row
	int y[500];//curve��Լ����col
	int pnum;//curve��Լ������
	int isCon;//�Ƿ������ʣ����������ӵıʻ�
}DrawCurve;

typedef struct constroke
{
	int conInd[500];//������ʵĸ��ʻ�������
	int conNum;//���ٸ��ʻ�����
	int canCut;//���ӳ��ۣ������������ʲ�ͬ
}ConnectStrokeSyntax;


typedef struct grp
{
	char grpname[1024];
	int partition_top,partition_left,partition_wid,partition_hei;
	int top,left,right,bot;
	int top_ssidx,left_ssidx,right_ssidx,bot_ssidx;
	StrokeSyntax *strokes;
	StrokeSyntax *draw_strokes;
	ConnectStrokeSyntax* con_ss;
	DrawCurve *draw_curves;
	int strokenum;
	int curvenum;
	int ptind_left_num,ptind_right_num,ptind_top_num,ptind_bot_num;

	int *ptind_left;
	int *ptind_right;
	int *ptind_top;
	int *ptind_bot;//

	int *ptind_left_grpidx;//
	int *ptind_right_grpidx;//
	int *ptind_top_grpidx;
	int *ptind_bot_grpidx;//

	float *ptind_left_wei_self;//
	float *ptind_right_wei_self;//
	float *ptind_top_wei_self;
	float *ptind_bot_wei_self;//

	float *ptind_left_wei;//
	float *ptind_right_wei;//
	float *ptind_top_wei;
	float *ptind_bot_wei;//

	float *ptind_left_worh;//0 w,1 h
	float *ptind_right_worh;//
	float *ptind_top_worh;
	float *ptind_bot_worh;//

	float *ptind_left_worh_self;//0 w,1 h
	float *ptind_right_worh_self;//
	float *ptind_top_worh_self;
	float *ptind_bot_worh_self;//

	float *ptind_left_dis;//
	float *ptind_right_dis;
	float *ptind_top_dis;
	float *ptind_bot_dis;

}Group;

void swapGrp(Group*allgroup,int allstrokenum);
void drawCurveOnImg_Bezier_eng(Group *grp,int onegroupwid,int onegrouphei,int width,int height);
double get_curlen(int n,int* px,int* py);
float get_minParalStkDis(Group *grp,int min_charwid,int min_charhei);
float getdis_toj(int isr,int isc,int ier,int iec,int jsr,int jsc,int jer,int jec);
void  add_noise(unsigned char *img,int wid,int hei,int cw,int ch);
void get_point_onstroke_around(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,int maxwid);
void con_2stk_pos(Group *grp,int i,int cntdcnum,int cntpnum,int &retcntpnum,int &retcntdcnum);
int LineToCurve3_next(Group *grp,int* isendstroke_ofpart);
void rotatePart_eachchar(Group *curgrp,double rotval,int *eachchar_start,int charnum);
int LineToCurve3_Chi(Group *grp,int* isendstroke_ofpart);
unsigned char *writeString_Chi(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val);
int LineToCurve3_Eng_string(Group *grp,int* isendstroke_ofpart);
bool partitionBigGrp(Group*&allgroup_big,int groupnum1,bool *);
void cuoqie_x(Group*curgrp,float ang);
void cuoqie_y(Group*curgrp,float ang);
int LineToCurve_con2str(Group *grp,int* isendstroke_ofpart);
void copyGrp_withfix(Group *&ori,Group* &tgt);
void get_point_onstroke(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,float val);
void get_randpoint_onstroke(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,int &len);
void rotateEachStroke(Group *grp);
void drawCurveOnImg_Bezier(Group *grp,int onegroupwid,int onegrouphei);
void copyGrp(Group *&ori,Group* &tgt);
 double GuassGenerate(double mu, double theda,double min,double max);
void ucsmooth(unsigned char *src, int width, int height,int smthwid);
void rotate_point(int orix,int oriy,int cx,int cy,int &retx,int &rety,float a);
void zmbyopencv(unsigned char *img, int width, int height,unsigned char *zmimg, int zmwidth, int zmheight);
void maxvalto255(unsigned char *img,int width,int height);
bool intersect3(int aax,int aay,int bbx,int bby,int ccx,int ccy,int ddx,int ddy);
double ang_2line(int sx1,int sy1,int ex1,int ey1,
				 int sx2,int sy2,int ex2,int ey2);
void cal_rel_intersect_twostrokes(Group *groupi,Group *groupk,int k);
void get_point_onstroke(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,float val);
void drawCurveOnImg_Bezier_eng(Group *grp,int onegroupwid,int onegrouphei);
void drawCurveOnImg_Bezier(Group *grp,int onegroupwid,int onegrouphei,int width,int height);
void add_ij_dot(Group*allgrp,int *ijleft,int *ijtop,int *ijwid,int charhei,int ijnum,int *isendstroke_ofpart);
void get_con_stroke_pts(int i_ptsrow,int i_ptscol,int i_pterow,int i_ptecol,
	int i1_ptsrow,int i1_ptscol,int i1_pterow,int i1_ptecol,int &i_crow,int &i_ccol,int &x_crow,int &x_ccol,int &i1_crow,int &i1_ccol);
int normimg_string(unsigned char *ucimg,int width,int height,unsigned char*retimg,int normwid,int normhei);
unsigned char * writeString(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val);
double rGuassGenerate(double mu, double theda,double min,double max);
void shiftPart2_s(Group *curgrp,int shiftlr,int shifttb);
void zoomPart2_s(Group *curgrp,float zmprolr,float zmprotb,int top,int left);
int get_charleftpos_instring(Group*leftchars,Group*curchar);
void cal_rel_atright_andinte(Group *groupi,Group *groupk,int k);
void cal_rel_atleft_andinte(Group *groupi,Group *groupk,int k);
void cal_rel_attop_andinte(Group *groupi,Group *groupk,int k);
void cal_rel_atbot_andinte(Group *groupi,Group *groupk,int k);
bool GetCrossPoint(int aax,int aay,int bbx,int bby,int ccx,int ccy,int ddx,int ddy,int &x,int &y);
unsigned char *writeString_Eng(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val);
void ck_stroke_conornot_draw(Group *onegroup);
int kua(int a1x,int a1y,int b1x,int b1y,int a2x,int a2y,int b2x,int b2y)  ;                         //����ʵ��  
float get_stkpro_incurve(Group *grp,int dcind);
void  add_noise2(unsigned char *img,int wid,int hei,int cw,int ch);
 int calCentroid(unsigned char* data, int width, int height, float *x, float *y);
void getLRTB(unsigned char *img,int width,int height,
			 int *retleft,int *retright,int *rettop,int *retbot);

int normimg(unsigned char *ucimg,int width,int height,unsigned char*retimg,int normwid,int normhei,int cennmwid,int cennmhei);
void zoom(unsigned char *src, int width, int height, unsigned char *ret, int retwidth, int retheight);
bool writePart3(int styleidx,char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,int *retisendstroke_ofpart,int part_lvl);
void batch_write_str();
int findLeftPos(Group *grp,Group*allgroup_big);
int findRightPos(Group *grp,Group*allgroup_big);
int findBotPos(Group *grp,Group*allgroup_big);
int findTopPos(Group *grp,Group*allgroup_big);
 
void zoom_smth(unsigned char *src, int width, int height, unsigned char *ret, int retwidth, int retheight);
int LineToCurve2(Group *grp);

void CopyStrokes(Group*&allgroup,Group* &onegroup,int allgroupnum);
void shiftPart2(Group *curgrp,int shiftlr,int shifttb);


int LineToCurve3(Group *grp,int* isendstroke_ofpart);
bool writePart(char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,bool *retisendstroke_ofpart);
void zoomPart2(Group *curgrp,float zmprolr,float zmprotb,int top,int left);
void updateGrp(Group *grp);
void cal_grouplrtb(Group* &allgroup,int allgroupnum);
bool writePart2(char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,bool *retisendstroke_ofpart);
void ReleaseGrammer1(Group *&onegroup);
void ReleaseGrammer4(Group *&allgroup,Group *&allgroup_cp,int allgroupnum);
void ReleaseGrammer4(Group *&allgroup,int allgroupnum);

void ReleaseGrammer(Group *&allgroup,int allgroupnum);
void ReleaseGrammer(Group *&allgroup,Group *&allgroup_cp,int allgroupnum);
void initgrp(Group *grp);
void rotatePart(Group *curgrp,double rotval);

void group_relationship_big(Group*&allgroup_big,int groupnum1);
void randperm(int n,int **idx);
void batch_write(int);

void rotatePart(Group *curgrp); 
void updateGrp_draw(Group *grp);
void ck_stroke_conornot(Group *onegroup);
void copy_allgroup_toonegroup(Group* onegroup,Group*allgroup,int*  isendstroke_ofpart,int allgroupnum,int allstrokenum);
void shiftPart();

int writeHanzi(int claind,int cnt,char *filename,char *svpath,unsigned char *retimg,int iswriteChi,int m_slider_var_val,int m_slider_con_val);
void drawCurveOnImg(Group *grp,int onegroupwid,int onegrouphei);

void drawGrammer(Group *grp);
int LineToCurve_oristroke(Group *grp,bool* isendstroke_ofpart);

void InitGrammer(char *path,char *hanziname,int ziti,int &allstrokenum,int &allgroupnum,
	Group* allgroup);
void cuoqie_x(unsigned char *img,int width,int height,float ang);
void cuoqie_y(unsigned char *img,int width,int height,float ang);
bool readPart(char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,int *retisendstroke_ofpart,int part_lvl);

void rotatePart3(Group *curgrp,double rotval);
void rotatePart2(Group *curgrp,double rotval);
double C(int n,int i);
double N(double u,int n);
int JieCheng(int n);


double    _random(void);
double    _sta(double    mu,double    sigma);
void test_guassGenerate();

double realGuassGenerate(double mu, double theda,double min,double max);