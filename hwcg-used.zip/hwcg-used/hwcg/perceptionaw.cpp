#include "stdafx.h"
#include "perceptionaw.h"
/*//for debug
#include "crtdbg.h"
inline void EnableMemLeakCheck()
{
_CrtSetDbgFlag(_CrtSetDbgFlag(_CRTDBG_REPORT_FLAG) | _CRTDBG_LEAK_CHECK_DF);
}
#ifdef _DEBUG
#define new new(_NORMAL_BLOCK, __FILE__, __LINE__)
#endif
*/
float glo_prev_rotang=0;
int glo_noise2_size=3;
float glo_prev_sx=0;
float glo_prev_sy=0;
float glo_prev_ex=0;
float glo_prev_ey=0;
float glo_canvanish_stk_minpro=0;
int glo_cur_used_sw=0;
double glo_2strokes_con=0.3;
int glo_pro_cut_iend=8;
int glo_pro_cut_ia1end=5;
int glo_cutcon_pro=90;
int glo_negdir_pro=2;
int glo_add_stroke_pro=80;
bool glo_is_writing_Chi=0;
int readpart_style[1000];
int readpart_startidx[1000];
int readpart_endidx[1000];
int cnt_read_style=0;
int cnt_write_style=0;
int glo_read_used_style=0;
bool firstin_write=true;
int glo_style;
int glo_style_wid,glo_style_hei;
float glo_rotang_pro=2;
float glo_zeroang_min=0.1;
float glo_pre_para;
bool pre_style_suc=1;
bool pre_para_suc=1;
double glo_grp_dis_wei=3;//weight of original distance between groups 
double glo_firstin_widpro=1;
double glo_firstin_heipro=1;
double glo_lr_or_tb_inter_shiftpro=2;
double glo_selfpro=3;
double glo_lr_or_tb_smlinter_shiftpro=2;
double glo_hengshu_lrtb_wei=1;//-| �������ƶ��ľ��룬�������
double glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei
double glo_paral_stroke_maxdis_wei=4;
double glo_lr_or_tb_shift_wei=2;// || shift top pro
double glo_dis_inte_pie_heng=1;//   /- \-   -\ -/  distance between them based on -
int glo_maxdis_addnoise=4;
double glo_as_lrtb_inter_min_pro=0.3;
double glo_as_lrtb_inter_maxdis_pro=3;
double glo_hengheng_shushu_inte_pro=0.3;
double glo_hengheng_shushu_tb_pro=0.3;
double glo_max_dis_fordiswei=300;
double glo_grpdis_selfwei=1.5;//lrtb���׼����
double glo_part_caninte_pt=0.0;//�ཻ���׼��ص��̶�
double glo_lrtb_part_canintepro=0.1;//�ཻ���׼��ص��̶�
double glo_part_disself_pt=1.5;//�ཻ���׼����
double glo_max_curvepro,glo_min_curvepro;
double glo_stroke_inte_minpro=0.1;//�ཻ�ʻ���С©������
double PI=3.1415926; 
int gen_nmwid=32;
int gen_nmwid_cen=32;
int glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot;
int width=gen_nmwid*9,height=gen_nmwid*9;
int cst_wei_left=gen_nmwid*3;//(stroke_can_zoom_pro*10);
int cst_wei_top=gen_nmwid*3;//(stroke_can_zoom_pro*10);
bool start_end_con=0;//denote whether start pt and end pt is connected together
double start_end_con_len=0.5;
double start_end_con_len_dec=0.5;
int glo_isgrow=5;//�ʻ��䳤�ĸ��ʣ�~/10
float xxxx=100;
double stroke_tiny_zoom=0.0;///�ʻ����������������ٴ���������ʻ�����

double prob_like_con=-1.0;
double prob_like_con_weilong=1;
double prob_like_con_weishort=1;
double prob_shortdis_connet=-1.0;
double prob_longdis_connect=-1;
double glo_cutcon_pro2;
double det_long_short_connect=0;

//double curvepro=0.1;////ֱ�߱������ĳ̶�

double glo_string_con_pro=0.5;
float glo_a=0;
float glo_cuoqiex_leftang=-glo_a;
float glo_cuoqiex_rightang=glo_a;
float glo_cuoqiey_topang=glo_a;
float glo_cuoqiey_botang=-glo_a;

double max_part_rotang_left=-0.5;//������ת�����Ƕ�15deg
double max_part_rotang_right=0.5;

double	stroke_rotate_maxang=0.1;
double max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
double max_ss_rotang_right=stroke_rotate_maxang;


double max_ss_zoompro=2;//���ַŴ��������
double stroke_can_zoom_pro=max_ss_zoompro;
double min_ss_zoompro=0.5;//������С��������

double max_part_zoompro=3;//���ַŴ��������
double min_part_zoompro=1;//������С��������

int glo_lrtb_sclpro=10;

int glo_graychayi=60;//200
int glo_graydec=10;
int strokewid=55;
float strokewidpro_rd=0.06;
float strokewidpro=0.13;//0.11;
int grayval=150;//150
int grayval_raodong=0;//70
int grayval_raodong_blk=30;//30

int glo_minsw=3;
int glo_maxgroupnum=500;
int glo_maxstrokenum=500;
int smthwid=3;
double max_ss_rotang_left_starts;
double 	max_ss_rotang_right_starts;

int eachgennum=20000;
double glo_constroke_start_pro=0.99;
double glo_constroke_max_lenpro=1;
double glo_part_con_pro=0.5;//���׼����ӵĸ���
int glo_stk_dotpro=5;
int glo_addnoisepro=0;
int glo_addnoisepro2=0;
unsigned char *glo_img;
float glo_nm_widpro=0;
unsigned char *genimg;
unsigned char *genimg1;
unsigned char *genimg2;
unsigned char *genimg3;
unsigned char *genimg4;
FILE *fpsvgen;
double glo_set_var_prob=1,glo_set_con_prob=1;
bool isbatchwrite=false;
char glo_learnresultpath[100]="learn_result";
char *s1="C:\\Users\\admin\\Desktop\\hwcg\\hwcg-hanzi\\hwcg";//
char *s2="d:\\genchar\\chi";//
double glo_addnoise2_stkpro=0.01;
char *rootpath="C:\\Users\\admin\\Desktop\\dsk\\hwcg\\hwcg-hanzi-engstr\\Release";//".";//
void set_para_Chi(float curwei)
{
	glo_noise2_size=2;
	glo_addnoise2_stkpro=0.01;
	glo_addnoisepro=0;
	glo_addnoisepro2=10;
	glo_constroke_start_pro=1;

	glo_cutcon_pro=90;
	glo_cutcon_pro2=50;
	glo_pro_cut_iend=4;
	glo_pro_cut_ia1end=3;
	glo_add_stroke_pro=90;


	eachgennum=100;
	glo_nm_widpro=2;
	gen_nmwid=128;
	gen_nmwid_cen=128;
	width=gen_nmwid*9;
	height=gen_nmwid*9;
	stroke_tiny_zoom=0;
	glo_lrtb_part_canintepro=0;
	glo_is_writing_Chi=1;
	glo_grp_dis_wei=2;//3 //weight of original distance between groups 
	glo_lr_or_tb_inter_shiftpro=0.5;
	glo_selfpro=2;//3
	glo_lr_or_tb_smlinter_shiftpro=1;
	glo_hengshu_lrtb_wei=0.5;//-| �������ƶ��ľ��룬�������
	glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei
	glo_paral_stroke_maxdis_wei=2;//4
	glo_lr_or_tb_shift_wei=0.25;
	glo_dis_inte_pie_heng=0.2;//   /- \-   -\ -/  distance between them based on -
	glo_stroke_inte_minpro=0.3;//�ཻ�ʻ���С©������
	glo_as_lrtb_inter_min_pro=0.3;//ori 0.3
	glo_as_lrtb_inter_maxdis_pro=3;
	glo_part_caninte_pt=0.0;
	glo_max_dis_fordiswei=300;
	glo_part_con_pro=1.5*glo_set_con_prob;
	glo_string_con_pro=1.5*glo_set_con_prob;
	glo_canvanish_stk_minpro=0;
	det_long_short_connect=0.5;
	glo_graychayi=100;//200
	glo_graydec=20;
	strokewid=55;
	strokewidpro_rd=0.03;
	strokewidpro=0.07;//0.11;
	grayval=180;//150
	grayval_raodong=0;//70
	grayval_raodong_blk=5;//30
	glo_minsw=3;
	glo_maxgroupnum=500;
	glo_maxstrokenum=500;
	smthwid=3;	
	glo_firstin_widpro=1;   //ori 0.8
	glo_firstin_heipro=1;   //ori 

	
	glo_constroke_max_lenpro=0.1;
	glo_min_curvepro=0.0*glo_set_var_prob;

	//////////////////////////////////////////////////////////////////normal
	/*glo_a=0.0*glo_set_var_prob;//0.05
	prob_like_con=0.0*glo_set_con_prob;
	prob_like_con_weilong=0.01*glo_set_con_prob;
	prob_like_con_weishort=0.1*glo_set_con_prob;
	glo_max_curvepro=0.0*glo_set_var_prob;//0.3
	max_part_rotang_left=-0.0*glo_set_var_prob;//0.1
	max_part_rotang_right=0.0*glo_set_var_prob;
	stroke_rotate_maxang=0.0*glo_set_var_prob;//0.2*/

	//////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////curv and rot
	/*glo_a=0.05*glo_set_var_prob;//0.05
	prob_like_con=0.0*glo_set_con_prob;
	prob_like_con_weilong=0.01*glo_set_con_prob;
	prob_like_con_weishort=0.1*glo_set_con_prob;
	glo_max_curvepro=0.2*glo_set_var_prob;//0.3
	max_part_rotang_left=-0.1*glo_set_var_prob;//0.1
	max_part_rotang_right=0.1*glo_set_var_prob;
	stroke_rotate_maxang=0.3*glo_set_var_prob;//0.2*/

	//////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////curv and rot
	glo_a=0.05*glo_set_var_prob;//0.05

	prob_like_con=.5*glo_set_con_prob;
	prob_like_con_weilong=0.3*glo_set_con_prob;
	prob_like_con_weishort=1.1*glo_set_con_prob;
	prob_shortdis_connet=0.1*glo_set_con_prob;
	prob_longdis_connect=0*glo_set_con_prob;

	glo_max_curvepro=0.2*glo_set_var_prob;//0.3
	max_part_rotang_left=-0.1*glo_set_var_prob;//0.1
	max_part_rotang_right=0.1*glo_set_var_prob;
	stroke_rotate_maxang=0.3*glo_set_var_prob;//0.2

	//////////////////////////////////////////////////////////

	max_part_zoompro=1.5+(glo_set_var_prob/2.0);//1.25
	min_part_zoompro=1;//������С��������
	max_ss_zoompro=1+glo_set_var_prob;//
	min_ss_zoompro=0.5+glo_set_var_prob/4.0;//0.75
	glo_grpdis_selfwei=1.2;//lrtb���׼����//ori 1.5
	glo_part_disself_pt=0.2;//�ཻ���׼����//ori 0.5
	stroke_can_zoom_pro=max_ss_zoompro;	
	glo_cuoqiex_leftang=-glo_a;
	glo_cuoqiex_rightang=glo_a;
	glo_cuoqiey_topang=glo_a;
	glo_cuoqiey_botang=-glo_a;
	max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
	max_ss_rotang_right=stroke_rotate_maxang;
	max_ss_rotang_left_starts=max_ss_rotang_left;
	max_ss_rotang_right_starts=max_ss_rotang_right;
	/*
	max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������
	stroke_can_zoom_pro=max_ss_zoompro;
	min_ss_zoompro=0.5+glo_set_var_prob/4.0;//������С��������*/

}
/*void set_para_Chi(float curwei)
{
glo_noise2_size=2;
glo_addnoise2_stkpro=0.01;
glo_addnoisepro=0;
glo_addnoisepro2=10;
glo_constroke_start_pro=1;

glo_cutcon_pro=90;
glo_cutcon_pro2=50;
glo_pro_cut_iend=4;
glo_pro_cut_ia1end=3;
glo_add_stroke_pro=90;


eachgennum=100;
glo_nm_widpro=2;
gen_nmwid=128;
gen_nmwid_cen=128;
width=gen_nmwid*9;
height=gen_nmwid*9;
stroke_tiny_zoom=0;
glo_lrtb_part_canintepro=0;


glo_is_writing_Chi=1;
glo_grp_dis_wei=2;//3 //weight of original distance between groups 
glo_lr_or_tb_inter_shiftpro=0.5;

glo_selfpro=2;//3
glo_lr_or_tb_smlinter_shiftpro=1;
glo_hengshu_lrtb_wei=0.5;//-| �������ƶ��ľ��룬�������
glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei

glo_paral_stroke_maxdis_wei=2;//4
glo_lr_or_tb_shift_wei=0.25;
glo_dis_inte_pie_heng=0.2;//   /- \-   -\ -/  distance between them based on -
glo_stroke_inte_minpro=0.3;//�ཻ�ʻ���С©������
glo_as_lrtb_inter_min_pro=0.3;//ori 0.3
glo_as_lrtb_inter_maxdis_pro=3;

glo_part_caninte_pt=0.0;
glo_max_dis_fordiswei=300;




glo_part_con_pro=1.5*glo_set_con_prob;
glo_string_con_pro=1.5*glo_set_con_prob;


glo_canvanish_stk_minpro=0;
det_long_short_connect=0.5;
glo_graychayi=100;//200
glo_graydec=20;
strokewid=55;
strokewidpro_rd=0.03;
strokewidpro=0.07;//0.11;
grayval=180;//150
grayval_raodong=0;//70
grayval_raodong_blk=5;//30
glo_minsw=3;
glo_maxgroupnum=500;
glo_maxstrokenum=500;
smthwid=3;	
glo_firstin_widpro=1;   //ori 0.8
glo_firstin_heipro=1;   //ori 
prob_like_con=0.2*glo_set_con_prob;
prob_like_con_weilong=0.01*glo_set_con_prob;
prob_like_con_weishort=0.1*glo_set_con_prob;
prob_shortdis_connet=0.02*glo_set_con_prob;
prob_longdis_connect=0.0001*glo_set_con_prob;

glo_constroke_max_lenpro=0.1;

glo_max_curvepro=0.4*glo_set_var_prob;//0.3
glo_min_curvepro=0.0*glo_set_var_prob;
glo_a=0.1*glo_set_var_prob;//0.05
max_part_rotang_left=-0.2*glo_set_var_prob;//0.1
max_part_rotang_right=0.2*glo_set_var_prob;
stroke_rotate_maxang=0.3*glo_set_var_prob;//0.2

max_part_zoompro=1.5+(glo_set_var_prob/2.0);//1.25
min_part_zoompro=1;//������С��������

max_ss_zoompro=1+glo_set_var_prob;//
min_ss_zoompro=0.5+glo_set_var_prob/4.0;//0.75

glo_grpdis_selfwei=1.2;//lrtb���׼����//ori 1.5
glo_part_disself_pt=0.2;//�ཻ���׼����//ori 0.5

stroke_can_zoom_pro=max_ss_zoompro;	
glo_cuoqiex_leftang=-glo_a;
glo_cuoqiex_rightang=glo_a;
glo_cuoqiey_topang=glo_a;
glo_cuoqiey_botang=-glo_a;
max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
max_ss_rotang_right=stroke_rotate_maxang;
max_ss_rotang_left_starts=max_ss_rotang_left;
max_ss_rotang_right_starts=max_ss_rotang_right;


}hb*/
/*void set_para_Chi(float curwei)
{
glo_noise2_size=2;
glo_addnoise2_stkpro=0.01;
glo_addnoisepro=0;
glo_addnoisepro2=10;
glo_constroke_start_pro=1;
glo_constroke_max_lenpro=0.5;
glo_cutcon_pro=90;
glo_cutcon_pro2=50;
glo_pro_cut_iend=4;
glo_pro_cut_ia1end=3;
glo_add_stroke_pro=90;


eachgennum=100;
glo_nm_widpro=2;
gen_nmwid=128;
gen_nmwid_cen=128;
width=gen_nmwid*9;
height=gen_nmwid*9;
stroke_tiny_zoom=0;
glo_lrtb_part_canintepro=0;


glo_is_writing_Chi=1;
glo_grp_dis_wei=2;//3 //weight of original distance between groups 
glo_lr_or_tb_inter_shiftpro=0.5;

glo_selfpro=2;//3
glo_lr_or_tb_smlinter_shiftpro=1;
glo_hengshu_lrtb_wei=0.5;//-| �������ƶ��ľ��룬�������
glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei

glo_paral_stroke_maxdis_wei=2;//4
glo_lr_or_tb_shift_wei=0.25;
glo_dis_inte_pie_heng=0.2;//   /- \-   -\ -/  distance between them based on -
glo_stroke_inte_minpro=0.3;//�ཻ�ʻ���С©������
glo_as_lrtb_inter_min_pro=0.3;//ori 0.3
glo_as_lrtb_inter_maxdis_pro=3;

glo_part_caninte_pt=0.0;
glo_max_dis_fordiswei=300;




glo_part_con_pro=1.5*glo_set_con_prob;
glo_string_con_pro=1.5*glo_set_con_prob;


glo_canvanish_stk_minpro=0;
det_long_short_connect=0.5;
glo_graychayi=100;//200
glo_graydec=20;
strokewid=55;
strokewidpro_rd=0.03;
strokewidpro=0.07;//0.11;
grayval=180;//150
grayval_raodong=0;//70
grayval_raodong_blk=5;//30
glo_minsw=3;
glo_maxgroupnum=500;
glo_maxstrokenum=500;
smthwid=3;	
glo_firstin_widpro=0.75;   //ori 0.8
glo_firstin_heipro=0.75;   //ori 
prob_like_con=1*glo_set_con_prob;
prob_like_con_weilong=1*glo_set_con_prob;
prob_like_con_weishort=1*glo_set_con_prob;
prob_shortdis_connet=0.1*glo_set_con_prob;
prob_longdis_connect=0.01*glo_set_con_prob;

glo_max_curvepro=0.2*glo_set_var_prob;//0.3
glo_min_curvepro=0.0*glo_set_var_prob;
glo_a=0.05*glo_set_var_prob;//0.05
max_part_rotang_left=-0.1*glo_set_var_prob;//0.1
max_part_rotang_right=0.1*glo_set_var_prob;
stroke_rotate_maxang=0.2*glo_set_var_prob;//0.2

max_part_zoompro=1+(glo_set_var_prob/2.0);//1.25
min_part_zoompro=1;//������С��������

max_ss_zoompro=1+glo_set_var_prob;//
min_ss_zoompro=0.5+glo_set_var_prob/4.0;//0.75

glo_grpdis_selfwei=1.2;//lrtb���׼����//ori 1.5
glo_part_disself_pt=0.2;//�ཻ���׼����//ori 0.5

stroke_can_zoom_pro=max_ss_zoompro;	
glo_cuoqiex_leftang=-glo_a;
glo_cuoqiex_rightang=glo_a;
glo_cuoqiey_topang=glo_a;
glo_cuoqiey_botang=-glo_a;
max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
max_ss_rotang_right=stroke_rotate_maxang;
max_ss_rotang_left_starts=max_ss_rotang_left;
max_ss_rotang_right_starts=max_ss_rotang_right;


}chi con*/

/*void set_para_Chi(float curwei)
{
glo_noise2_size=2;
glo_addnoise2_stkpro=0.01;
glo_addnoisepro=0;
glo_addnoisepro2=10;
glo_constroke_start_pro=1;
glo_constroke_max_lenpro=0.5;
glo_cutcon_pro=90;
glo_cutcon_pro2=50;
glo_pro_cut_iend=4;
glo_pro_cut_ia1end=3;
glo_add_stroke_pro=90;


eachgennum=100;
glo_nm_widpro=2;
gen_nmwid=128;
gen_nmwid_cen=128;
width=gen_nmwid*9;
height=gen_nmwid*9;
stroke_tiny_zoom=0;
glo_lrtb_part_canintepro=0;


glo_is_writing_Chi=1;
glo_grp_dis_wei=2;//3 //weight of original distance between groups 
glo_lr_or_tb_inter_shiftpro=0.5;

glo_selfpro=2;//3
glo_lr_or_tb_smlinter_shiftpro=1;
glo_hengshu_lrtb_wei=0.5;//-| �������ƶ��ľ��룬�������
glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei

glo_paral_stroke_maxdis_wei=2;//4
glo_lr_or_tb_shift_wei=0.25;
glo_dis_inte_pie_heng=0.2;//   /- \-   -\ -/  distance between them based on -
glo_stroke_inte_minpro=0.3;//�ཻ�ʻ���С©������
glo_as_lrtb_inter_min_pro=0.3;//ori 0.3
glo_as_lrtb_inter_maxdis_pro=3;

glo_part_caninte_pt=0.0;
glo_max_dis_fordiswei=300;




glo_part_con_pro=0.5*glo_set_con_prob;
glo_string_con_pro=0.5*glo_set_con_prob;


glo_canvanish_stk_minpro=0;
det_long_short_connect=0.5;
glo_graychayi=100;//200
glo_graydec=20;
strokewid=55;
strokewidpro_rd=0.03;
strokewidpro=0.07;//0.11;
grayval=180;//150
grayval_raodong=0;//70
grayval_raodong_blk=5;//30
glo_minsw=3;
glo_maxgroupnum=500;
glo_maxstrokenum=500;
smthwid=3;	
glo_firstin_widpro=0.75;   //ori 0.8
glo_firstin_heipro=0.75;   //ori 
prob_like_con=1*glo_set_con_prob;
prob_like_con_weilong=0.7*glo_set_con_prob;
prob_like_con_weishort=0.9*glo_set_con_prob;
prob_shortdis_connet=0.1*glo_set_con_prob;
prob_longdis_connect=0.01*glo_set_con_prob;

glo_max_curvepro=0.2*glo_set_var_prob;//0.3
glo_min_curvepro=0.0*glo_set_var_prob;
glo_a=0.05*glo_set_var_prob;//0.05
max_part_rotang_left=-0.1*glo_set_var_prob;//0.1
max_part_rotang_right=0.1*glo_set_var_prob;
stroke_rotate_maxang=0.2*glo_set_var_prob;//0.2

max_part_zoompro=1+(glo_set_var_prob/2.0);//1.25
min_part_zoompro=1;//������С��������

max_ss_zoompro=1+glo_set_var_prob;//
min_ss_zoompro=0.5+glo_set_var_prob/4.0;//0.75

glo_grpdis_selfwei=1.2;//lrtb���׼����//ori 1.5
glo_part_disself_pt=0.2;//�ཻ���׼����//ori 0.5

stroke_can_zoom_pro=max_ss_zoompro;	
glo_cuoqiex_leftang=-glo_a;
glo_cuoqiex_rightang=glo_a;
glo_cuoqiey_topang=glo_a;
glo_cuoqiey_botang=-glo_a;
max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
max_ss_rotang_right=stroke_rotate_maxang;
max_ss_rotang_left_starts=max_ss_rotang_left;
max_ss_rotang_right_starts=max_ss_rotang_right;

//max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������
//stroke_can_zoom_pro=max_ss_zoompro;
//min_ss_zoompro=0.5+glo_set_var_prob/4.0;//������С��������

}*/

/**/
void set_para_Eng(int inchar)
{
	glo_noise2_size=2;
	glo_addnoise2_stkpro=0.01;
	glo_canvanish_stk_minpro=0;
	glo_addnoisepro=1;
	glo_addnoisepro2=5;
	glo_constroke_start_pro=1;
	glo_constroke_max_lenpro=0.15;
	glo_cutcon_pro=90;
	glo_cutcon_pro2=50;
	glo_pro_cut_iend=8;
	glo_pro_cut_ia1end=8;

	prob_like_con=0.3*glo_set_con_prob;
	prob_like_con_weilong=0.1*glo_set_con_prob;
	prob_like_con_weishort=0.99*glo_set_con_prob;
	prob_shortdis_connet=0.00*glo_set_con_prob;
	prob_longdis_connect=0.00*glo_set_con_prob;
	eachgennum=300;
	glo_nm_widpro=0.1;
	stroke_tiny_zoom=0.00;
	gen_nmwid=64;
	gen_nmwid_cen=64;
	width=gen_nmwid*9;
	height=gen_nmwid*9;

	glo_is_writing_Chi=0;
	glo_grp_dis_wei=2;//weight of original distance between groups 
	glo_lr_or_tb_inter_shiftpro=1;//ori 1
	glo_selfpro=3;//ori 3
	glo_lr_or_tb_smlinter_shiftpro=1;//ori 1
	glo_hengshu_lrtb_wei=1;//ori 1   -| �������ƶ��ľ��룬�������
	glo_paral_stroke_dis_wei=0.4;//ori 0.2  parallel strokes min distance related to the height of k_hei
	glo_paral_stroke_maxdis_wei=4;//ori 4
	glo_lr_or_tb_shift_wei=1;//ori 1   || shift top pro
	glo_dis_inte_pie_heng=1.1;//   /- \-   -\ -/  distance between them based on -

	glo_as_lrtb_inter_min_pro=0.3;
	glo_as_lrtb_inter_maxdis_pro=3;
	glo_part_caninte_pt=0.0;
	glo_max_dis_fordiswei=300;
	glo_part_disself_pt=0.1;
	glo_stroke_inte_minpro=0.2;//�ཻ�ʻ���С©������
	glo_part_con_pro=0.5*glo_set_con_prob;
	glo_string_con_pro=0.5*glo_set_con_prob;
	strokewidpro_rd=9;
	strokewidpro=0.0;//0.11;
	glo_graychayi=100;//200
	glo_graydec=20;
	strokewid=55;
	grayval=150;//150
	grayval_raodong=0;//70
	grayval_raodong_blk=5;//30
	glo_minsw=3;
	glo_maxgroupnum=500;
	glo_maxstrokenum=500;
	smthwid=3;	
	glo_min_curvepro=0.00*glo_set_var_prob;
	glo_zeroang_min=0.1;
	glo_firstin_widpro=1;	//1234  0.8
	glo_firstin_heipro=1;
	glo_maxdis_addnoise=16;

	if(inchar==0||inchar==6||inchar==9)
		glo_cutcon_pro=95;
	else
		glo_cutcon_pro=70;//80

	if(inchar==8||inchar==9)
		glo_firstin_widpro=1.5;
	else
		glo_firstin_widpro=1.5;//80

	if(inchar==1||inchar==4 ||inchar==7)
		glo_max_curvepro=0.2*glo_set_var_prob;//0.3
	else
		glo_max_curvepro=0.4*glo_set_var_prob;//0.3
	if(inchar==1)
	{
		max_part_rotang_left=-0.1*glo_set_var_prob;//0.3
		max_part_rotang_right=0.1*glo_set_var_prob;

	}
	else if(inchar==0)
	{
		max_part_rotang_left=-8*glo_set_var_prob;//0.3
		max_part_rotang_right=8*glo_set_var_prob;
	}
	else
	{
		max_part_rotang_left=-0.4*glo_set_var_prob;//0.3
		max_part_rotang_right=0.4*glo_set_var_prob;
	}
	glo_a=0.1*glo_set_var_prob;//0.05
	stroke_rotate_maxang=0.4*glo_set_var_prob;//0.4 
	glo_add_stroke_pro=80;

	min_ss_zoompro=0.25+glo_set_var_prob/4.0;//12345 0.75
	max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������

	stroke_can_zoom_pro=max_ss_zoompro;
	glo_cuoqiex_leftang=-glo_a;
	glo_cuoqiex_rightang=glo_a;
	glo_cuoqiey_topang=glo_a;
	glo_cuoqiey_botang=-glo_a;
	max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
	max_ss_rotang_right=stroke_rotate_maxang;
	max_ss_rotang_left_starts=max_ss_rotang_left;
	max_ss_rotang_right_starts=max_ss_rotang_right;
	max_part_zoompro=1.5+(glo_set_var_prob/2.0);//���ַŴ��������
	min_part_zoompro=1;//������С��������



}/*flower*/
/*
void set_para_Eng(int inchar)
{
glo_noise2_size=2;
glo_addnoise2_stkpro=0.01;
glo_canvanish_stk_minpro=0;
glo_addnoisepro=1;
glo_addnoisepro2=5;
glo_constroke_start_pro=1;
glo_constroke_max_lenpro=0.15;
glo_cutcon_pro=90;
glo_cutcon_pro2=50;
glo_pro_cut_iend=8;
glo_pro_cut_ia1end=8;

prob_like_con=0.0*glo_set_con_prob;
prob_like_con_weilong=0.1*glo_set_con_prob;
prob_like_con_weishort=0.99*glo_set_con_prob;
prob_shortdis_connet=0.00*glo_set_con_prob;
prob_longdis_connect=0.00*glo_set_con_prob;
eachgennum=100;
glo_nm_widpro=0.1;
stroke_tiny_zoom=0.00;
gen_nmwid=64;
gen_nmwid_cen=64;
width=gen_nmwid*9;
height=gen_nmwid*9;

glo_is_writing_Chi=0;
glo_grp_dis_wei=2;//weight of original distance between groups 
glo_lr_or_tb_inter_shiftpro=1;//ori 1
glo_selfpro=3;//ori 3
glo_lr_or_tb_smlinter_shiftpro=1;//ori 1
glo_hengshu_lrtb_wei=1;//ori 1   -| �������ƶ��ľ��룬�������
glo_paral_stroke_dis_wei=0.4;//ori 0.2  parallel strokes min distance related to the height of k_hei
glo_paral_stroke_maxdis_wei=4;//ori 4
glo_lr_or_tb_shift_wei=1;//ori 1   || shift top pro
glo_dis_inte_pie_heng=1.1;//   /- \-   -\ -/  distance between them based on -

glo_as_lrtb_inter_min_pro=0.3;
glo_as_lrtb_inter_maxdis_pro=3;
glo_part_caninte_pt=0.0;
glo_max_dis_fordiswei=300;
glo_part_disself_pt=0.1;
glo_stroke_inte_minpro=0.2;//�ཻ�ʻ���С©������
glo_part_con_pro=0.5*glo_set_con_prob;
glo_string_con_pro=0.5*glo_set_con_prob;
strokewidpro_rd=9;
strokewidpro=0.0;//0.11;
glo_graychayi=100;//200
glo_graydec=20;
strokewid=55;
grayval=150;//150
grayval_raodong=0;//70
grayval_raodong_blk=5;//30
glo_minsw=3;
glo_maxgroupnum=500;
glo_maxstrokenum=500;
smthwid=3;	
glo_min_curvepro=0.00*glo_set_var_prob;
glo_zeroang_min=0.1;
glo_firstin_widpro=1;	//1234  0.8
glo_firstin_heipro=1;
glo_maxdis_addnoise=16;

if(inchar==0||inchar==6||inchar==9)
glo_cutcon_pro=95;
else
glo_cutcon_pro=90;//80

if(inchar==8||inchar==9)
glo_firstin_widpro=1.5;
else
glo_firstin_widpro=1;//80

if(inchar==1||inchar==4 ||inchar==7)
glo_max_curvepro=0.2*glo_set_var_prob;//0.3
else
glo_max_curvepro=0.2*glo_set_var_prob;//0.3
if(inchar==1)
{
max_part_rotang_left=-0.1*glo_set_var_prob;//0.3
max_part_rotang_right=0.1*glo_set_var_prob;

}
else if(inchar==0)
{
max_part_rotang_left=-8*glo_set_var_prob;//0.3
max_part_rotang_right=8*glo_set_var_prob;
}
else
{
max_part_rotang_left=-0.2*glo_set_var_prob;//0.3
max_part_rotang_right=0.2*glo_set_var_prob;
}
glo_a=0.05*glo_set_var_prob;//0.05
stroke_rotate_maxang=0.3*glo_set_var_prob;//0.4 
glo_add_stroke_pro=90;

min_ss_zoompro=0.35+glo_set_var_prob/4.0;//12345 0.75
max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������

stroke_can_zoom_pro=max_ss_zoompro;
glo_cuoqiex_leftang=-glo_a;
glo_cuoqiex_rightang=glo_a;
glo_cuoqiey_topang=glo_a;
glo_cuoqiey_botang=-glo_a;
max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
max_ss_rotang_right=stroke_rotate_maxang;
max_ss_rotang_left_starts=max_ss_rotang_left;
max_ss_rotang_right_starts=max_ss_rotang_right;
max_part_zoompro=1.5+(glo_set_var_prob/2.0);//���ַŴ��������
min_part_zoompro=1;//������С��������



}*/


void set_para_Eng_string(float curwei)
{
	set_para_Eng(2);
	glo_cutcon_pro=98;
	glo_cutcon_pro2=95;
	glo_constroke_start_pro=1;
	glo_constroke_max_lenpro=0.1;
	prob_like_con=0.2*glo_set_con_prob;
	prob_like_con_weilong=0.8*glo_set_con_prob;
	prob_like_con_weishort=1*glo_set_con_prob;
	glo_part_con_pro=1*glo_set_con_prob;
	glo_string_con_pro=1*glo_set_con_prob;
	max_part_zoompro=1.5+(glo_set_var_prob/2.0);//���ַŴ��������
	min_part_zoompro=1.5-glo_set_var_prob/2.0;//������С��������
}

/*
void set_para_Eng_string(float curwei)
{
glo_addnoisepro=0;
glo_constroke_start_pro=1;
glo_constroke_max_lenpro=0.1;
glo_max_curvepro=0.3;
glo_cutcon_pro=90;
glo_cutcon_pro2=50;
glo_pro_cut_iend=8;
glo_pro_cut_ia1end=8;
glo_add_stroke_pro=90;

prob_like_con=1*glo_set_con_prob;
prob_like_con_weilong=1.99*glo_set_con_prob;
prob_like_con_weishort=1*glo_set_con_prob;
prob_shortdis_connet=0.1*glo_set_con_prob;
prob_longdis_connect=0.05*glo_set_con_prob;

eachgennum=70000;
glo_nm_widpro=0.1;
stroke_tiny_zoom=0.00;

gen_nmwid=64;
gen_nmwid_cen=64;
width=gen_nmwid*9;
height=gen_nmwid*9;

glo_is_writing_Chi=0;
glo_grp_dis_wei=2;//weight of original distance between groups 


glo_lr_or_tb_inter_shiftpro=1;//ori 1


glo_selfpro=3;//ori 3
glo_lr_or_tb_smlinter_shiftpro=1;//ori 1
glo_hengshu_lrtb_wei=1;//ori 1   -| �������ƶ��ľ��룬�������
glo_paral_stroke_dis_wei=0.4;//ori 0.2  parallel strokes min distance related to the height of k_hei
glo_paral_stroke_maxdis_wei=4;//ori 4
glo_lr_or_tb_shift_wei=1;//ori 1   || shift top pro
glo_dis_inte_pie_heng=1.1;//   /- \-   -\ -/  distance between them based on -
glo_firstin_widpro=1;	
glo_firstin_heipro=1;
glo_as_lrtb_inter_min_pro=0.3;
glo_as_lrtb_inter_maxdis_pro=3;

glo_part_caninte_pt=0.0;
glo_max_dis_fordiswei=300;
glo_part_disself_pt=0.1;
glo_stroke_inte_minpro=0.2;//�ཻ�ʻ���С©������



glo_part_con_pro=1*glo_set_con_prob;
glo_string_con_pro=1*glo_set_con_prob;


strokewidpro_rd=9;
strokewidpro=0.0;//0.11;

glo_graychayi=100;//200
glo_graydec=20;
strokewid=55;
grayval=150;//150
grayval_raodong=0;//70
grayval_raodong_blk=5;//30


glo_minsw=3;
glo_maxgroupnum=500;
glo_maxstrokenum=500;
smthwid=3;	

//glo_max_curvepro=0.1*glo_set_var_prob;//0.2 2018
glo_min_curvepro=0.00*glo_set_var_prob;

// curvepro=0.2*glo_set_var_prob;
glo_a=0.0*glo_set_var_prob;//0.01 2018
glo_cuoqiex_leftang=-glo_a;
glo_cuoqiex_rightang=glo_a;
glo_cuoqiey_topang=glo_a;
glo_cuoqiey_botang=-glo_a;



max_part_rotang_left=-0.3*glo_set_var_prob;//������ת�����Ƕ�15deg
max_part_rotang_right=0.3*glo_set_var_prob;

stroke_rotate_maxang=0.3*glo_set_var_prob;//0.4 2018
glo_zeroang_min=0.1;
max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
max_ss_rotang_right=stroke_rotate_maxang;


max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������
stroke_can_zoom_pro=max_ss_zoompro;



min_ss_zoompro=0.5+glo_set_var_prob/4.0;//������С��������



max_part_zoompro=1.5+(glo_set_var_prob/4.0);//���ַŴ��������
min_part_zoompro=1.5-glo_set_var_prob/4.0;//������С��������


}
*/
void set_para_Chi_string(float curwei)
{

	glo_constroke_start_pro=1;
	glo_constroke_max_lenpro=0.5;
	//glo_max_curvepro=1.5;
	glo_max_curvepro=0.3*glo_set_var_prob;
	glo_cutcon_pro=190;
	glo_cutcon_pro2=150;
	glo_pro_cut_iend=4;
	glo_pro_cut_ia1end=3;
	glo_add_stroke_pro=190;


	prob_like_con=1.5*glo_set_con_prob;
	prob_like_con_weilong=1.4*glo_set_con_prob;
	prob_like_con_weishort=1.8*glo_set_con_prob;

	prob_shortdis_connet=0.02*glo_set_con_prob;
	prob_longdis_connect=0.001*glo_set_con_prob;

	eachgennum=70000;
	glo_nm_widpro=2;
	gen_nmwid=64;
	gen_nmwid_cen=64;
	stroke_tiny_zoom=0.01;
	glo_lrtb_part_canintepro=0.001;
	glo_firstin_widpro=1;
	glo_firstin_heipro=1;
	glo_is_writing_Chi=1;
	glo_grp_dis_wei=2;//3 //weight of original distance between groups 
	glo_lr_or_tb_inter_shiftpro=0.5;

	glo_selfpro=2;//3
	glo_lr_or_tb_smlinter_shiftpro=1;
	glo_hengshu_lrtb_wei=0.5;//-| �������ƶ��ľ��룬�������
	glo_paral_stroke_dis_wei=0.2;//parallel strokes min distance related to the height of k_hei

	glo_paral_stroke_maxdis_wei=2;//4
	glo_lr_or_tb_shift_wei=0.25;
	glo_dis_inte_pie_heng=0.2;//   /- \-   -\ -/  distance between them based on -
	glo_stroke_inte_minpro=0.3;//�ཻ�ʻ���С©������
	glo_as_lrtb_inter_min_pro=0.3;//ori 0.3
	glo_as_lrtb_inter_maxdis_pro=3;

	glo_part_caninte_pt=0.0;
	glo_max_dis_fordiswei=300;
	glo_grpdis_selfwei=1.1;//lrtb���׼����

	glo_part_disself_pt=0.25;//�ཻ���׼����



	glo_part_con_pro=0.5*glo_set_con_prob;
	glo_string_con_pro=0.5*glo_set_con_prob;


	det_long_short_connect=0.5;
	glo_graychayi=100;//200
	glo_graydec=20;
	strokewid=55;
	strokewidpro_rd=0.03;
	strokewidpro=0.07;//0.11;
	grayval=180;//150
	grayval_raodong=0;//70
	grayval_raodong_blk=5;//30
	glo_minsw=3;
	glo_maxgroupnum=500;
	glo_maxstrokenum=500;
	smthwid=3;	

	// curvepro=0.1*glo_set_var_prob;

	glo_min_curvepro=0.0*glo_set_var_prob;

	glo_a=0.01*glo_set_var_prob;
	glo_cuoqiex_leftang=-glo_a;
	glo_cuoqiex_rightang=glo_a;
	glo_cuoqiey_topang=glo_a;
	glo_cuoqiey_botang=-glo_a;
	max_part_rotang_left=-0.01*glo_set_var_prob;//������ת�����Ƕ�15deg
	max_part_rotang_right=0.01*glo_set_var_prob;

	stroke_rotate_maxang=0.3*glo_set_var_prob;
	max_ss_rotang_left=-stroke_rotate_maxang;//������ת�����Ƕ�15deg
	max_ss_rotang_right=stroke_rotate_maxang;
	max_ss_zoompro=1+glo_set_var_prob;//���ַŴ��������
	stroke_can_zoom_pro=max_ss_zoompro;
	min_ss_zoompro=0.25+glo_set_var_prob/4.0;//������С��������
	max_part_zoompro=1.5+(glo_set_var_prob/2.0);//���ַŴ��������
	min_part_zoompro=1.5-glo_set_var_prob/2.0;//������С��������


}


void batch_write(int iswriteChi)
{
	glo_is_writing_Chi=iswriteChi;

	if(!glo_is_writing_Chi)
	{	
		set_para_Eng(0);		
	}
	else
	{	
		set_para_Chi(0);	
	}

	isbatchwrite=true;
	char charstr[3]="";
	char svpath[1024]="";
	int usedclassnum=10;
	char **clsstr=new char *[usedclassnum];
	int i;
	for( i=0;i<usedclassnum;i++)
	{
		clsstr[i]=new char[3];
		memset(clsstr[i],0,sizeof(char)*3);
	}
	char classfilename[1024]="";
	if(glo_is_writing_Chi)		
	{
		glo_is_writing_Chi=1;
		sprintf(classfilename,"%s\\usedclass_hanzi.txt",rootpath);
	}
	else
	{
		sprintf(classfilename,"%s\\usedclass_flower.txt",rootpath);
		//sprintf(classfilename,"%s\\usedclass.txt",rootpath);
		glo_is_writing_Chi=0;
	}
	FILE *fprdcls=fopen(classfilename,"r");
	for( i=0;i<usedclassnum;i++)
	{
		fscanf(fprdcls,"%s",&(clsstr[i][0]));
	}
	fclose(fprdcls);
	unsigned char *retimg=new unsigned char[gen_nmwid*gen_nmwid];
	int iiii=0 ;

	for(int rddd=iiii;rddd<iiii+1;rddd+=1)
	{
		int rd=rddd%10;
		pre_style_suc=1; 
		pre_para_suc=1;
		srand(0);
		if(glo_is_writing_Chi)		
			sprintf(svpath,"%s\\gen_char\\%d.txt",rootpath,rd);
		else
			sprintf(svpath,"%s\\gen_char-eng\\%d.txt",rootpath,rd);
		fpsvgen=fopen(svpath,"wb");
		for(int i=0;i<eachgennum;i++)
		{		
			int issuc=writeHanzi(rd,i,clsstr[rd],rootpath,retimg,glo_is_writing_Chi,10,10);
			pre_style_suc=issuc;
			pre_para_suc=issuc;
			if(!issuc)
			{
				i--;
				continue;
			}
			else
			{
				fwrite(genimg,sizeof(unsigned char),gen_nmwid*gen_nmwid,fpsvgen);
				//fwrite(genimg1,sizeof(unsigned char),gen_nmwid*gen_nmwid,fpsvgen);
				//fwrite(genimg2,sizeof(unsigned char),gen_nmwid*gen_nmwid,fpsvgen);
				//	fwrite(genimg3,sizeof(unsigned char),gen_nmwid*gen_nmwid,fpsvgen);
			}
			//	showImg(genimg,gen_nmwid,gen_nmwid);
			delete []genimg;	delete []genimg1;	delete []genimg2;	delete []genimg3;delete []genimg4;
		}
		fclose(fpsvgen);
	}
	delete []retimg;
}
void batch_write_str()
{
	set_para_Eng_string(0);
	int gennum=eachgennum;
	int retwid,rethei,rownum=4;
	FILE *fpsvgen=fopen("string.txt","wb");
	for(int i=0;i<gennum;i++)
	{
		unsigned char *retimg=writeString_Eng("string",retwid,rethei,rownum*2,10,10);
		fwrite(retimg,sizeof(unsigned char),retwid*rethei,fpsvgen);
		delete []retimg;
	}
	fclose(fpsvgen);
}

int writeHanzi(int styleidx,int cnt,char *filename,char *svpath,unsigned char *retimg,int is_writing_Chi,int m_slider_var_val,int m_slider_con_val)
{ 
	glo_prev_rotang=0;
	glo_prev_sx=0;
	glo_prev_sy=0;
	glo_prev_ex=0;
	glo_prev_ey=0;

	glo_is_writing_Chi=is_writing_Chi;
	glo_set_var_prob=m_slider_var_val/10.0;
	glo_set_con_prob=m_slider_con_val/10.0;
	start_end_con=0;


	//EnableMemLeakCheck();
	if(!is_writing_Chi)
	{
		int iiiiii=filename[0]-48;
		set_para_Eng(iiiiii);

	}
	else
	{
		if(pre_para_suc)
		{
			glo_pre_para=rand()*1.0/RAND_MAX;
			set_para_Chi(glo_pre_para);
		}
		else
		{
			set_para_Chi(glo_pre_para);
		}
	}


	float nm_wid_pro=0;//glo_nm_widpro;
	float nm_hei_pro=0.8;//glo_nm_widpro;
	float botmm=realGuassGenerate(1.5, 0.3,nm_wid_pro, 0.1);
	float botrr=realGuassGenerate(2, 0.4,  nm_hei_pro, 1);
	/*
	if(glo_addnoisepro>0)
	gen_nmwid_cen=48+rand()%16;
	else
	gen_nmwid_cen=64;
	*/
	glo_tgt_left=cst_wei_left;glo_tgt_top=cst_wei_top;
	glo_tgt_right=glo_tgt_left+gen_nmwid*(botmm);//3*(rand()%gen_nmwid);//730+rand()%100;
	glo_tgt_bot=glo_tgt_top+gen_nmwid*(botrr);//3*(rand()%gen_nmwid);//730+rand()%100;

	genimg=new unsigned char[gen_nmwid*gen_nmwid];
	genimg1=new unsigned char[gen_nmwid*gen_nmwid];
	genimg2=new unsigned char[gen_nmwid*gen_nmwid];
	genimg3=new unsigned char[gen_nmwid*gen_nmwid];
	genimg4=new unsigned char[gen_nmwid*gen_nmwid];

	glo_img=new unsigned char [width*height];
	memset(glo_img,0,sizeof(unsigned char)*width*height);

	Group *retgrp=new Group;

	retgrp->strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum];
	retgrp->draw_curves=new DrawCurve[glo_maxstrokenum];

	int *isendstroke_ofpart=new int[glo_maxstrokenum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum);

	cnt_read_style=0;
	cnt_write_style=0;
	glo_read_used_style=0;
	firstin_write=true;
	bool issuc= writePart3(styleidx,filename,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart,1);
	if(!issuc)
	{
		pre_style_suc=0;
		pre_para_suc=0;
		delete []glo_img;
		delete []genimg;delete []genimg1;delete []genimg2;delete []genimg3;delete []genimg4;
		delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
		delete []retgrp;delete []isendstroke_ofpart;
		return 0;
	}
	if(retgrp->top<=0 || retgrp->left<=0 || retgrp->bot>=width || retgrp->right>=height)
	{
		float zmprolr=(1+glo_tgt_right-glo_tgt_left)*1.0/(1+retgrp->right-retgrp->left);
		float zmprotb=(1+glo_tgt_bot-glo_tgt_top)*1.0/(1+retgrp->bot-retgrp->top);
		float smlzmpro=zmprolr<zmprotb?zmprolr:zmprotb;

		zoomPart2_s(retgrp,smlzmpro,smlzmpro,retgrp->top,retgrp->left);
		updateGrp_draw(retgrp);
		shiftPart2_s(retgrp,glo_tgt_left-retgrp->left,glo_tgt_top-retgrp->top);
		updateGrp_draw(retgrp);

	}

	ck_stroke_conornot_draw(retgrp);



	double curmax_zmpro=max_part_zoompro;
	double curmin_zmpro=min_part_zoompro;
	double rotval;
	rotval=realGuassGenerate(0,0,max_part_rotang_left,max_part_rotang_right);
	/*if(strcmp(filename,"0x")==0 ||strcmp(filename,"0")==0)
	{
	rotval=realGuassGenerate(0,0,-8,8);
	}*/

	int onegroupwid=retgrp->right-retgrp->left+1;
	int onegrouphei=retgrp->bot-retgrp->top+1;



	float curzmprolr=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	float curzmprotb=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;

	int oripostop=retgrp->top;
	int oriposleft=retgrp->left;

	updateGrp_draw((retgrp));
	rotatePart3((retgrp),rotval); //rotval
	updateGrp_draw((retgrp));


	float cuoqiexang=realGuassGenerate(0,1,glo_cuoqiex_leftang,glo_cuoqiex_rightang);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	float cuoqieyang=realGuassGenerate(0,1,glo_cuoqiey_botang,glo_cuoqiey_topang);


	//if(is_writing_Chi)
	//{
	cuoqie_x(retgrp,cuoqiexang);
	updateGrp_draw((retgrp));
	cuoqie_y(retgrp,cuoqieyang);
	updateGrp_draw((retgrp));
	//}


	shiftPart2((retgrp),glo_tgt_left-retgrp->left,glo_tgt_top-retgrp->top);
	updateGrp_draw((retgrp));

	retgrp->partition_hei=1+retgrp->bot-retgrp->top;
	retgrp->partition_wid=1+retgrp->right-retgrp->left;
	retgrp->partition_left=retgrp->left;
	retgrp->partition_top=retgrp->top;
	updateGrp_draw(retgrp);
	if(retgrp->top<=0 || retgrp->left<=0 || retgrp->bot>=width || retgrp->right>=height)
	{pre_style_suc=0;pre_para_suc=0;
	//	//AfxMessageBox("err");
	delete []glo_img;
	delete []genimg;delete []genimg1;delete []genimg2;delete []genimg3;delete []genimg4;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;delete []isendstroke_ofpart;
	return 0;
	}
	//int onegroupwid=retgrp->right-retgrp->left+1;
	//int onegrouphei=retgrp->bot-retgrp->top+1;






	for(int jjj=0;jjj<retgrp->strokenum;jjj++)
	{
		int strokelen=sqrt(1.0*
			(retgrp->draw_strokes[jjj].ptsrow-retgrp->draw_strokes[jjj].pterow)*(retgrp->draw_strokes[jjj].ptsrow-retgrp->draw_strokes[jjj].pterow)+
			(retgrp->draw_strokes[jjj].ptscol-retgrp->draw_strokes[jjj].ptecol)*(retgrp->draw_strokes[jjj].ptscol-retgrp->draw_strokes[jjj].ptecol));
		double rdlen=strokelen*stroke_tiny_zoom/2;
		//if(rdlen<5)
		//	rdlen=5;
		retgrp->draw_strokes[jjj].ptecol=retgrp->draw_strokes[jjj].ptecol+rdlen*realGuassGenerate(0,1.0/3,-1,1);//(1-rand()*2.0/RAND_MAX);
		retgrp->draw_strokes[jjj].pterow=retgrp->draw_strokes[jjj].pterow+rdlen*realGuassGenerate(0,1.0/3,-1,1);//(1-rand()*2.0/RAND_MAX);

		if(jjj>0 &&retgrp->con_ss[jjj-1].canCut==0)
		{
			retgrp->draw_strokes[jjj].ptecol=retgrp->draw_strokes[jjj].ptecol+(retgrp->draw_strokes[jjj-1].ptecol-retgrp->draw_strokes[jjj].ptscol);
			retgrp->draw_strokes[jjj].pterow=retgrp->draw_strokes[jjj].pterow+(retgrp->draw_strokes[jjj-1].pterow-retgrp->draw_strokes[jjj].ptsrow);		
			retgrp->draw_strokes[jjj].ptscol=retgrp->draw_strokes[jjj-1].ptecol;
			retgrp->draw_strokes[jjj].ptsrow=retgrp->draw_strokes[jjj-1].pterow;	

		}
	}


	int curvenum=LineToCurve_con2str(retgrp,isendstroke_ofpart);
	if(curvenum<1)	{pre_style_suc=0;pre_para_suc=0;
	delete []glo_img;
	delete []genimg;delete []genimg1;delete []genimg2;delete []genimg3;delete []genimg4;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;delete []isendstroke_ofpart;
	return 0;
	}
	retgrp->curvenum=curvenum;
	//	float cuoqiexang=realGuassGenerate(0,0,-glo_cuoqiex_maxang,glo_cuoqiex_maxang);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	//	float cuoqieyang=realGuassGenerate(0,0,-glo_cuoqiey_maxang,glo_cuoqiey_maxang);

	/*float zmprolr=(gen_nmwid_cen)*1.0/(retgrp->partition_wid);
	float zmprotb=(gen_nmwid_cen)*1.0/(retgrp->partition_hei);
	float smlzmpro=zmprolr<zmprotb?zmprolr:zmprotb;
	zoomPart2_s(retgrp,smlzmpro,smlzmpro,retgrp->top,retgrp->left);
	updateGrp_draw(retgrp);*/
	onegroupwid=retgrp->partition_wid;
	onegrouphei=retgrp->partition_hei;
	if(isbatchwrite)
	{
		memset(glo_img,0,sizeof(unsigned char)*width*height);
		if(!glo_is_writing_Chi)
			drawCurveOnImg_Bezier_eng(retgrp, onegroupwid, onegrouphei);
		else
			drawCurveOnImg_Bezier(retgrp, onegroupwid, onegrouphei);
		int issuc=normimg(glo_img,width,height,genimg,gen_nmwid,gen_nmwid,gen_nmwid_cen,gen_nmwid_cen);
		if(!is_writing_Chi)
		{
			for(int i=0;i<gen_nmwid;i++)
				for (int j=0;j<gen_nmwid;j++)
					genimg[i*gen_nmwid+j]=genimg[i*gen_nmwid+j]>0?255:0;
		}

		/*	memset(glo_img,0,sizeof(unsigned char)*width*height);
		if(!glo_is_writing_Chi)
		drawCurveOnImg_Bezier_eng(retgrp, onegroupwid, onegrouphei);
		else
		drawCurveOnImg_Bezier(retgrp, onegroupwid, onegrouphei);
		int issuc2=normimg(glo_img,width,height,genimg1,gen_nmwid,gen_nmwid,gen_nmwid_cen,gen_nmwid_cen);
		if(!is_writing_Chi)
		{
		for(int i=0;i<gen_nmwid;i++)
		for (int j=0;j<gen_nmwid;j++)
		genimg1[i*gen_nmwid+j]=genimg1[i*gen_nmwid+j]>0?255:0;
		}

		memset(glo_img,0,sizeof(unsigned char)*width*height);
		if(!glo_is_writing_Chi)
		drawCurveOnImg_Bezier_eng(retgrp, onegroupwid, onegrouphei);
		else
		drawCurveOnImg_Bezier(retgrp, onegroupwid, onegrouphei);
		int issuc3=normimg(glo_img,width,height,genimg2,gen_nmwid,gen_nmwid,gen_nmwid_cen,gen_nmwid_cen);
		if(!is_writing_Chi)
		{
		for(int i=0;i<gen_nmwid;i++)
		for (int j=0;j<gen_nmwid;j++)
		genimg2[i*gen_nmwid+j]=genimg2[i*gen_nmwid+j]>0?255:0;
		}
		*/

		if(!issuc )//||!issuc2)
		{
			pre_style_suc=0;pre_para_suc=0;
			delete []glo_img;
			delete []genimg;delete []genimg1;delete []genimg2;delete []genimg3;delete []genimg4;
			delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
			delete []retgrp;delete []isendstroke_ofpart;
			return 0;
		}


	}
	else
	{
		memset(glo_img,0,sizeof(unsigned char)*width*height);
		if(!glo_is_writing_Chi)
			drawCurveOnImg_Bezier_eng(retgrp, onegroupwid, onegrouphei);
		else
			drawCurveOnImg_Bezier(retgrp, onegroupwid, onegrouphei);
		int issuc=normimg(glo_img,width,height,genimg,gen_nmwid,gen_nmwid,gen_nmwid_cen,gen_nmwid_cen);

		if(!is_writing_Chi)
		{
			for(int i=0;i<gen_nmwid;i++)
				for (int j=0;j<gen_nmwid;j++)
					genimg[i*gen_nmwid+j]=genimg[i*gen_nmwid+j]>0?255:0;
		}
		if(!issuc)
		{pre_style_suc=0;pre_para_suc=0;
		delete []glo_img;
		delete []genimg;delete []genimg1;delete []genimg2;delete []genimg3;delete []genimg4;
		delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
		delete []retgrp;delete []isendstroke_ofpart;
		return 0;
		}


		memset(retimg,0,sizeof(unsigned char)*gen_nmwid*gen_nmwid);
		for(int i=0;i<gen_nmwid;i++)
			for (int j=0;j<gen_nmwid;j++)
				retimg[i*gen_nmwid+j]=genimg[i*gen_nmwid+j];
	}

	delete []glo_img;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;delete []isendstroke_ofpart;
	if(!isbatchwrite)
	{	delete []genimg;	delete []genimg1;	delete []genimg2;	delete []genimg3;delete []genimg4;
	}
	pre_style_suc=1;pre_para_suc=1;
	return 1;

}

void  add_noise(unsigned char *img,int wid,int hei,int cw,int ch)
{
	int retleft,retright,rettop,retbot;
	getLRTB(img, wid, hei,&retleft,&retright,&rettop,&retbot);

	if(glo_cur_used_sw<1)
		glo_cur_used_sw=1;
	if(glo_cur_used_sw>2)
		glo_cur_used_sw=2;

	int sj;
	int si=rettop-glo_maxdis_addnoise+rand()%(retbot-rettop+1+glo_maxdis_addnoise*2);

	if(si>=rettop&& si<=retbot)
	{	if(rand()%2==0)
	sj=retleft-glo_maxdis_addnoise+rand()%glo_maxdis_addnoise;
	else
		sj=retright+rand()%glo_maxdis_addnoise;
	}
	else
	{
		sj=retleft-glo_maxdis_addnoise+rand()%(retright-retleft+1+glo_maxdis_addnoise*2);
	}
	int ei=si+rGuassGenerate(2, 1,0, 3);
	int ej=sj+rGuassGenerate(2, 1,0, 3);

	if(rand()%2==0)//heng
	{
		ei=si+rGuassGenerate(1, 1,0, glo_cur_used_sw);
		ej=sj+rGuassGenerate(cw*0.1, cw*0.05,0, cw/5);
	}
	else//shu
	{
		ej=sj+rGuassGenerate(1, 1,0, glo_cur_used_sw);
		ei=si+rGuassGenerate(ch*0.1, ch*0.05,0, ch/5);
	}
	if(si<0)si=0;if(sj<0)sj=0;if(ei<0)ei=0;if(ej<0)ej=0;
	if(si>=hei)si=hei-1;if(ei>=hei)ei=hei-1;
	if(sj>=wid) sj=wid-1;if(ej>=wid) ej=wid-1;
	if(rand()%3==0)
	{
		for(int li=si;li<=ei;li++)
		{
			for(int lj=sj;lj<=ej;lj++)
			{
				img[li*wid+lj]=255;//curgrayval;//
			}
		}
	}
	else
	{
		for(int li=si;li<=ei;li++)
		{
			for(int lj=sj;lj<=ej;lj++)
			{
				img[li*wid+lj]=255;//curgrayval;//
			}
		}
	}
}


void  add_noise2(unsigned char *img,int wid,int hei,int cw,int ch)
{

	int *rows=new int[cw*ch];
	int *cols=new int[cw*ch];
	int cnt=0;
	for(int li=0;li<ch;li++)
	{
		for(int lj=0;lj<cw;lj++)
		{
			if(img[li*wid+lj]>0)
			{
				rows[cnt]=li;
				cols[cnt]=lj;
				cnt++;
			}
		}
	}
	if(cnt<ch)
	{delete []rows;
	delete []cols;
	return;
	}
	int idx=rand()%cnt;

	int row=rows[idx];
	int col=cols[idx];

	int rdlenrow=rand()%glo_noise2_size;
	int rdlencol=rand()%glo_noise2_size;

	for(int li=row-rdlenrow;li<=row+rdlenrow;li++)
	{
		for(int lj=col-rdlencol;lj<=col+rdlencol;lj++)
		{
			if(li<hei &&li>=0 &&lj<wid&&lj>=0)
				img[li*wid+lj]=0;
		}
	}


	delete []rows;
	delete []cols;
}
int get_charleftpos_instring(Group*leftchars,Group*curchar)
{
	int i,j;
	int curleft=leftchars->right;

	bool isinte=0;
	while(!isinte)
	{
		curleft--;
		shiftPart2_s(curchar,curleft-curchar->left,0);
		updateGrp_draw(curchar);

		for(i=0;i<leftchars->strokenum;i++)
		{
			for(j=0;j<curchar->strokenum;j++)
			{
				if(intersect3(	leftchars->strokes[i].ptscol,leftchars->strokes[i].ptsrow,
					leftchars->strokes[i].ptecol,leftchars->strokes[i].pterow,

					curchar->strokes[j].ptscol,curchar->strokes[j].ptsrow,
					curchar->strokes[j].ptecol,curchar->strokes[j].pterow))
				{
					isinte=1;
				}
				if(isinte)
					break;
			}
			if(isinte)
				break;

		}
	}
	return curleft;
}
void getEngCharTop(char *stringtowrite,int curstring_top1,int curstring_top2,int curstring_top3,int curstring_top4,int curstring_topshift,
	float wid_heipro_min_ace,float wid_heipro_max_ace,float wid_heipro_min_bdpq,float wid_heipro_max_bdpq,
	float wid_heipro_min_fg,float wid_heipro_max_fg,
	int &thischar_top,int &thischar_hei,int &thischar_wid)
{
	if(stringtowrite[0]=='a'||
		stringtowrite[0]=='c'||
		stringtowrite[0]=='e'||
		stringtowrite[0]=='n'||
		stringtowrite[0]=='o'||
		stringtowrite[0]=='r'||
		stringtowrite[0]=='s'||
		stringtowrite[0]=='t'||
		stringtowrite[0]=='u'||
		stringtowrite[0]=='v'||
		stringtowrite[0]=='x'||
		stringtowrite[0]=='z'||
		stringtowrite[0]=='i'
		)//cen
	{
		thischar_top=curstring_top2-curstring_topshift*rand()*0.5/RAND_MAX;
		int curbot=curstring_top3+curstring_topshift*rand()*0.5/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(wid_heipro_min_ace+(wid_heipro_max_ace-wid_heipro_min_ace)*rand()*1.0/RAND_MAX);
	}
	else if(stringtowrite[0]=='b'||
		stringtowrite[0]=='d'||
		stringtowrite[0]=='h'||
		stringtowrite[0]=='k'||
		stringtowrite[0]=='l'
		)//top 2
	{
		thischar_top=curstring_top1-curstring_topshift*rand()*1.5/RAND_MAX;
		int curbot=curstring_top3+curstring_topshift*rand()*1.0/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(wid_heipro_min_bdpq+(wid_heipro_max_bdpq-wid_heipro_min_bdpq)*rand()*1.0/RAND_MAX);

	}
	else if(stringtowrite[0]=='g'||
		stringtowrite[0]=='p'||
		stringtowrite[0]=='q'||
		stringtowrite[0]=='y'
		)//bot 2
	{
		thischar_top=curstring_top2-curstring_topshift*rand()*1.0/RAND_MAX;
		int curbot=curstring_top4+curstring_topshift*rand()*1.50/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		if(stringtowrite[0]=='g'||stringtowrite[0]=='y')
		{
			float oripro=glo_style_wid*1.0/glo_style_hei;
			thischar_wid=oripro*thischar_hei*(wid_heipro_min_fg+(wid_heipro_max_fg-wid_heipro_min_fg)*rand()*1.0/RAND_MAX);
		}
		else
		{
			thischar_wid=thischar_hei*(wid_heipro_min_bdpq+(wid_heipro_max_bdpq-wid_heipro_min_bdpq)*rand()*1.0/RAND_MAX);
		}
	}
	else if(stringtowrite[0]=='f'
		)//3
	{
		thischar_top=curstring_top1-curstring_topshift*rand()*1.5/RAND_MAX;
		int curbot=curstring_top4+curstring_topshift*rand()*1.5/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(wid_heipro_min_fg+(wid_heipro_max_fg-wid_heipro_min_fg)*rand()*1.0/RAND_MAX);
	}
	else if(stringtowrite[0]=='i'
		)//cen thin top for .
	{

	

		thischar_top=curstring_top2-curstring_topshift*(rand()*1.0/RAND_MAX-0.25);
		int curbot=curstring_top3+curstring_topshift*rand()*1.0/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(wid_heipro_min_ace+(wid_heipro_max_ace-wid_heipro_min_ace)*rand()*1.0/RAND_MAX);
	}
	else if(stringtowrite[0]=='j'
		)//cen thin top for .
	{
		thischar_top=curstring_top2-curstring_topshift*(rand()*1.0/RAND_MAX-0.25);
		int curbot=curstring_top4+curstring_topshift*rand()*1.50/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(wid_heipro_min_fg+(wid_heipro_max_fg-wid_heipro_min_fg)*rand()*1.0/RAND_MAX);
	}
	else if(stringtowrite[0]=='w'||stringtowrite[0]=='m'
		)//cen fat
	{
		thischar_top=curstring_top2-curstring_topshift*rand()*1.0/RAND_MAX;
		int curbot=curstring_top3+curstring_topshift*rand()*1.0/RAND_MAX;
		thischar_hei=curbot-thischar_top+1;
		thischar_wid=thischar_hei*(1+(wid_heipro_max_ace-wid_heipro_min_ace)*rand()*1.0/RAND_MAX);
	}
}
unsigned char *writeString_Chi(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val)
{ 
	glo_is_writing_Chi=1;
	glo_set_var_prob=m_slider_var_val/10.0;
	glo_set_con_prob=m_slider_con_val/10.0;
	float botmm=realGuassGenerate(1.5, 0.3,1, 2);
	float botrr=realGuassGenerate(2, 0.4,  1, 2);
	glo_tgt_left=cst_wei_left;glo_tgt_top=cst_wei_top;
	glo_tgt_right=glo_tgt_left+gen_nmwid*(botmm);
	glo_tgt_bot=glo_tgt_top+gen_nmwid*(botrr);
	glo_img=new unsigned char [maxcharnum*width*height];
	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);
	Group *retgrp=new Group;
	retgrp->strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum];
	retgrp->draw_curves=new DrawCurve[glo_maxstrokenum];
	int *isendstroke_ofpart=new int[glo_maxstrokenum*maxcharnum];
	int *isendstroke_ofpart2=new int[glo_maxstrokenum*maxcharnum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum*maxcharnum);
	memset(isendstroke_ofpart2,0,sizeof(int)*glo_maxstrokenum*maxcharnum);

	Group *allgrp=new Group;
	int base_stkidx=0;
	allgrp->strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_curves=new DrawCurve[glo_maxstrokenum*maxcharnum];

	int curstring_right=0;
	int *ijleft=new int[maxcharnum];
	int *ijtop=new int[maxcharnum];
	int *ijwid=new int[maxcharnum];
	int ijnum=0;
	int curstring_top1=gen_nmwid;
	int curstring_top2=curstring_top1+gen_nmwid/3;
	int curstring_top3=curstring_top2+gen_nmwid/3;
	int curstring_top4=curstring_top3+gen_nmwid/3;

	int curstring_topshift=gen_nmwid/3;

	float wid_heipro_min_ace=0.5;
	float wid_heipro_max_ace=1.5;

	float wid_heipro_min_bdgf=0.2;
	float wid_heipro_max_acef=1.25;

	int realcharnum=0;
	float glo_base_dis=1+gen_nmwid *rand()*0.5/RAND_MAX;
	int i=0;
	while(curstring[i]!=0)
	{
		cnt_read_style=0;
		cnt_write_style=0;
		glo_read_used_style=0;
		firstin_write=true;
		char stringtowrite[3]="";

		stringtowrite[0]=curstring[i];
		stringtowrite[1]=curstring[i+1];
		stringtowrite[2]=0;
		// i++; 
		set_para_Chi_string(0);

		bool issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		while(!issuc)
		{
			pre_style_suc=0;
			pre_para_suc=0;
			cnt_read_style=0;
			cnt_write_style=0;
			glo_read_used_style=0;
			firstin_write=true;
			issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		}
		realcharnum++;
		if(retgrp->top<=0 || retgrp->left<=0 || retgrp->bot>=width || retgrp->right>=height)
		{
			float zmprolr=(1+glo_tgt_right-glo_tgt_left)*1.0/(1+retgrp->right-retgrp->left);
			float zmprotb=(1+glo_tgt_bot-glo_tgt_top)*1.0/(1+retgrp->bot-retgrp->top);
			float smlzmpro=zmprolr<zmprotb?zmprolr:zmprotb;

			zoomPart2_s(retgrp,smlzmpro,smlzmpro,retgrp->top,retgrp->left);
			updateGrp_draw(retgrp);
			shiftPart2_s(retgrp,glo_tgt_left-retgrp->left,glo_tgt_top-retgrp->top);
			updateGrp_draw(retgrp);
		}
		int thischar_top=curstring_top1+(rand()*1.0/RAND_MAX-0.5)*curstring_topshift;
		int thischar_hei=gen_nmwid+(rand()*1.0/RAND_MAX-0.5)*curstring_topshift;
		int thischar_wid=gen_nmwid+(rand()*1.0/RAND_MAX-0.5)*curstring_topshift;

		double rotval=realGuassGenerate(0,0,-0.05,0.05);
		float curzmprolr=thischar_wid*1.0/retgrp->partition_wid;
		float curzmprotb=thischar_hei*1.0/retgrp->partition_hei;

		rotatePart3((retgrp),rotval); 
		updateGrp_draw(retgrp);
		if(retgrp->strokenum==1)
		{
			float smlpro=curzmprotb<curzmprolr?curzmprotb:curzmprolr;
			zoomPart2_s(retgrp,smlpro,smlpro,retgrp->top,retgrp->left);
		}
		else
			zoomPart2_s(retgrp,curzmprolr,curzmprotb,retgrp->top,retgrp->left);
		updateGrp_draw(retgrp);

		int thischar_left=curstring_right+(0.2+rand()*0.8/RAND_MAX)*glo_base_dis;

		shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
		updateGrp_draw(retgrp);

		curstring_right=thischar_left+retgrp->partition_wid+1;
		///////////////////////////////////////////////////


		for(int j=0;j<retgrp->strokenum;j++)
		{
			allgrp->strokes[base_stkidx+j].ptscol=retgrp->strokes[j].ptscol;
			allgrp->strokes[base_stkidx+j].ptsrow=retgrp->strokes[j].ptsrow;
			allgrp->strokes[base_stkidx+j].ptecol=retgrp->strokes[j].ptecol;
			allgrp->strokes[base_stkidx+j].pterow=retgrp->strokes[j].pterow;
			if(j<retgrp->strokenum-1 && retgrp->con_ss[j].canCut==0)
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=0;
			}
			else
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=1;
			}
			allgrp->draw_strokes[base_stkidx+j].ptscol=retgrp->draw_strokes[j].ptscol;
			allgrp->draw_strokes[base_stkidx+j].ptsrow=retgrp->draw_strokes[j].ptsrow;
			allgrp->draw_strokes[base_stkidx+j].ptecol=retgrp->draw_strokes[j].ptecol;
			allgrp->draw_strokes[base_stkidx+j].pterow=retgrp->draw_strokes[j].pterow;
			isendstroke_ofpart[base_stkidx+j]=isendstroke_ofpart2[j];
		}
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conNum=1;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conInd[1]=0;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].canCut=1;
		isendstroke_ofpart[base_stkidx+retgrp->strokenum-1]=0;
		base_stkidx+=retgrp->strokenum;	
		allgrp->strokenum=base_stkidx;
		updateGrp_draw(allgrp);
		i+=2;
		///////////////////////////////////////////////////
	}
	allgrp->strokenum=base_stkidx;
	updateGrp_draw(allgrp);

	int onegroupwid=allgrp->right-allgrp->left+1;
	int onegrouphei=allgrp->bot-allgrp->top+1;

	ck_stroke_conornot_draw(allgrp);

	int curvenum=LineToCurve_con2str(allgrp,isendstroke_ofpart);
	allgrp->curvenum=curvenum;

	unsigned char *retimg=new unsigned char [realcharnum*gen_nmwid*gen_nmwid];
	memset(retimg,0,sizeof(unsigned char)*realcharnum*gen_nmwid*gen_nmwid);

	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);

	drawCurveOnImg_Bezier(allgrp, onegroupwid, onegrouphei,maxcharnum*width,height);

	retwid=realcharnum*gen_nmwid;
	rethei=gen_nmwid;
	normimg_string(glo_img,maxcharnum*width,height,retimg,realcharnum*gen_nmwid,gen_nmwid);

	delete []glo_img;
	delete []allgrp->strokes;delete []allgrp->draw_strokes;delete []allgrp->con_ss;delete []allgrp->draw_curves;
	delete []allgrp;
	delete []isendstroke_ofpart;
	delete []isendstroke_ofpart2;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;
	delete []ijleft;delete []ijtop;delete []ijwid;
	return retimg;
}
unsigned char *writeString_Eng(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val)
{ 
	glo_is_writing_Chi=0;
	set_para_Eng_string(0);
	glo_set_var_prob=m_slider_var_val/10.0;
	glo_set_con_prob=m_slider_con_val/10.0;
	float botmm=realGuassGenerate(1.5, 0.3,1, 2);
	float botrr=realGuassGenerate(2, 0.4,  1, 2);
	glo_tgt_left=cst_wei_left;glo_tgt_top=cst_wei_top;
	glo_tgt_right=glo_tgt_left+gen_nmwid*(botmm);
	glo_tgt_bot=glo_tgt_top+gen_nmwid*(botrr);
	glo_img=new unsigned char [maxcharnum*width*height];
	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);
	Group *retgrp=new Group;
	retgrp->strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum];
	retgrp->draw_curves=new DrawCurve[glo_maxstrokenum];
	int *isendstroke_ofpart=new int[glo_maxstrokenum*maxcharnum];
	int *isendstroke_ofpart2=new int[glo_maxstrokenum*maxcharnum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum*maxcharnum);
	memset(isendstroke_ofpart2,0,sizeof(int)*glo_maxstrokenum*maxcharnum);

	Group *allgrp=new Group;
	int base_stkidx=0;
	allgrp->strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_curves=new DrawCurve[glo_maxstrokenum*maxcharnum];

	int curstring_right=0;
	int *ijleft=new int[maxcharnum];
	int *ijtop=new int[maxcharnum];
	int *ijwid=new int[maxcharnum];
	int ijnum=0;


	int curstring_top1=gen_nmwid;
	int curstring_top2=curstring_top1+gen_nmwid/3;
	int curstring_top3=curstring_top2+gen_nmwid/3;
	int curstring_top4=curstring_top3+gen_nmwid/3;

	int curstring_topshift=gen_nmwid/6;


	float wid_heipro_min_ace=0.5;
	float wid_heipro_max_ace=1.5;

	float wid_heipro_min_bdpq=0.75;
	float wid_heipro_max_bdpq=1.5;

	float wid_heipro_min_fg=1;
	float wid_heipro_max_fg=2;

	int realcharnum=0;
	float glo_base_dis=gen_nmwid/3;
	int i=0;
	int *eachchar_start=new int [maxcharnum+1];
	memset(eachchar_start,0,sizeof(int)*(maxcharnum+1));
	eachchar_start[0]=0;
	while(curstring[i]!=0)
	{
		cnt_read_style=0;
		cnt_write_style=0;
		glo_read_used_style=0;
		firstin_write=true;
		char stringtowrite[3]="";
		pre_style_suc=1;
		stringtowrite[0]=curstring[i];
		stringtowrite[1]=0;
		stringtowrite[2]=0;
		// i++; 


		bool issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		while(!issuc)
		{
			pre_style_suc=0;
			pre_para_suc=0;
			cnt_read_style=0;
			cnt_write_style=0;
			glo_read_used_style=0;
			firstin_write=true;
			issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		}
		realcharnum++;
		eachchar_start[realcharnum]=eachchar_start[realcharnum-1]+retgrp->strokenum;
		if(retgrp->top<=0 || retgrp->left<=0 || retgrp->bot>=width || retgrp->right>=height)
		{
			float zmprolr=(1+glo_tgt_right-glo_tgt_left)*1.0/(1+retgrp->right-retgrp->left);
			float zmprotb=(1+glo_tgt_bot-glo_tgt_top)*1.0/(1+retgrp->bot-retgrp->top);
			float smlzmpro=zmprolr<zmprotb?zmprolr:zmprotb;

			zoomPart2_s(retgrp,smlzmpro,smlzmpro,retgrp->top,retgrp->left);
			updateGrp_draw(retgrp);
			shiftPart2_s(retgrp,glo_tgt_left-retgrp->left,glo_tgt_top-retgrp->top);
			updateGrp_draw(retgrp);
		}
		int thischar_top,thischar_hei,thischar_wid;

		getEngCharTop(stringtowrite,curstring_top1,curstring_top2,curstring_top3,curstring_top4,curstring_topshift,
			wid_heipro_min_ace,wid_heipro_max_ace,wid_heipro_min_bdpq,wid_heipro_max_bdpq,wid_heipro_min_fg,wid_heipro_max_fg,
			thischar_top,thischar_hei,thischar_wid);
		/*if(stringtowrite[0]=='i'||stringtowrite[0]=='l')
		{
			thischar_wid=thischar_hei*(retgrp->partition_wid*1./retgrp->partition_hei);
		}*/
		double rotval=realGuassGenerate(0,0,-0.05,0.05);
		float curzmprolr=thischar_wid*1.0/retgrp->partition_wid;
		float curzmprotb=thischar_hei*1.0/retgrp->partition_hei;

		rotatePart3((retgrp),rotval); 
		updateGrp_draw(retgrp);
		if(retgrp->strokenum==1)
		{
			float smlpro=curzmprotb<curzmprolr?curzmprotb:curzmprolr;
			zoomPart2_s(retgrp,smlpro,smlpro,retgrp->top,retgrp->left);
		}
		else
			zoomPart2_s(retgrp,curzmprolr,curzmprotb,retgrp->top,retgrp->left);
		updateGrp_draw(retgrp);

		int thischar_left=curstring_right;

		shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
		updateGrp_draw(retgrp);
		if(realcharnum>1)
		{	
			if(curstring[i]=='g' ||curstring[i]=='f' ||curstring[i]=='j' ||curstring[i]=='y' ||curstring[i-1]=='f' )
			{
				thischar_left=get_charleftpos_instring(allgrp,retgrp)+(0.2+rand()*1.0/RAND_MAX)*glo_base_dis;
				shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
				updateGrp_draw(retgrp);
			}
			else if(curstring[i-1]=='i'||curstring[i-1]=='l' )
			{
				/*thischar_left=curstring_right+(0.5+rand()*1.0/RAND_MAX)*glo_base_dis;
				shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
				updateGrp_draw(retgrp);*/
			}
		}

		curstring_right=thischar_left+retgrp->partition_wid+1;
		///////////////////////////////////////////////////

		if(stringtowrite[0]=='i'||stringtowrite[0]=='j')
		{
			ijtop[ijnum]=thischar_top;
			ijleft[ijnum]=thischar_left;
			ijwid[ijnum]=retgrp->partition_wid;
			ijnum++;
		}

		for(int j=0;j<retgrp->strokenum;j++)
		{
			allgrp->strokes[base_stkidx+j].ptscol=retgrp->strokes[j].ptscol;
			allgrp->strokes[base_stkidx+j].ptsrow=retgrp->strokes[j].ptsrow;
			allgrp->strokes[base_stkidx+j].ptecol=retgrp->strokes[j].ptecol;
			allgrp->strokes[base_stkidx+j].pterow=retgrp->strokes[j].pterow;
			if(j<retgrp->strokenum-1 && retgrp->con_ss[j].canCut==0)
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=0;
			}
			else
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=1;
			}
			allgrp->draw_strokes[base_stkidx+j].ptscol=retgrp->draw_strokes[j].ptscol;
			allgrp->draw_strokes[base_stkidx+j].ptsrow=retgrp->draw_strokes[j].ptsrow;
			allgrp->draw_strokes[base_stkidx+j].ptecol=retgrp->draw_strokes[j].ptecol;
			allgrp->draw_strokes[base_stkidx+j].pterow=retgrp->draw_strokes[j].pterow;
			isendstroke_ofpart[base_stkidx+j]=isendstroke_ofpart2[j];
		}
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conNum=1;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conInd[1]=0;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].canCut=1;
		isendstroke_ofpart[base_stkidx+retgrp->strokenum-1]=0;
		base_stkidx+=retgrp->strokenum;	
		allgrp->strokenum=base_stkidx;
		updateGrp_draw(allgrp);
		i++;
		///////////////////////////////////////////////////
	}
	allgrp->strokenum=base_stkidx;
	updateGrp_draw(allgrp);



	if(ijnum>0)
		add_ij_dot(allgrp,ijleft,ijtop,ijwid,curstring_topshift,ijnum,isendstroke_ofpart);

	

	float cuoqiexang=realGuassGenerate(0,1,-0.3,0.8);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	float cuoqieyang=realGuassGenerate(0,1,-0.2,0.2);
	updateGrp_draw((allgrp));
	cuoqie_x(allgrp,cuoqiexang);
	updateGrp_draw((allgrp));
	cuoqie_y(allgrp,cuoqieyang);
	updateGrp_draw((allgrp));
	
	shiftPart2((allgrp),0-allgrp->left,0-allgrp->top);
	updateGrp_draw((allgrp));

	int onegroupwid=allgrp->right-allgrp->left+1;
	int onegrouphei=allgrp->bot-allgrp->top+1;

	ck_stroke_conornot_draw(allgrp);

	int curvenum=LineToCurve_con2str(allgrp,isendstroke_ofpart);
	allgrp->curvenum=curvenum;

	unsigned char *retimg=new unsigned char [realcharnum*gen_nmwid*gen_nmwid];
	memset(retimg,0,sizeof(unsigned char)*realcharnum*gen_nmwid*gen_nmwid);

	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);

	drawCurveOnImg_Bezier_eng(allgrp, onegroupwid, onegrouphei,maxcharnum*width,height);


	retwid=realcharnum*gen_nmwid;
	rethei=gen_nmwid;
	normimg_string(glo_img,maxcharnum*width,height,retimg,realcharnum*gen_nmwid,gen_nmwid);

	delete []glo_img;
	delete []allgrp->strokes;delete []allgrp->draw_strokes;delete []allgrp->con_ss;delete []allgrp->draw_curves;
	delete []allgrp;
	delete []isendstroke_ofpart;
	delete []isendstroke_ofpart2;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;
	delete []ijleft;delete []ijtop;delete []ijwid;
	return retimg;
}
void add_ij_dot(Group*allgrp,int *ijleft,int *ijtop,int *ijwid,int charhei,int ijnum,int *isendstroke_ofpart)
{
	int i;
	int base_stkidx=allgrp->strokenum;
	Group *retgrp=new Group;
	retgrp->strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum];
	retgrp->draw_curves=new DrawCurve[glo_maxstrokenum];
	int *isendstroke_ofpart2=new int[3];
	memset(isendstroke_ofpart2,0,sizeof(int)*3);
	isendstroke_ofpart[base_stkidx-1]=-1;
	for(i=0;i<ijnum;i++)
	{
		cnt_read_style=0;
		cnt_write_style=0;
		pre_style_suc=1;
		glo_read_used_style=0;
		firstin_write=true;
		set_para_Eng_string(0);

		bool issuc= writePart3(0,".",glo_tgt_left,glo_tgt_top,glo_tgt_left+20,glo_tgt_top+20,retgrp,isendstroke_ofpart2,1);
		int thischar_top=ijtop[i]-charhei*(0.2+rand()*1.0/RAND_MAX);
		int thischar_left=ijleft[i]-ijwid[i]*(rand()*0.5/RAND_MAX-0.25);

		int thischar_hei=(ijtop[i]-thischar_top)*(rand()*1.0/RAND_MAX);	
		int thischar_wid=(ijwid[i])*(rand()*1.25/RAND_MAX);

		float curzmprolr=thischar_wid*1.0/retgrp->partition_wid;
		float curzmprotb=thischar_hei*1.0/retgrp->partition_hei;	
		float smlpro=curzmprotb<curzmprolr?curzmprotb:curzmprolr;
		zoomPart2_s(retgrp,smlpro,smlpro,retgrp->top,retgrp->left);		
		updateGrp_draw(retgrp);


		shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
		updateGrp_draw(retgrp);

		allgrp->strokes[base_stkidx+i].ptscol=retgrp->strokes[0].ptscol;
		allgrp->strokes[base_stkidx+i].ptsrow=retgrp->strokes[0].ptsrow;
		allgrp->strokes[base_stkidx+i].ptecol=retgrp->strokes[0].ptecol;
		allgrp->strokes[base_stkidx+i].pterow=retgrp->strokes[0].pterow;
		allgrp->con_ss[base_stkidx+i].conNum=1;
		allgrp->con_ss[base_stkidx+i].conInd[1]=base_stkidx+i+1;
		allgrp->con_ss[base_stkidx+i].canCut=1;

		allgrp->draw_strokes[base_stkidx+i].ptscol=retgrp->draw_strokes[0].ptscol;
		allgrp->draw_strokes[base_stkidx+i].ptsrow=retgrp->draw_strokes[0].ptsrow;
		allgrp->draw_strokes[base_stkidx+i].ptecol=retgrp->draw_strokes[0].ptecol;
		allgrp->draw_strokes[base_stkidx+i].pterow=retgrp->draw_strokes[0].pterow;
		isendstroke_ofpart[base_stkidx+i]=-2;
	}
	allgrp->strokenum=base_stkidx+ijnum;
	updateGrp_draw(allgrp);

	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;delete []isendstroke_ofpart2;
}


void rotatePart_eachchar(Group *curgrp,double rotval,int *eachchar_start,int charnum)
{
	for(int chidx=0;chidx<charnum;chidx++)
	{
		int ssind=0;
		int cencol_d=0,cenrow_d=0,cencol2_d=0,cenrow2_d=0;

		for(ssind=eachchar_start[chidx];ssind<eachchar_start[chidx+1];ssind++)
		{		

			cencol_d+=curgrp->draw_strokes[ssind].ptscol;
			cencol_d+=curgrp->draw_strokes[ssind].ptecol;
			cenrow_d+=curgrp->draw_strokes[ssind].ptsrow;
			cenrow_d+=curgrp->draw_strokes[ssind].pterow;
		}

		if(cencol_d>0||cenrow_d>0)
		{

			cencol_d/=(eachchar_start[chidx+1]-eachchar_start[chidx]);
			cenrow_d/=(eachchar_start[chidx+1]-eachchar_start[chidx]);
			cencol_d/=2;cenrow_d/=2;
		}

		if(cencol_d>0||cenrow_d>0)
		{

			int retx,rety;

			for(ssind=eachchar_start[chidx];ssind<eachchar_start[chidx+1];ssind++)
			{
				rotate_point(curgrp->draw_strokes[ssind].ptscol,curgrp->draw_strokes[ssind].ptsrow,cencol_d,cenrow_d,retx,rety,rotval);
				curgrp->draw_strokes[ssind].ptscol=retx;curgrp->draw_strokes[ssind].ptsrow=rety;

				rotate_point(curgrp->draw_strokes[ssind].ptecol,curgrp->draw_strokes[ssind].pterow,cencol_d,cenrow_d,retx,rety,rotval);
				curgrp->draw_strokes[ssind].ptecol=retx;curgrp->draw_strokes[ssind].pterow=rety;
			}
		}

	}
}
unsigned char *writeString(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val)
{ 
	glo_is_writing_Chi=1;
	glo_set_var_prob=m_slider_var_val/10.0;
	glo_set_con_prob=m_slider_con_val/10.0;
	float botmm=realGuassGenerate(1.5, 0.3,1, 2);
	float botrr=realGuassGenerate(2, 0.4,  1, 2);
	glo_tgt_left=cst_wei_left;glo_tgt_top=cst_wei_top;
	glo_tgt_right=glo_tgt_left+gen_nmwid*(botmm);
	glo_tgt_bot=glo_tgt_top+gen_nmwid*(botrr);
	glo_img=new unsigned char [maxcharnum*width*height];
	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);
	Group *retgrp=new Group;
	retgrp->strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	retgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum];
	retgrp->draw_curves=new DrawCurve[glo_maxstrokenum];
	int *isendstroke_ofpart=new int[glo_maxstrokenum*maxcharnum];
	int *isendstroke_ofpart2=new int[glo_maxstrokenum*maxcharnum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum*maxcharnum);
	memset(isendstroke_ofpart2,0,sizeof(int)*glo_maxstrokenum*maxcharnum);

	Group *allgrp=new Group;
	int base_stkidx=0;
	allgrp->strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_strokes=new StrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->con_ss=new ConnectStrokeSyntax[glo_maxstrokenum*maxcharnum];
	allgrp->draw_curves=new DrawCurve[glo_maxstrokenum*maxcharnum];

	int curstring_right=0;
	int curstring_cenrow=height/2;
	int realcharnum=0;
	float glo_base_dis=1+gen_nmwid *rand()*1.0/RAND_MAX;
	int i=0;
	while(curstring[i]!=0)
	{
		cnt_read_style=0;
		cnt_write_style=0;
		glo_read_used_style=0;
		firstin_write=true;
		char stringtowrite[3]="";
		if(curstring[i]>0)//ascii
		{
			stringtowrite[0]=curstring[i];
			stringtowrite[1]=0;
			stringtowrite[2]=0;
			i++;
			if(pre_para_suc)
			{
				glo_pre_para=rand()*1.0/RAND_MAX;
				set_para_Eng_string(glo_pre_para);
			}
			else
			{
				set_para_Eng_string(glo_pre_para);
			}

		}
		else//Chinese
		{
			stringtowrite[0]=curstring[i];
			stringtowrite[1]=curstring[i+1];
			stringtowrite[2]=0;
			i+=2;
			if(pre_para_suc)
			{
				glo_pre_para=rand()*1.0/RAND_MAX;
				set_para_Chi(glo_pre_para);
			}
			else
			{
				set_para_Chi(glo_pre_para);
			}
		}
		bool issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		while(!issuc)
		{
			pre_style_suc=0;
			pre_para_suc=0;
			cnt_read_style=0;
			cnt_write_style=0;
			glo_read_used_style=0;
			firstin_write=true;
			issuc= writePart3(0,stringtowrite,glo_tgt_left,glo_tgt_top,glo_tgt_right,glo_tgt_bot,retgrp,isendstroke_ofpart2,1);
		}
		realcharnum++;
		if(retgrp->top<=0 || retgrp->left<=0 || retgrp->bot>=width || retgrp->right>=height)
		{
			float zmprolr=(1+glo_tgt_right-glo_tgt_left)*1.0/(1+retgrp->right-retgrp->left);
			float zmprotb=(1+glo_tgt_bot-glo_tgt_top)*1.0/(1+retgrp->bot-retgrp->top);
			float smlzmpro=zmprolr<zmprotb?zmprolr:zmprotb;

			zoomPart2_s(retgrp,smlzmpro,smlzmpro,retgrp->top,retgrp->left);
			updateGrp_draw(retgrp);
			shiftPart2_s(retgrp,glo_tgt_left-retgrp->left,glo_tgt_top-retgrp->top);
			updateGrp_draw(retgrp);
		}
		double rotval=realGuassGenerate(0,0,-0.05,0.05);
		float curzmprolr=realGuassGenerate(0,0,0.95,1.1);
		float curzmprotb=realGuassGenerate(0,0,0.95,1.1);

		rotatePart3((retgrp),rotval); 
		updateGrp_draw(retgrp);
		if(retgrp->strokenum==1)
			zoomPart2_s(retgrp,curzmprolr,curzmprolr,retgrp->top,retgrp->left);
		else
			zoomPart2_s(retgrp,curzmprolr,curzmprotb,retgrp->top,retgrp->left);
		updateGrp_draw(retgrp);

		int thischar_left=curstring_right+(0.5+rand()*0.5/RAND_MAX)*glo_base_dis;
		int thischar_top=curstring_cenrow-retgrp->partition_hei/2+0.2*(0.5-rand()*1.0/RAND_MAX)*retgrp->partition_hei;

		shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
		updateGrp_draw(retgrp);

		thischar_left=get_charleftpos_instring(allgrp,retgrp);

		shiftPart2_s(retgrp,thischar_left-retgrp->left,thischar_top-retgrp->top);
		updateGrp_draw(retgrp);

		curstring_right=thischar_left+retgrp->partition_wid+1;
		///////////////////////////////////////////////////



		for(int j=0;j<retgrp->strokenum;j++)
		{
			allgrp->strokes[base_stkidx+j].ptscol=retgrp->strokes[j].ptscol;
			allgrp->strokes[base_stkidx+j].ptsrow=retgrp->strokes[j].ptsrow;
			allgrp->strokes[base_stkidx+j].ptecol=retgrp->strokes[j].ptecol;
			allgrp->strokes[base_stkidx+j].pterow=retgrp->strokes[j].pterow;
			if(j<retgrp->strokenum-1 && retgrp->con_ss[j].canCut==0)
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=0;
			}
			else
			{
				allgrp->con_ss[base_stkidx+j].conNum=1;
				allgrp->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				allgrp->con_ss[base_stkidx+j].canCut=1;
			}
			allgrp->draw_strokes[base_stkidx+j].ptscol=retgrp->draw_strokes[j].ptscol;
			allgrp->draw_strokes[base_stkidx+j].ptsrow=retgrp->draw_strokes[j].ptsrow;
			allgrp->draw_strokes[base_stkidx+j].ptecol=retgrp->draw_strokes[j].ptecol;
			allgrp->draw_strokes[base_stkidx+j].pterow=retgrp->draw_strokes[j].pterow;
			isendstroke_ofpart[base_stkidx+j]=isendstroke_ofpart2[j]>0?1:0;
		}
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conNum=1;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].conInd[1]=0;
		allgrp->con_ss[base_stkidx+retgrp->strokenum-1].canCut=1;
		isendstroke_ofpart[base_stkidx+retgrp->strokenum-1]=2;
		base_stkidx+=retgrp->strokenum;	
		///////////////////////////////////////////////////
	}
	allgrp->strokenum=base_stkidx;

	updateGrp_draw(allgrp);
	int onegroupwid=allgrp->right-allgrp->left+1;
	int onegrouphei=allgrp->bot-allgrp->top+1;

	ck_stroke_conornot_draw(allgrp);
	int curvenum=LineToCurve_con2str(allgrp,isendstroke_ofpart);
	allgrp->curvenum=curvenum;

	unsigned char *retimg=new unsigned char [realcharnum*gen_nmwid*gen_nmwid];
	memset(retimg,0,sizeof(unsigned char)*realcharnum*gen_nmwid*gen_nmwid);

	memset(glo_img,0,sizeof(unsigned char)*maxcharnum*width*height);

	drawCurveOnImg_Bezier(allgrp, onegroupwid, onegrouphei,maxcharnum*width,height);

	retwid=realcharnum*gen_nmwid;
	rethei=gen_nmwid;
	normimg_string(glo_img,maxcharnum*width,height,retimg,realcharnum*gen_nmwid,gen_nmwid);

	delete []glo_img;
	delete []allgrp->strokes;delete []allgrp->draw_strokes;delete []allgrp->con_ss;delete []allgrp->draw_curves;
	delete []allgrp;
	delete []isendstroke_ofpart;
	delete []isendstroke_ofpart2;
	delete []retgrp->strokes;delete []retgrp->draw_strokes;delete []retgrp->con_ss;delete []retgrp->draw_curves;
	delete []retgrp;

	return retimg;
}
//ang is conresponding to y-axis
void cuoqie_x(unsigned char *img,int width,int height,float ang)
{
	int i,j;
	float ta=tan(ang);
	int maxdis=abs(height*ta);
	int newwid=maxdis+width;
	unsigned char *cpimg=new unsigned char[newwid*height];
	memset(cpimg,0,sizeof(unsigned char)*newwid*height);
	if(ta>0)
	{
		for(int i=0;i<height;i++)
		{
			for(int j=0;j<width;j++)
			{
				cpimg[i*newwid+j]=img[i*width+j];
			}
		}

	}else
	{
		for(int i=0;i<height;i++)
		{
			for(int j=newwid-width;j<newwid;j++)
			{
				cpimg[i*newwid+j]=img[i*width+j-newwid+width];
			}
		}
	}
	for( i=0;i<height;i++)
	{
		int shiftdis=(height-1-i)*ta;
		if(shiftdis>0)
		{
			for( j=newwid-shiftdis-1;j>=0;j--)
			{
				cpimg[i*newwid+j+shiftdis]=cpimg[i*newwid+j];
			}
			for(j=0;j<shiftdis;j++)
				cpimg[i*newwid+j]=0;
		}
		else
		{
			for( j=-shiftdis;j<newwid;j++)
			{
				cpimg[i*newwid+j+shiftdis]=cpimg[i*newwid+j];
			}
			for(j=newwid+shiftdis;j<newwid;j++)
				cpimg[i*newwid+j]=0;
		}
	}
	zoom_smth(cpimg,newwid,height,img,width,height);
	delete []cpimg;
}
//ang is conresponding to x-axis
void cuoqie_y(unsigned char *img,int width,int height,float ang)
{
	int i,j;
	float ta=tan(ang);
	int maxdis=abs(width*ta);
	int newhei=maxdis+height;
	unsigned char *cpimg=new unsigned char[width*newhei];
	memset(cpimg,0,sizeof(unsigned char)*width*newhei);
	if(ta>0)
	{
		for(int i=0;i<height;i++)
		{
			for(int j=0;j<width;j++)
			{
				cpimg[i*width+j]=img[i*width+j];
			}
		}

	}else
	{
		for(int i=newhei-height;i<newhei;i++)
		{
			for(int j=0;j<width;j++)
			{
				cpimg[i*width+j]=img[(i-newhei+height)*width+j];
			}
		}
	}
	for( j=0;j<width;j++)
	{
		int shiftdis=(width-1-j)*ta;
		if(shiftdis>0)
		{
			for( i=newhei-shiftdis-1;i>=0;i--)
			{
				cpimg[(i+shiftdis)*width+j]=cpimg[i*width+j];
			}
			for(i=0;i<shiftdis;i++)
				cpimg[i*width+j]=0;
		}
		else
		{
			for( i=-shiftdis;i<newhei;i++)
			{
				cpimg[(i+shiftdis)*width+j]=cpimg[i*width+j];
			}
			for(i=newhei+shiftdis;i<newhei;i++)
				cpimg[i*width+j]=0;
		}
	}
	zoom_smth(cpimg,width,newhei,img,width,height);
	delete []cpimg;
}
//return value: strokenum
void maxvalto255(unsigned char *img,int width,int height)
{
	int i,j;
	int maxval=0;
	int meanv=0;
	int cnt=0;
	for( i=0;i<height;i++)
	{
		for( j=0;j<width;j++)
		{

			if(img[i*width+j]>maxval)
				maxval=img[i*width+j];
		}
	}
	int addv=255-maxval;
	for( i=0;i<height;i++)
	{
		for( j=0;j<width;j++)
		{
			if(img[i*width+j]>0)
				img[i*width+j]+=addv;
		}
	}
}

void initGrp_relationship(Group*&grp,int len)
{
	memset(grp->ptind_left_worh,0,sizeof(float)*len);
	memset(grp->ptind_left_worh_self,0,sizeof(float)*len);
	memset(grp->ptind_left_dis,0,sizeof(float)*len);
	memset(grp->ptind_left_wei_self,0,sizeof(float)*len);
	memset(grp->ptind_left_wei,0,sizeof(float)*len);
	memset(grp->ptind_right_worh,0,sizeof(float)*len);
	memset(grp->ptind_right_worh_self,0,sizeof(float)*len);
	memset(grp->ptind_right_dis,0,sizeof(float)*len);
	memset(grp->ptind_right_wei_self,0,sizeof(float)*len);
	memset(grp->ptind_right_wei,0,sizeof(float)*len);
	memset(grp->ptind_top_worh,0,sizeof(float)*len);
	memset(grp->ptind_top_worh_self,0,sizeof(float)*len);
	memset(grp->ptind_top_dis,0,sizeof(float)*len);
	memset(grp->ptind_top_wei_self,0,sizeof(float)*len);
	memset(grp->ptind_top_wei,0,sizeof(float)*len);
	memset(grp->ptind_bot_worh,0,sizeof(float)*len);
	memset(grp->ptind_bot_worh_self,0,sizeof(float)*len);
	memset(grp->ptind_bot_dis,0,sizeof(float)*len);
	memset(grp->ptind_bot_wei_self,0,sizeof(float)*len);
	memset(grp->ptind_bot_wei,0,sizeof(float)*len);
}


bool writePart3(int instyleidx,char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,int *retisendstroke_ofpart,int part_lvl)
{

	char numfilename[1024]="";
	sprintf(numfilename,"%s\\%s\\%s_num.txt",rootpath,glo_learnresultpath,hanziname);
	FILE *fp=fopen(numfilename,"r");
	int isusedpart,stylenum;
	fscanf(fp,"%d",&stylenum);
	fclose(fp);
	int curstyleidx;
	if(firstin_write)
	{	
		if(!pre_style_suc)
			curstyleidx=glo_style;
		else
		{
			curstyleidx=1+rand()%(stylenum-1);
			glo_style=curstyleidx;
		}
	//	curstyleidx=instyleidx;
		int tmp;
		sprintf(numfilename,"%s\\%s\\%s_%d.txt",rootpath,glo_learnresultpath,hanziname,curstyleidx);
		fp=fopen(numfilename,"r");
		int ispart;
		fscanf(fp,"%d%d",&ispart,&(tmp));
		int curleft,curtop,curright,curbot;
		char curpartname[1024];
		int minleft=100000,maxright=-100000,mintop=1000000,maxbot=-100000;
		for(int jjj=0;jjj<tmp;jjj++)
		{
			fscanf(fp,"%d%d%d%d%s",&curleft,&curtop,&curright,&curbot,curpartname);
			if(curleft<minleft)minleft=curleft;
			if(curright<minleft)minleft=curright;
			if(curleft>maxright)maxright=curleft;
			if(curright>maxright)maxright=curright;

			if(curtop<mintop)mintop=curtop;
			if(curbot<mintop)mintop=curbot;
			if(curtop>maxbot)maxbot=curtop;
			if(curbot>maxbot)maxbot=curbot;

		}
		float tempwid=maxright-minleft+1;
		float temphei=maxbot-mintop+1;

		glo_style_wid=tempwid;
		glo_style_hei=temphei;
		/*if(tempwid<temphei && ((tgtright-tgtleft+1)>(tgtbot-tgttop+1) || (tgtright-tgtleft+1)*1.0/(tgtbot-tgttop+1)>4*tempwid/temphei))
		{
		tgtright=tgtleft+(tgtright-tgtleft+1)*(tempwid/temphei);
		}*/
		float rdv1=(1+glo_firstin_widpro*rand()*1.0/RAND_MAX);
		float rdv2=(1+glo_firstin_heipro*rand()*1.0/RAND_MAX);


		tgtright=tgtleft+tempwid*rdv1-1;//0513
		tgtbot=tgttop+temphei*rdv2-1;


		if(tgtright-tgtleft>tgtbot-tgttop)
		{
			tgtbot=tgttop+gen_nmwid*(tgtbot-tgttop+1)*1.0/(tgtright-tgtleft+1);
			tgtright=tgtleft+gen_nmwid;

		}
		else
		{
			tgtright=tgtleft+gen_nmwid*(tgtright-tgtleft+1)*1.0/(tgtbot-tgttop+1);
			tgtbot=tgttop+gen_nmwid;

		}

		fclose(fp);

		glo_tgt_left=tgtleft;
		glo_tgt_top=tgttop;

		glo_tgt_right=tgtright;
		glo_tgt_bot=tgtbot;


	}
	else
	{	
		curstyleidx=readpart_style[cnt_write_style];
		cnt_write_style++;
		glo_read_used_style=cnt_write_style;

	}

	int allstrokenum=0,allgroupnum=0;
	Group* allgroup,*onegroup,*tmpgroup;
	sprintf(numfilename,"%s\\%s\\%s_%d.txt",rootpath,glo_learnresultpath,hanziname,curstyleidx);
	fp=fopen(numfilename,"r");
	int ispart;
	fscanf(fp,"%d%d",&ispart,&(allgroupnum));
	allgroup=new Group[allgroupnum];
	int i,j;
	for( i=0;i<allgroupnum;i++)
	{
		initgrp(&(allgroup[i]));
		allgroup[i].strokes     =new StrokeSyntax[glo_maxstrokenum];
		allgroup[i].draw_strokes     =new StrokeSyntax[glo_maxstrokenum];
		allgroup[i].con_ss     =new ConnectStrokeSyntax[glo_maxstrokenum];
		allgroup[i].draw_curves     =new DrawCurve[glo_maxstrokenum];
	}
	int *isendstroke_ofpart=new int[glo_maxstrokenum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum);
	onegroup=new Group;
	initgrp(onegroup);
	onegroup->strokes     =new StrokeSyntax[glo_maxstrokenum];
	onegroup->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	onegroup->con_ss      =new ConnectStrokeSyntax[glo_maxstrokenum];
	onegroup->draw_curves =new DrawCurve[glo_maxstrokenum];
	onegroup->ptind_left=new int[2*glo_maxstrokenum];//
	onegroup->ptind_right=new int[2*glo_maxstrokenum];//
	onegroup->ptind_top=new int[2*glo_maxstrokenum];//
	onegroup->ptind_bot=new int[2*glo_maxstrokenum];//			
	onegroup->ptind_left_grpidx=new int[2*glo_maxstrokenum];//
	onegroup->ptind_right_grpidx=new int[2*glo_maxstrokenum];//
	onegroup->ptind_top_grpidx=new int[2*glo_maxstrokenum];//
	onegroup->ptind_bot_grpidx=new int[2*glo_maxstrokenum];//			
	onegroup->ptind_left_wei_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_right_wei_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_top_wei_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_bot_wei_self=new float[2*glo_maxstrokenum];//			
	onegroup->ptind_left_wei=new float[2*glo_maxstrokenum];//
	onegroup->ptind_right_wei=new float[2*glo_maxstrokenum];//
	onegroup->ptind_top_wei=new float[2*glo_maxstrokenum];//
	onegroup->ptind_bot_wei=new float[2*glo_maxstrokenum];//

	onegroup->ptind_left_worh=new float[2*glo_maxstrokenum];//
	onegroup->ptind_right_worh=new float[2*glo_maxstrokenum];//
	onegroup->ptind_top_worh=new float[2*glo_maxstrokenum];//
	onegroup->ptind_bot_worh=new float[2*glo_maxstrokenum];//

	onegroup->ptind_left_worh_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_right_worh_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_top_worh_self=new float[2*glo_maxstrokenum];//
	onegroup->ptind_bot_worh_self=new float[2*glo_maxstrokenum];//

	onegroup->ptind_left_dis=new float[2*glo_maxstrokenum];//
	onegroup->ptind_right_dis=new float[2*glo_maxstrokenum];//
	onegroup->ptind_top_dis=new float[2*glo_maxstrokenum];//
	onegroup->ptind_bot_dis=new float[2*glo_maxstrokenum];//

	initGrp_relationship(onegroup,2*glo_maxstrokenum);
	tmpgroup=new Group;
	initgrp(tmpgroup);
	tmpgroup->strokes     =new StrokeSyntax[glo_maxstrokenum];
	tmpgroup->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	tmpgroup->con_ss      =new ConnectStrokeSyntax[glo_maxstrokenum];
	tmpgroup->draw_curves =new DrawCurve[glo_maxstrokenum];
	tmpgroup->ptind_left=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_right=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_top=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot=new int[2*glo_maxstrokenum];//			
	tmpgroup->ptind_left_grpidx=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_grpidx=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_grpidx=new int[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_grpidx=new int[2*glo_maxstrokenum];//			
	tmpgroup->ptind_left_wei_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_wei_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_wei_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_wei_self=new float[2*glo_maxstrokenum];//			
	tmpgroup->ptind_left_wei=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_wei=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_wei=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_wei=new float[2*glo_maxstrokenum];//


	tmpgroup->ptind_left_worh=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_worh=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_worh=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_worh=new float[2*glo_maxstrokenum];//

	tmpgroup->ptind_left_worh_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_worh_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_worh_self=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_worh_self=new float[2*glo_maxstrokenum];//

	tmpgroup->ptind_left_dis=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_right_dis=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_top_dis=new float[2*glo_maxstrokenum];//
	tmpgroup->ptind_bot_dis=new float[2*glo_maxstrokenum];//

	initGrp_relationship(tmpgroup,2*glo_maxstrokenum);
	int cntgrplvl1=0;
	int curleft,curtop,curright,curbot;
	char curpartname[1024]="";
	if(ispart)
	{
		fscanf(fp,"%d%d%d%d%s",&curleft,&curtop,&curright,&curbot,curpartname);
		sprintf(allgroup[0].grpname,"%s",curpartname);

		bool issuc=readPart(curpartname,curleft,curtop,curright,curbot,onegroup,isendstroke_ofpart,part_lvl+1);
		sprintf(onegroup->grpname,"%s",curpartname);
		if(issuc)
		{
			Group *ttt=&(allgroup[0]);
			copyGrp(onegroup,ttt);
			for(int iii=0;iii<onegroup->strokenum;iii++)
				retisendstroke_ofpart[allstrokenum+iii]=isendstroke_ofpart[iii];
			retisendstroke_ofpart[allstrokenum+onegroup->strokenum-1]=part_lvl;
		}else
		{
			ReleaseGrammer4(allgroup,allgroupnum);
			ReleaseGrammer1(tmpgroup);ReleaseGrammer1(onegroup);
			delete []isendstroke_ofpart;
			fclose(fp);
			return 0;
		}
		allstrokenum+=allgroup[0].strokenum;
		i=1;
		while(issuc && i<allgroupnum)
		{
			fscanf(fp,"%d%d%d%d%s",	&curleft,&curtop,&curright,&curbot,curpartname);

			sprintf(allgroup[i].grpname,"%s",curpartname);
			sprintf(onegroup->grpname,"%s",curpartname);

			issuc=readPart(curpartname,curleft,curtop,curright,curbot,onegroup,isendstroke_ofpart,part_lvl+1);
			sprintf(onegroup->grpname,"%s",curpartname);

			if(issuc)
			{
				Group *ttt=&(allgroup[i]);
				copyGrp(onegroup,ttt);
				for(int iii=0;iii<onegroup->strokenum;iii++)
					retisendstroke_ofpart[allstrokenum+iii]=isendstroke_ofpart[iii];
				retisendstroke_ofpart[allstrokenum+onegroup->strokenum-1]=part_lvl;
			}
			else
			{
				ReleaseGrammer4(allgroup,allgroupnum);
				ReleaseGrammer1(tmpgroup);ReleaseGrammer1(onegroup);
				delete []isendstroke_ofpart;
				fclose(fp);
				return 0;
			}
			allstrokenum+=allgroup[i].strokenum;
			i++;
		}
		fclose(fp);


		for(i=0;i<allgroupnum;i++)
		{	
			allgroup[i].ptind_left=new int[2*allstrokenum];//
			allgroup[i].ptind_right=new int[2*allstrokenum];//
			allgroup[i].ptind_top=new int[2*allstrokenum];//
			allgroup[i].ptind_bot=new int[2*allstrokenum];//

			allgroup[i].ptind_left_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_right_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_top_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_bot_grpidx=new int[2*allstrokenum];//

			allgroup[i].ptind_left_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_right_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_top_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_wei_self=new float[2*allstrokenum];//

			allgroup[i].ptind_left_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_right_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_top_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_wei=new float[2*allstrokenum];//



			allgroup[i].ptind_left_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_right_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_top_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_worh=new float[2*allstrokenum];//

			allgroup[i].ptind_left_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_right_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_top_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_worh_self=new float[2*allstrokenum];//

			allgroup[i].ptind_left_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_right_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_top_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_dis=new float[2*allstrokenum];//
			Group*ttt=&(allgroup[i]);
			initGrp_relationship(ttt,2*allstrokenum);

		}
		//cal_grouplrtb(allgroup,allgroupnum);	
		int kkkk;
		for( kkkk=0;kkkk<allgroupnum;kkkk++)
		{
			updateGrp_draw(&(allgroup[kkkk]));
		}	
		group_relationship_big(allgroup,allgroupnum);
		int is_swap_2grp=0;
		if(allgroupnum==2&&(allgroup[0].strokenum>1 ||allgroup[1].strokenum>1)&&(allgroup[1].ptind_bot_num==0||allgroup[1].ptind_top_num==0||allgroup[1].ptind_right_num==0||allgroup[1].ptind_left_num==0))
		{
			int cpreadpartstyle[1000];
			int cpreadpartstartidx[1000];
			int cpreadpartendidx[1000];
			int cntcp=0;
			for(int cidx=0;cidx<readpart_startidx[cnt_write_style];cidx++)
			{
				cpreadpartstyle[cntcp]=readpart_style[cntcp];
				cpreadpartstartidx[cntcp]=readpart_startidx[cntcp];
				cpreadpartendidx[cntcp]=readpart_endidx[cntcp];
				cntcp++;
			}
			for(int cidx=readpart_endidx[cnt_write_style];cidx<readpart_endidx[readpart_endidx[cnt_write_style]];cidx++)
			{
				int subval=readpart_endidx[cnt_write_style]-readpart_startidx[cnt_write_style];
				cpreadpartstyle[cntcp]=readpart_style[cidx];
				cpreadpartstartidx[cntcp]=readpart_startidx[cidx]-subval;
				cpreadpartendidx[cntcp]=readpart_endidx[cidx]-subval;
				cntcp++;
			}
			
			for(int cidx=readpart_startidx[cnt_write_style];cidx<readpart_endidx[cnt_write_style];cidx++)
			{
				int addval=readpart_endidx[readpart_endidx[cnt_write_style]]-readpart_endidx[cnt_write_style];
				cpreadpartstyle[cntcp]=readpart_style[cidx];
				cpreadpartstartidx[cntcp]=readpart_startidx[cidx]+addval;
				cpreadpartendidx[cntcp]=readpart_endidx[cidx]+addval;
				cntcp++;
			}
			for(int cidx=readpart_endidx[readpart_endidx[cnt_write_style]];cidx<1000;cidx++)
			{
				cpreadpartstyle[cntcp]=readpart_style[cidx];
				cpreadpartstartidx[cntcp]=readpart_startidx[cidx];
				cpreadpartendidx[cntcp]=readpart_endidx[cidx];
				cntcp++;
			}
			memcpy(readpart_style,cpreadpartstyle,sizeof(int)*1000);
			memcpy(readpart_startidx,cpreadpartstartidx,sizeof(int)*1000);
			memcpy(readpart_endidx,cpreadpartendidx,sizeof(int)*1000);

		

			is_swap_2grp=1;
			swapGrp(allgroup,allstrokenum);
			group_relationship_big(allgroup,allgroupnum);
		}
		//write first
		bool *isconnextgroup=new bool[allgroupnum];
		int curallgroupnum=0;
		for( i=0;i<allgroupnum;i++)
		{
			isconnextgroup[i]=false;
			if(i>0 &&allgroup[i].strokenum==1 &&allgroup[i-1].strokenum==1 )
			{
				if( 
					(abs(allgroup[i-1].strokes[0].pterow-allgroup[i].strokes[0].ptsrow)<=10
					&&abs(allgroup[i-1].strokes[0].ptecol-allgroup[i].strokes[0].ptscol)<=10
					)
					)//������ʻ����غϵĵ㣬�򲻿ɷ�
				{
					isconnextgroup[i]=true;
				}
			}
		}
		for( i=0;i<allgroupnum;i++)
		{
			Group *ttt=&(allgroup[i]);
			copyGrp_withfix(ttt,onegroup);
			strcpy(onegroup->grpname,allgroup[i].grpname);
			firstin_write=false;
			bool issuc3=writePart3(0,allgroup[i].grpname,allgroup[i].left,allgroup[i].top,
				allgroup[i].right,allgroup[i].bot,onegroup,isendstroke_ofpart,part_lvl+1);
			if(!issuc3)
			{
				delete []isendstroke_ofpart;
				delete []isconnextgroup;
				ReleaseGrammer1(tmpgroup);ReleaseGrammer1(onegroup);
				ReleaseGrammer(allgroup, allgroupnum);
				return 0;
			}
			ttt=&(allgroup[i]);
			copyGrp_withfix(onegroup,ttt);
		}

		for( kkkk=0;kkkk<allgroupnum;kkkk++)
		{
			updateGrp_draw(&(allgroup[kkkk]));
		}	

		int iiii=0;
		Group*allgroup_cp=new Group[allgroupnum];
		for(iiii=0;iiii<allgroupnum;iiii++)
		{
			initgrp(&(allgroup_cp[iiii]));
			allgroup_cp[iiii].strokes     =new StrokeSyntax[glo_maxstrokenum];
			allgroup_cp[iiii].draw_strokes=new StrokeSyntax[glo_maxstrokenum];
			allgroup_cp[iiii].con_ss      =new ConnectStrokeSyntax[glo_maxstrokenum];
			allgroup_cp[iiii].draw_curves =new DrawCurve[glo_maxstrokenum];

			allgroup_cp[iiii].ptind_left=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot=new int[2*allstrokenum];//			

			allgroup_cp[iiii].ptind_left_grpidx=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_grpidx=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_grpidx=new int[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_grpidx=new int[2*allstrokenum];//			

			allgroup_cp[iiii].ptind_left_wei_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_wei_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_wei_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_wei_self=new float[2*allstrokenum];//			

			allgroup_cp[iiii].ptind_left_wei=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_wei=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_wei=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_wei=new float[2*allstrokenum];//


			allgroup_cp[iiii].ptind_left_worh=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_worh=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_worh=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_worh=new float[2*allstrokenum];//

			allgroup_cp[iiii].ptind_left_worh_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_worh_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_worh_self=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_worh_self=new float[2*allstrokenum];//

			allgroup_cp[iiii].ptind_left_dis=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_right_dis=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_top_dis=new float[2*allstrokenum];//
			allgroup_cp[iiii].ptind_bot_dis=new float[2*allstrokenum];//

			Group *ttt=&(allgroup_cp[iiii]);Group *sss=&(allgroup[iiii]);

			initGrp_relationship(ttt,2*allstrokenum);
			copyGrp_withfix(sss,ttt);

		}

		bool psuc=false;
		iiii=0;

		while(iiii<100)
		{
			for(int i=0;i<allgroupnum;i++)
			{
				Group *ttt=&(allgroup_cp[i]);Group *sss=&(allgroup[i]);
				copyGrp_withfix(ttt,sss);
			}
			bool issuc2=partitionBigGrp(allgroup,allgroupnum,isconnextgroup);
			if (issuc2==true)
			{
				psuc=true;
				break;
			}
			iiii++;
		}
		if(is_swap_2grp)
		{


			swapGrp(allgroup,allstrokenum);
		}
		if (psuc==true)
		{
			copy_allgroup_toonegroup(onegroup,allgroup, isendstroke_ofpart,allgroupnum, allstrokenum);
			/*	for(i=0;i<allstrokenum;i++)
			{
			retisendstroke_ofpart[i]+=isendstroke_ofpart[i];
			}*/
			/////////////////////////////////////����յ�պϵģ���Ҫ����
			if(start_end_con)
			{

				int addrow=onegroup->draw_strokes[0].ptsrow-onegroup->draw_strokes[onegroup->strokenum-1].pterow;
				int addcol=onegroup->draw_strokes[0].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol;

				int curssindidx=onegroup->strokenum-2;
				//addrow*=0.9;
				//addcol*=0.9;
				while(curssindidx>=0)
				{
					onegroup->draw_strokes[curssindidx+1].ptecol+=addcol;//onegroup->strokes[curssindidx+1].ptecol+onegroup->draw_strokes[curssindidx].ptecol-onegroup->strokes[curssindidx+1].ptscol;
					onegroup->draw_strokes[curssindidx+1].pterow+=addrow;

					onegroup->draw_strokes[curssindidx+1].ptscol+=addcol;//onegroup->strokes[curssindidx+1].ptecol+onegroup->draw_strokes[curssindidx].ptecol-onegroup->strokes[curssindidx+1].ptscol;
					onegroup->draw_strokes[curssindidx+1].ptsrow+=addrow;
					curssindidx--;
					addrow*=0.9;
					addcol*=0.9;
				}	
				//onegroup->draw_strokes[0].ptecol=onegroup->draw_strokes[0].ptscol;
				//onegroup->draw_strokes[0].pterow=onegroup->draw_strokes[0].ptsrow;
				onegroup->draw_strokes[0].ptecol+=addcol;
				onegroup->draw_strokes[0].pterow+=addrow;


				//�ӱȻ��������ӻ�����
				int lenrow=abs(onegroup->draw_strokes[onegroup->strokenum-1].ptsrow-onegroup->draw_strokes[onegroup->strokenum-1].pterow);//row y,col x
				int lencol=abs(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol);
				if(lenrow==0 && lencol==0)
				{

				}
				else
				{
					double linek;
					double lineb;
					if(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol!=0)
					{
						linek=(onegroup->draw_strokes[onegroup->strokenum-1].ptsrow-onegroup->draw_strokes[onegroup->strokenum-1].pterow)*1.0/(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol);
						lineb=(onegroup->draw_strokes[onegroup->strokenum-1].ptscol*onegroup->draw_strokes[onegroup->strokenum-1].pterow-onegroup->draw_strokes[onegroup->strokenum-1].ptecol*onegroup->draw_strokes[onegroup->strokenum-1].ptsrow)*1.0/(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol);
					}
					if(lenrow>lencol)//ƫ����
					{
						if(onegroup->draw_strokes[onegroup->strokenum-1].ptsrow>onegroup->draw_strokes[onegroup->strokenum-1].pterow)//��������棬����
						{
							if(rand()%10<glo_isgrow)//����
							{
								onegroup->draw_strokes[onegroup->strokenum-1].pterow=onegroup->draw_strokes[onegroup->strokenum-1].pterow-start_end_con_len*lenrow*realGuassGenerate(0.5,0.5/3,0,1);
							}
							else
							{
								onegroup->draw_strokes[onegroup->strokenum-1].pterow=onegroup->draw_strokes[onegroup->strokenum-1].pterow+start_end_con_len_dec*lenrow*realGuassGenerate(0.5,0.5/3,0,1);//;
							}
							if(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol==0)
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol;
							else
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=(onegroup->draw_strokes[onegroup->strokenum-1].pterow-lineb)*1.0/linek;
						}
						else//��������棬��С
						{
							if(rand()%10<glo_isgrow)//����
							{
								onegroup->draw_strokes[onegroup->strokenum-1].pterow=onegroup->draw_strokes[onegroup->strokenum-1].pterow+start_end_con_len*lenrow*realGuassGenerate(0.5,0.5/3,0,1);
							}
							else
							{
								onegroup->draw_strokes[onegroup->strokenum-1].pterow=onegroup->draw_strokes[onegroup->strokenum-1].pterow-start_end_con_len_dec*lenrow*realGuassGenerate(0.5,0.5/3,0,1);//;
							}
							if(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol==0)
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol;
							else
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=(onegroup->draw_strokes[onegroup->strokenum-1].pterow-lineb)*1.0/linek;
						}
					}
					else//ƫ����
					{
						if(onegroup->draw_strokes[onegroup->strokenum-1].ptscol>onegroup->draw_strokes[onegroup->strokenum-1].ptecol)//��������棬����
						{
							if(rand()%10<glo_isgrow)//����
							{
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol-start_end_con_len*lencol*realGuassGenerate(0.5,0.5/3,0,1);
							}
							else
							{
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol+start_end_con_len_dec*lencol*realGuassGenerate(0.5,0.5/3,0,1);//;
							}
							onegroup->draw_strokes[onegroup->strokenum-1].pterow=linek*onegroup->draw_strokes[onegroup->strokenum-1].ptecol+lineb;
						}
						else//��������棬��С
						{
							if(rand()%10<glo_isgrow)//����
							{
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol+start_end_con_len*lencol*realGuassGenerate(0.5,0.5/3,0,1);
							}
							else
							{
								onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol-start_end_con_len_dec*lencol*realGuassGenerate(0.5,0.5/3,0,1);//;
							}
							onegroup->draw_strokes[onegroup->strokenum-1].pterow=linek*onegroup->draw_strokes[onegroup->strokenum-1].ptecol+lineb;
						}
					}
				}
				int strokelen=sqrt(1.0*
					(onegroup->draw_strokes[onegroup->strokenum-1].ptsrow-onegroup->draw_strokes[onegroup->strokenum-1].pterow)*(onegroup->draw_strokes[onegroup->strokenum-1].ptsrow-onegroup->draw_strokes[onegroup->strokenum-1].pterow)+
					(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol)*(onegroup->draw_strokes[onegroup->strokenum-1].ptscol-onegroup->draw_strokes[onegroup->strokenum-1].ptecol));
				double rdlen=strokelen*stroke_tiny_zoom/2;
				//if(rdlen<5)
				//	rdlen=5;
				onegroup->draw_strokes[onegroup->strokenum-1].ptecol=onegroup->draw_strokes[onegroup->strokenum-1].ptecol+rdlen*realGuassGenerate(0,1.0/3,-1,1);//(1-rand()*2.0/RAND_MAX);
				onegroup->draw_strokes[onegroup->strokenum-1].pterow=onegroup->draw_strokes[onegroup->strokenum-1].pterow+rdlen*realGuassGenerate(0,1.0/3,-1,1);//(1-rand()*2.0/RAND_MAX);



			}

			updateGrp_draw(onegroup);

			float zmprolr=(1+tgtright-tgtleft)*1.0/(1+onegroup->right-onegroup->left);
			float zmprotb=(1+tgtbot-tgttop)*1.0/(1+onegroup->bot-onegroup->top);
			float smlzmpro=zmprolr>zmprotb?zmprolr:zmprotb;


			if(onegroup->strokenum>1)
				zoomPart2_s(onegroup,zmprolr,zmprotb,onegroup->top,onegroup->left);
			else
				zoomPart2_s(onegroup,smlzmpro,smlzmpro,onegroup->top,onegroup->left);
			updateGrp_draw(onegroup);
			shiftPart2_s(onegroup,tgtleft-onegroup->left,tgttop-onegroup->top);
			updateGrp_draw(onegroup);

			onegroup->partition_hei=1+onegroup->bot-onegroup->top;
			onegroup->partition_wid=1+onegroup->right-onegroup->left;
			onegroup->partition_left=onegroup->left;
			onegroup->partition_top=onegroup->top;
			copyGrp(onegroup,retgrp);
			strcpy(retgrp->grpname,hanziname);
			delete []isendstroke_ofpart;
			delete []isconnextgroup;
			ReleaseGrammer1(tmpgroup);ReleaseGrammer1(onegroup);
			ReleaseGrammer(allgroup,allgroup_cp, allgroupnum);
			return 1;

		}else
		{
			ReleaseGrammer1(tmpgroup);ReleaseGrammer1(onegroup);
			delete []isendstroke_ofpart;
			delete []isconnextgroup;
			ReleaseGrammer(allgroup,allgroup_cp, allgroupnum);
			return 0;
		}

	}
	else
	{
		fclose(fp);		
		int i,j;
		InitGrammer(rootpath,hanziname,curstyleidx,allstrokenum,allgroupnum,allgroup);


		for( i=0;i<allgroupnum;i++)
		{
			ck_stroke_conornot(&(allgroup[i]));
		}

		int curstrokenum_tmp=0;
		for( i=0;i<1;i++)
		{

			drawGrammer(&(allgroup[i]));
			updateGrp_draw(&(allgroup[i]));



			curstrokenum_tmp+=allgroup[i].strokenum;
			isendstroke_ofpart[curstrokenum_tmp-1]=part_lvl;
		}

		copy_allgroup_toonegroup(onegroup,allgroup,isendstroke_ofpart,allgroupnum, allstrokenum);
		//ck_stroke_conornot(onegroup);
		for(i=0;i<allstrokenum;i++)
		{
			retisendstroke_ofpart[i]=part_lvl;
		}
		delete []isendstroke_ofpart;
		//CopyStrokes(allgroup,onegroup,allgroupnum);

		//	updateGrp_draw(onegroup);
		updateGrp_draw(onegroup);
		//CopyStrokes(allgroup,onegroup,allgroupnum);
		float zmprolr=(1+tgtright-tgtleft)*1.0/(1+onegroup->right-onegroup->left);
		float zmprotb=(1+tgtbot-tgttop)*1.0/(1+onegroup->bot-onegroup->top);

		float smlzmpro=zmprolr>zmprotb?zmprolr:zmprotb;

		/*	if(zmprolr/zmprotb>glo_lrtb_sclpro)
		zmprolr=zmprotb*glo_lrtb_sclpro;
		if(zmprotb/zmprolr>glo_lrtb_sclpro)
		zmprotb=zmprolr*glo_lrtb_sclpro;*/
		if(1)//onegroup->strokenum>1)
			zoomPart2_s(onegroup,zmprolr,zmprotb,onegroup->top,onegroup->left);
		else
			zoomPart2_s(onegroup,smlzmpro,smlzmpro,onegroup->top,onegroup->left);
		updateGrp_draw(onegroup);
		shiftPart2(onegroup,tgtleft-onegroup->left,tgttop-onegroup->top);

		//	updateGrp_draw(onegroup);
		updateGrp_draw(onegroup);
		//	drawGrammer(onegroup);
		//	updateGrp_draw(onegroup);
		onegroup->partition_hei=1+onegroup->bot-onegroup->top;
		onegroup->partition_wid=1+onegroup->right-onegroup->left;
		onegroup->partition_left=onegroup->left;
		onegroup->partition_top=onegroup->top;
		copyGrp(onegroup,retgrp);
		strcpy(retgrp->grpname,hanziname);
		//ReleaseGrammer(allgroup,allgroup_big,onegroup,groupnum2, glo_maxgroupnum, glo_maxgroupnum);

		ReleaseGrammer1(onegroup);
		ReleaseGrammer1(tmpgroup);
		ReleaseGrammer4(allgroup, allgroupnum);
		//	delete []isendstroke_ofpart;
		return 1;
	}




}
void swapGrp(Group*allgroup,int allstrokenum)
{
	int iiii=0;
	int allgroupnum=2;
	Group*allgroup_cp=new Group;
	initgrp(&(allgroup_cp[0]));
	allgroup_cp[0].strokes     =new StrokeSyntax[glo_maxstrokenum];
	allgroup_cp[0].draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	allgroup_cp[0].con_ss      =new ConnectStrokeSyntax[glo_maxstrokenum];
	allgroup_cp[0].draw_curves =new DrawCurve[glo_maxstrokenum];
	allgroup_cp[0].ptind_left=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_right=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_top=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_bot=new int[2*allstrokenum];//			
	allgroup_cp[0].ptind_left_grpidx=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_right_grpidx=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_top_grpidx=new int[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_grpidx=new int[2*allstrokenum];//			
	allgroup_cp[0].ptind_left_wei_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_right_wei_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_top_wei_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_wei_self=new float[2*allstrokenum];//			
	allgroup_cp[0].ptind_left_wei=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_right_wei=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_top_wei=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_wei=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_left_worh=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_right_worh=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_top_worh=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_worh=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_left_worh_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_right_worh_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_top_worh_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_worh_self=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_left_dis=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_right_dis=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_top_dis=new float[2*allstrokenum];//
	allgroup_cp[0].ptind_bot_dis=new float[2*allstrokenum];//

	Group *ttt=&(allgroup_cp[0]);Group *sss=&(allgroup[0]);

	Group *rrr=&(allgroup[1]);

	initGrp_relationship(ttt,2*allstrokenum);
	copyGrp_withfix(sss,ttt);
	copyGrp_withfix(rrr,sss);
	copyGrp_withfix(ttt,rrr);

	ReleaseGrammer1(allgroup_cp);
}
bool readPart(char *hanziname,int tgtleft,int tgttop,int tgtright,int tgtbot,Group*retgrp,int *retisendstroke_ofpart,int part_lvl)
{
	char numfilename[1024]="";
	sprintf(numfilename,"%s\\%s\\%s_num.txt",rootpath,glo_learnresultpath,hanziname);
	FILE *fp=fopen(numfilename,"r");
	int isusedpart,stylenum;
	fscanf(fp,"%d",&stylenum);
	fclose(fp);
	int curstyleidx;
	int startstyleidx=cnt_read_style;
	if(firstin_write)
	{
		curstyleidx=1+rand()%(stylenum-1);
		readpart_style[cnt_read_style]=curstyleidx;
		readpart_startidx[cnt_read_style]=cnt_read_style;
		cnt_read_style++;
	}
	else
	{
		curstyleidx=readpart_style[glo_read_used_style];
		glo_read_used_style++;

	}



	//	curstyleidx=1;
	int i,j;
	int allstrokenum=0,allgroupnum=0;
	Group* allgroup,*onegroup;
	sprintf(numfilename,"%s\\%s\\%s_%d.txt",rootpath,glo_learnresultpath,hanziname,curstyleidx);
	FILE *fp_rd=fopen(numfilename,"r");

	fscanf(fp_rd,"%d%d",&(isusedpart),&(allgroupnum));
	allgroup=new Group[allgroupnum];

	for( i=0;i<allgroupnum;i++)
	{
		initgrp(&(allgroup[i]));
		allgroup[i].strokes     =new StrokeSyntax[glo_maxstrokenum];
		allgroup[i].draw_strokes     =new StrokeSyntax[glo_maxstrokenum];
		allgroup[i].con_ss     =new ConnectStrokeSyntax[glo_maxstrokenum];
		allgroup[i].draw_curves     =new DrawCurve[glo_maxstrokenum];
	}
	int *isendstroke_ofpart=new int[glo_maxstrokenum];
	memset(isendstroke_ofpart,0,sizeof(int)*glo_maxstrokenum);
	onegroup=new Group;
	initgrp(onegroup);
	onegroup->strokes     =new StrokeSyntax[glo_maxstrokenum];
	onegroup->draw_strokes=new StrokeSyntax[glo_maxstrokenum];
	onegroup->con_ss      =new ConnectStrokeSyntax[glo_maxstrokenum];
	onegroup->draw_curves =new DrawCurve[glo_maxstrokenum];

	if(isusedpart)
	{

		int curleft,curtop,curright,curbot;
		char curpartname[1024]="";

		fscanf(fp_rd,"%d%d%d%d%s",	&curleft,&curtop,&curright,&curbot,curpartname);

		bool issuc=readPart(curpartname,curleft,curtop,curright,curbot,onegroup,isendstroke_ofpart,part_lvl+1);
		if(issuc)
		{
			Group *ttt=&(allgroup[0]);
			copyGrp(onegroup,ttt);
			updateGrp_draw(&(allgroup[0]));
			for(int iii=0;iii<onegroup->strokenum;iii++)
				retisendstroke_ofpart[allstrokenum+iii]=isendstroke_ofpart[iii];
			retisendstroke_ofpart[allstrokenum+onegroup->strokenum-1]=part_lvl;
		}else
		{
			delete []	onegroup->strokes ;//�ýṹ�����ʻ�����ʼ��
			delete []onegroup->draw_strokes;//�ýṹ�����ʻ�����ʼ��
			delete []onegroup->con_ss;//�������ʻ�����
			delete []onegroup->draw_curves;
			delete []	onegroup;
			delete []isendstroke_ofpart;
			ReleaseGrammer4(allgroup,allgroupnum);

			fclose(fp);
			return 0;
		}
		allstrokenum+=allgroup[0].strokenum;
		i=1;
		while(issuc && i<allgroupnum)
		{
			fscanf(fp_rd,"%d%d%d%d%s",&curleft,&curtop,&curright,&curbot,curpartname);
			issuc=readPart(curpartname,curleft,curtop,curright,curbot,onegroup,isendstroke_ofpart,part_lvl+1);

			if(issuc)
			{
				Group *ttt=&(allgroup[i]);
				copyGrp(onegroup,ttt);
				updateGrp_draw(&(allgroup[i]));
				for(int iii=0;iii<onegroup->strokenum;iii++)
					retisendstroke_ofpart[allstrokenum+iii]=isendstroke_ofpart[iii];
				retisendstroke_ofpart[allstrokenum+onegroup->strokenum-1]=part_lvl;
			}
			else
			{
				delete []	onegroup->strokes ;//�ýṹ�����ʻ�����ʼ��
				delete []onegroup->draw_strokes;//�ýṹ�����ʻ�����ʼ��
				delete []onegroup->con_ss;//�������ʻ�����
				delete []onegroup->draw_curves;
				delete []	onegroup;
				delete []isendstroke_ofpart;
				ReleaseGrammer4(allgroup,allgroupnum);

				fclose(fp);
				return 0;
			}
			allstrokenum+=allgroup[i].strokenum;
			i++;
		}
		fclose(fp_rd);
		//copy to big group
		for(i=0;i<allgroupnum;i++)
		{	
			allgroup[i].ptind_left=new int[2*allstrokenum];//
			allgroup[i].ptind_right=new int[2*allstrokenum];//
			allgroup[i].ptind_top=new int[2*allstrokenum];//
			allgroup[i].ptind_bot=new int[2*allstrokenum];//

			allgroup[i].ptind_left_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_right_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_top_grpidx=new int[2*allstrokenum];//
			allgroup[i].ptind_bot_grpidx=new int[2*allstrokenum];//

			allgroup[i].ptind_left_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_right_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_top_wei_self=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_wei_self=new float[2*allstrokenum];//

			allgroup[i].ptind_left_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_right_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_top_wei=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_wei=new float[2*allstrokenum];//

			allgroup[i].ptind_left_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_right_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_top_worh=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_worh=new float[2*allstrokenum];//

			allgroup[i].ptind_left_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_right_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_top_worh_self=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_worh_self=new float[2*allstrokenum];//

			allgroup[i].ptind_left_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_right_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_top_dis=new float[2*allstrokenum];//
			allgroup[i].ptind_bot_dis=new float[2*allstrokenum];//

			Group*ttt=&(allgroup[i]);
			initGrp_relationship(ttt,2*allstrokenum);
		}
		copy_allgroup_toonegroup(onegroup,allgroup, isendstroke_ofpart,allgroupnum, allstrokenum);

		/*for(int iii=0;iii<allstrokenum;iii++)
		{
		retisendstroke_ofpart[iii]+=isendstroke_ofpart[iii]>0?1:0;
		}*/

		updateGrp_draw(onegroup);

		float zmprolr=(1+tgtright-tgtleft)*1.0/(1+onegroup->right-onegroup->left);
		float zmprotb=(1+tgtbot-tgttop)*1.0/(1+onegroup->bot-onegroup->top);

		float smlzmpro=zmprolr>zmprotb?zmprolr:zmprotb;

		if(1)//onegroup->strokenum>1)
			zoomPart2_s(onegroup,zmprolr,zmprotb,onegroup->top,onegroup->left);
		else
			zoomPart2_s(onegroup,smlzmpro,smlzmpro,onegroup->top,onegroup->left);
		updateGrp_draw(onegroup);
		shiftPart2_s(onegroup,tgtleft-onegroup->left,tgttop-onegroup->top);
		updateGrp_draw(onegroup);



		onegroup->partition_hei=1+onegroup->bot-onegroup->top;
		onegroup->partition_wid=1+onegroup->right-onegroup->left;
		onegroup->partition_left=onegroup->left;
		onegroup->partition_top=onegroup->top;

		copyGrp(onegroup,retgrp);


		delete []	onegroup->strokes ;//�ýṹ�����ʻ�����ʼ��
		delete []onegroup->draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []onegroup->con_ss;//�������ʻ�����
		delete []onegroup->draw_curves;
		delete []	onegroup;
		delete []isendstroke_ofpart;
		ReleaseGrammer(allgroup,allgroupnum);

		if(firstin_write)
		{
		
			readpart_endidx[startstyleidx]=cnt_read_style;

		}

		return 1;
	}
	else
	{
		fclose(fp_rd);
		int allstrokenum,allgroupnum;
		allgroupnum=1;
		allstrokenum=1;

		InitGrammer(rootpath,hanziname,curstyleidx,allstrokenum,allgroupnum,allgroup);


		onegroup->strokenum=allstrokenum;

		cal_grouplrtb(allgroup,allgroupnum);
		copy_allgroup_toonegroup(onegroup,allgroup,isendstroke_ofpart,allgroupnum, allstrokenum);
		cal_grouplrtb(onegroup,1);

		for(i=0;i<allstrokenum;i++)
		{
			retisendstroke_ofpart[i]=part_lvl;
		}

		updateGrp_draw(onegroup);
		float zmprolr=(1+tgtright-tgtleft)*1.0/(1+onegroup->right-onegroup->left);
		float zmprotb=(1+tgtbot-tgttop)*1.0/(1+onegroup->bot-onegroup->top);
		float smlzmpro=zmprolr>zmprotb?zmprolr:zmprotb;


		if(1)//onegroup->strokenum>1)
			zoomPart2_s(onegroup,zmprolr,zmprotb,onegroup->top,onegroup->left);	
		else
			zoomPart2_s(onegroup,smlzmpro,smlzmpro,onegroup->top,onegroup->left);	


		updateGrp_draw(onegroup);
		shiftPart2_s(onegroup,tgtleft-onegroup->left,tgttop-onegroup->top);		
		updateGrp_draw(onegroup);	
		onegroup->partition_hei=1+onegroup->bot-onegroup->top;
		onegroup->partition_wid=1+onegroup->right-onegroup->left;
		onegroup->partition_left=onegroup->left;
		onegroup->partition_top=onegroup->top;

		copyGrp(onegroup,retgrp);
		//ReleaseGrammer(allgroup,allgroup_big,onegroup,groupnum2, glo_maxgroupnum, glo_maxgroupnum);



		delete []	onegroup->strokes ;//�ýṹ�����ʻ�����ʼ��
		delete []onegroup->draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []onegroup->con_ss;//�������ʻ�����
		delete []onegroup->draw_curves;
		delete []	onegroup;
		delete []isendstroke_ofpart;
		ReleaseGrammer4(allgroup, allgroupnum);

		if(firstin_write)
		{
		
			readpart_endidx[startstyleidx]=cnt_read_style;

		}

		return 1;



	}
	
}



void cal_grouplrtb(Group* &allgroup,int allgroupnum)
{
	int i,j;
	for(int i=0;i<allgroupnum;i++)
	{
		int curleft=1000000,curtop=1000000,curbot=0,curright=0;
		int curleftidx=1000000,curtopidx=1000000,curbotidx=0,currightidx=0;
		for(int j=0;j<allgroup[i].strokenum;j++)
		{
			if(allgroup[i].strokes[j].ptsrow<curtop)
			{	curtop=allgroup[i].strokes[j].ptsrow;
			curtopidx=j;
			}
			if(allgroup[i].strokes[j].ptsrow>curbot)
			{	curbot=allgroup[i].strokes[j].ptsrow;
			curbotidx=j;
			}
			if(allgroup[i].strokes[j].pterow<curtop)
			{	curtop=allgroup[i].strokes[j].pterow;curtopidx=j;
			}
			if(allgroup[i].strokes[j].pterow>curbot)
			{	curbot=allgroup[i].strokes[j].pterow;curbotidx=j;
			}

			if(allgroup[i].strokes[j].ptscol<curleft)
			{	curleft=allgroup[i].strokes[j].ptscol;curleftidx=j;
			}
			if(allgroup[i].strokes[j].ptscol>curright)
			{	curright=allgroup[i].strokes[j].ptscol;currightidx=j;
			}
			if(allgroup[i].strokes[j].ptecol<curleft)
			{	curleft=allgroup[i].strokes[j].ptecol;curleftidx=j;
			}
			if(allgroup[i].strokes[j].ptecol>curright)
			{	curright=allgroup[i].strokes[j].ptecol;currightidx=j;
			}
		}
		allgroup[i].top=curtop;
		allgroup[i].bot=curbot;
		allgroup[i].left=curleft;
		allgroup[i].right=curright;

		allgroup[i].top_ssidx=curtopidx;
		allgroup[i].bot_ssidx=curbotidx;
		allgroup[i].left_ssidx=curleftidx;
		allgroup[i].right_ssidx=currightidx;
	}
}

void copyGrp_withfix(Group *&ori,Group* &tgt)
{
	int i,j;
	sprintf(tgt->grpname,"%s",ori->grpname);
	tgt->partition_top=ori->partition_top;
	tgt->partition_left=ori->partition_left;
	tgt->partition_wid=ori->partition_wid;
	tgt->partition_hei=ori->partition_hei;

	tgt->top=ori->top;
	tgt->left=ori->left;
	tgt->right=ori->right;
	tgt->bot=ori->bot;

	tgt->top_ssidx=ori->top_ssidx;
	tgt->left_ssidx=ori->left_ssidx;
	tgt->right_ssidx=ori->right_ssidx;
	tgt->bot_ssidx=ori->bot_ssidx;


	tgt->strokenum=ori->strokenum;
	tgt->curvenum=ori->curvenum;

	tgt->ptind_left_num=ori->ptind_left_num;
	tgt->ptind_right_num=ori->ptind_right_num;
	tgt->ptind_top_num=ori->ptind_top_num;
	tgt->ptind_bot_num=ori->ptind_bot_num;

	/*	tgt->strokes=new StrokeSyntax[ori->strokenum];
	tgt->draw_strokes=new StrokeSyntax[ori->strokenum];
	tgt->con_ss=new ConnectStrokeSyntax[ori->strokenum];
	tgt->draw_curves=new DrawCurve[ori->strokenum *4];
	*/
	for( i=0;i<ori->strokenum;i++)
	{
		tgt->strokes[i].ptsrow=ori->strokes[i].ptsrow;
		tgt->strokes[i].ptscol=ori->strokes[i].ptscol;
		tgt->strokes[i].pterow=ori->strokes[i].pterow;
		tgt->strokes[i].ptecol=ori->strokes[i].ptecol;

	}

	for( i=0;i<ori->strokenum;i++)
	{
		tgt->draw_strokes[i].ptsrow=ori->draw_strokes[i].ptsrow;
		tgt->draw_strokes[i].ptscol=ori->draw_strokes[i].ptscol;
		tgt->draw_strokes[i].pterow=ori->draw_strokes[i].pterow;
		tgt->draw_strokes[i].ptecol=ori->draw_strokes[i].ptecol;

	}
	for( i=0;i<ori->strokenum-1;i++)
	{

		tgt->con_ss[i].canCut=ori->con_ss[i].canCut;
		tgt->con_ss[i].conNum=ori->con_ss[i].conNum;
		for(int j=0;j<ori->con_ss[i].conNum;j++)
		{
			tgt->con_ss[i].conInd[j]=ori->con_ss[i].conInd[j];
		}
	}
	for(i=0;i<ori->ptind_left_num;i++)
	{
		tgt->ptind_left[i]=ori->ptind_left[i];
		tgt->ptind_left_grpidx[i]=ori->ptind_left_grpidx[i];
		tgt->ptind_left_wei_self[i]=ori->ptind_left_wei_self[i];
		tgt->ptind_left_wei[i]=ori->ptind_left_wei[i];

		tgt->ptind_left_worh[i]=ori->ptind_left_worh[i];
		tgt->ptind_left_worh_self[i]=ori->ptind_left_worh_self[i];
		tgt->ptind_left_dis[i]=ori->ptind_left_dis[i];

		tgt->ptind_left_num=ori->ptind_left_num;
	}
	for(i=0;i<ori->ptind_right_num;i++)
	{
		tgt->ptind_right[i]=ori->ptind_right[i];
		tgt->ptind_right_grpidx[i]=ori->ptind_right_grpidx[i];
		tgt->ptind_right_wei_self[i]=ori->ptind_right_wei_self[i];
		tgt->ptind_right_wei[i]=ori->ptind_right_wei[i];

		tgt->ptind_right_worh[i]=ori->ptind_right_worh[i];
		tgt->ptind_right_worh_self[i]=ori->ptind_right_worh_self[i];
		tgt->ptind_right_dis[i]=ori->ptind_right_dis[i];
		tgt->ptind_right_num=ori->ptind_right_num;
	}

	for(i=0;i<ori->ptind_top_num;i++)
	{
		tgt->ptind_top[i]=ori->ptind_top[i];
		tgt->ptind_top_grpidx[i]=ori->ptind_top_grpidx[i];
		tgt->ptind_top_wei_self[i]=ori->ptind_top_wei_self[i];
		tgt->ptind_top_wei[i]=ori->ptind_top_wei[i];

		tgt->ptind_top_worh[i]=ori->ptind_top_worh[i];
		tgt->ptind_top_worh_self[i]=ori->ptind_top_worh_self[i];
		tgt->ptind_top_dis[i]=ori->ptind_top_dis[i];

		tgt->ptind_top_num=ori->ptind_top_num;
	}

	for(i=0;i<ori->ptind_bot_num;i++)
	{
		tgt->ptind_bot[i]=ori->ptind_bot[i];
		tgt->ptind_bot_grpidx[i]=ori->ptind_bot_grpidx[i];
		tgt->ptind_bot_wei_self[i]=ori->ptind_bot_wei_self[i];
		tgt->ptind_bot_wei[i]=ori->ptind_bot_wei[i];

		tgt->ptind_bot_worh[i]=ori->ptind_bot_worh[i];
		tgt->ptind_bot_worh_self[i]=ori->ptind_bot_worh_self[i];
		tgt->ptind_bot_dis[i]=ori->ptind_bot_dis[i];
		tgt->ptind_bot_num=ori->ptind_bot_num;
	}
}


void copyGrp(Group *&ori,Group* &tgt)
{
	int i,j;
	sprintf(tgt->grpname,"%s",ori->grpname);
	tgt->partition_top=ori->partition_top;
	tgt->partition_left=ori->partition_left;
	tgt->partition_wid=ori->partition_wid;
	tgt->partition_hei=ori->partition_hei;

	tgt->top=ori->top;
	tgt->left=ori->left;
	tgt->right=ori->right;
	tgt->bot=ori->bot;

	tgt->top_ssidx=ori->top_ssidx;
	tgt->left_ssidx=ori->left_ssidx;
	tgt->right_ssidx=ori->right_ssidx;
	tgt->bot_ssidx=ori->bot_ssidx;


	tgt->strokenum=ori->strokenum;
	tgt->curvenum=ori->curvenum;

	/*	tgt->strokes=new StrokeSyntax[ori->strokenum];
	tgt->draw_strokes=new StrokeSyntax[ori->strokenum];
	tgt->con_ss=new ConnectStrokeSyntax[ori->strokenum];
	tgt->draw_curves=new DrawCurve[ori->strokenum *4];
	*/
	for(int i=0;i<ori->strokenum;i++)
	{
		tgt->strokes[i].ptsrow=ori->strokes[i].ptsrow;
		tgt->strokes[i].ptscol=ori->strokes[i].ptscol;
		tgt->strokes[i].pterow=ori->strokes[i].pterow;
		tgt->strokes[i].ptecol=ori->strokes[i].ptecol;

	}

	for( i=0;i<ori->strokenum;i++)
	{
		tgt->draw_strokes[i].ptsrow=ori->draw_strokes[i].ptsrow;
		tgt->draw_strokes[i].ptscol=ori->draw_strokes[i].ptscol;
		tgt->draw_strokes[i].pterow=ori->draw_strokes[i].pterow;
		tgt->draw_strokes[i].ptecol=ori->draw_strokes[i].ptecol;

	}
	for( i=0;i<ori->strokenum-1;i++)
	{

		tgt->con_ss[i].canCut=ori->con_ss[i].canCut;
		tgt->con_ss[i].conNum=ori->con_ss[i].conNum;
		for(int j=0;j<ori->con_ss[i].conNum;j++)
		{
			tgt->con_ss[i].conInd[j]=ori->con_ss[i].conInd[j];
		}
	}
}


void zoom(unsigned char *src, int width, int height, unsigned char *ret, int retwidth, int retheight)
{
	int i,j;
	double ratiox,ratioy;
	double fi,fj,di,dj;
	int ii,ij;

	ratiox=retwidth*1.0/width;
	ratioy=retheight*1.0/height;

	for(i=0;i<retheight;i++)
	{
		for(j=0;j<retwidth;j++)
		{
			fi=i/ratioy;		fj=j/ratiox;
			ii=(int)fi;			ij=(int)fj;
			di=fi-ii;			dj=fj-ij;						
			if(ij+1<width && ii+1 <height && di!=0 && dj!=0)
			{
				ret[i*retwidth+j]=
					(
					(src[ii*width+(ij+1)]-src[ii*width+ij] )*dj
					+(src[(ii+1)*width+ij]-src[ii*width+ij])*di
					+(src[(ii+1)*width+(ij+1)]+src[ii*width+ij]-src[ii*width+(ij+1)]-src[(ii+1)*width+ij])*di*dj
					+src[ii*width+ij]
				);
			}
			else if(ij+1<width && di==0 && dj!=0)
			{
				ret[i*retwidth+j]=
					(
					(src[ii*width+(ij+1)]-src[ii*width+ij] )*dj			
					+src[ii*width+ij]
				);
			}
			else if(ii+1 <height && di!=0 && dj==0)
			{
				ret[i*retwidth+j]=
					(		   
					(src[(ii+1)*width+ij]-src[ii*width+ij])*di
					+src[ii*width+ij]
				);
			}
			else
			{
				ret[i*retwidth+j]=src[ii*width+ij];
			}			
		}
	}
}


void binImg(unsigned char *src, int width, int height)
{
	int i,j;
	float mean=0;
	int cnt=0;
	for(i=0;i<height;i++)
	{
		for(j=0;j<width;j++)
		{
			mean+=src[i*width+j];
			cnt+=(src[i*width+j]>0?1:0);
		}
	}
	mean/=cnt;
	mean-=10;
	if(mean<0)mean=0;
	for(i=0;i<height;i++)
	{
		for(j=0;j<width;j++)
		{
			src[i*width+j]=src[i*width+j]>mean?255:0;
		}
	}
}

void zoom_smth(unsigned char *src, int width, int height, unsigned char *ret, int retwidth, int retheight)
{

	/*	int i,j;
	double ratiox,ratioy;
	double fi,fj,di,dj;
	int ii,ij;

	ratiox=retwidth*1.0/width;
	ratioy=retheight*1.0/height;

	for(i=0;i<retheight;i++)
	{
	for(j=0;j<retwidth;j++)
	{
	fi=i/ratioy;		fj=j/ratiox;
	ii=(int)fi;			ij=(int)fj;
	float sum=0;
	int cnt=0;
	for(int r=-1;r<2;r++)
	{	for(int c=-1;c<2;c++)
	{
	if(ii+r<height && ii+r>=0 && ij+c<width && ij+c>=0)
	{
	int wei=3-abs(r)-abs(c);
	sum+=wei*src[(ii+r)*width+ij+c];
	cnt+=wei;
	}
	}	
	}
	ret[i*retwidth+j]=sum/cnt;			
	}
	}*/


	int i,j;
	double ratiox,ratioy;
	double fi,fj,di,dj;
	int ii,ij;

	int smthwid=3;
	//ucsmooth(src,width,height,smthwid);
	//binImg(src,width,height);
	ratiox=retwidth*1.0/width;
	ratioy=retheight*1.0/height;

	for(i=0;i<retheight;i++)
	{
		for(j=0;j<retwidth;j++)
		{
			fi=i/ratioy;		fj=j/ratiox;
			ii=(int)fi;			ij=(int)fj;
			di=fi-ii;			dj=fj-ij;						
			if(ij+1<width && ii+1 <height)
			{
				ret[i*retwidth+j]=src[ii*width+ij]*(1-di)*(1-dj)+src[(1+ii)*width+(1+ij)]*(di)*(dj)+src[(1+ii)*width+(ij)]*(di)*(1-dj)+src[(ii)*width+(1+ij)]*(1-di)*(dj);

			}

			else
			{
				ret[i*retwidth+j]=src[ii*width+ij];
			}			
		}
	}
}

void ucsmooth(unsigned char *src, int width, int height,int smthwid)
{
	int i,j;
	double ratiox,ratioy;
	double fi,fj,di,dj;
	int ii,ij;
	unsigned char *cpimg=new unsigned char[width*height];

	for(i=0;i<height;i++)
	{
		for(j=0;j<width;j++)
		{
			float sum=0;
			int cnt=0;
			for(int r=-smthwid;r<smthwid+1;r++)
			{	for(int c=-smthwid;c<smthwid+1;c++)
			{
				if(i+r<height && i+r>=0 && j+c<width && j+c>=0)
				{
					int wei=2*smthwid+1-abs(r)-abs(c);
					sum+=wei*src[(i+r)*width+j+c];
					cnt+=wei;
				}
			}	
			}
			cpimg[i*width+j]=sum/cnt;			
		}
	}
	for(i=0;i<height;i++)
	{
		for(j=0;j<width;j++)
		{
			src[i*width+j]=cpimg[i*width+j];
		}
	}
	delete[]cpimg;
}

int normimg(unsigned char *ucimg,int width,int height,unsigned char*retimg,int normwid,int normhei,int cennmwid,int cennmhei)
{
	int i,j;
	memset(retimg,0,sizeof(unsigned char)*normwid*normhei);
	int left,right,top,bot;
	getLRTB(ucimg, width, height,&left,&right,&top,&bot);

	unsigned char *onlycenimg=new unsigned char[cennmwid*cennmhei];


	int realwid=right-left+1;
	int realhei=bot-top+1;
	if(realwid>realhei)
	{
		unsigned char *cenimg=new unsigned char[realwid*realwid];
		memset(cenimg,0,sizeof(unsigned char)*realwid*realwid);
		int addwid=(realwid-realhei)/2;

		for(int i=top;i<=bot;i++)
		{
			for(int j=left;j<=right;j++)
			{
				cenimg[(i-top+addwid)*realwid+j-left]=ucimg[i*width+j];
			}
		}

		zoom_smth(cenimg,realwid,realwid,onlycenimg,cennmwid,cennmhei);//	zmbyopencv(cenimg,realwid,realwid,onlycenimg,cennmwid,cennmhei);

		delete []cenimg;
	}
	else
	{
		unsigned char *cenimg=new unsigned char[realhei*realhei];
		memset(cenimg,0,sizeof(unsigned char)*realhei*realhei);
		int addwid=(realhei-realwid)/2;

		for(int i=top;i<=bot;i++)
		{
			for(int j=left;j<=right;j++)
			{
				cenimg[(i-top)*realhei+j-left+addwid]=ucimg[i*width+j];
			}
		}
		zoom_smth(cenimg,realhei,realhei,onlycenimg,cennmwid,cennmhei);//	zmbyopencv(cenimg,realhei,realhei,onlycenimg,cennmwid,cennmhei);
		delete []cenimg;
	}
	//	ucsmooth(onlycenimg,cennmwid,cennmhei,3);
	float cmx=(normwid-1)/2.0,cmy=(normhei-1)/2.0;
	//int issuc=calCentroid(onlycenimg,cennmwid,cennmhei,&cmx,&cmy);	
	//maxvalto255(onlycenimg,cennmwid,cennmhei);
	//if(!issuc)
	//{delete []onlycenimg;	return 0;}

	int distop=normhei/2.0-cmy;//(normhei-cennmhei)/2;
	int disleft=normwid/2.0-cmx;//(normwid-cennmwid)/2;
	if(distop<0)distop=0;
	if(disleft<0)disleft=0;
	if(distop>normhei-cennmhei)distop=normhei-cennmhei;
	if(disleft>normwid-cennmwid)disleft=normwid-cennmwid;
	for(int i=0;i<cennmhei;i++)
	{
		for(int j=0;j<cennmwid;j++)
		{
			retimg[(i+distop)*normwid+j+disleft]=onlycenimg[i*cennmwid+j];
		}
	}
	if(rand()%100<glo_addnoisepro)
		add_noise(retimg,normwid,normhei,cennmwid,cennmhei);
	int iiiii=0;

	if(rand()%100<glo_addnoisepro2)
	{
		int cntcnt=0;
		for(int li=0;li<cennmhei;li++)
		{
			for(int lj=0;lj<cennmwid;lj++)
			{
				if(retimg[li*cennmwid+lj]>0)
				{

					cntcnt++;
				}
			}
		}
		int maxnoisetimes=cntcnt*glo_addnoise2_stkpro;
		if(maxnoisetimes>1)
		{
			int noisetimes=rand()%(maxnoisetimes);

			while(iiiii<noisetimes)
			{	
				add_noise2(retimg,normwid,normhei,cennmwid,cennmhei);
				iiiii++;
			}
		}
	}
	delete []onlycenimg;

	return 1;


}


int normimg_string(unsigned char *ucimg,int width,int height,unsigned char*retimg,int normwid,int normhei)
{
	int i,j;
	memset(retimg,0,sizeof(unsigned char)*normwid*normhei);
	int left,right,top,bot;
	getLRTB(ucimg, width, height,&left,&right,&top,&bot);	
	int realwid=right-left+1;
	int realhei=bot-top+1;
	float prowid=realwid*1.0/normwid;
	float prohei=realhei*1.0/normhei;
	if(prowid>prohei)
	{

		realhei=prowid*normhei;
		unsigned char *cenimg=new unsigned char[realwid*realhei];
		memset(cenimg,0,sizeof(unsigned char)*realwid*realhei);
		for(int i=top;i<=bot;i++)
		{
			for(int j=left;j<=right;j++)
			{
				cenimg[(i-top)*realwid+j-left]=ucimg[i*width+j];
			}
		}
		zoom_smth(cenimg,realwid,realhei,retimg,normwid,normhei);
		delete []cenimg;
	}
	else
	{

		realwid=prohei*normwid;
		unsigned char *cenimg=new unsigned char[realwid*realhei];
		memset(cenimg,0,sizeof(unsigned char)*realwid*realhei);
		for(int i=top;i<=bot;i++)
		{
			for(int j=left;j<=right;j++)
			{
				cenimg[(i-top)*realwid+j-left]=ucimg[i*width+j];
			}
		}
		zoom_smth(cenimg,realwid,realhei,retimg,normwid,normhei);
		delete []cenimg;
	}


	return 1;
}
void rotate_point(int orix,int oriy,int cx,int cy,int &retx,int &rety,float a)
{

	retx= (orix - cx)*cos(a) - (oriy - cy)*sin(a) + cx ;
	rety= (orix - cx)*sin(a) + (oriy - cy)*cos(a) + cy ;
}

double ang_2line(int sx1,int sy1,int ex1,int ey1,
	int sx2,int sy2,int ex2,int ey2)
{
	float k1=0,k2=0;
	float dy1=ey1-sy1;
	float dx1=ex1-sx1;
	if(dx1!=0)
		k1=dy1/dx1;
	else
		k1=1000000000;

	float dy2=ey2-sy2;
	float dx2=ex2-sx2;
	if(dx2!=0)
		k2=dy2/dx2;
	else
		k2=1000000000;
	if(k1*k2==-1)
		return 3.14159/2;
	else
		return atan( fabs(  (k2-k1)/(1+k1*k2)  ) );


}
int calCentroid(unsigned char* data, int width, int height, float *x, float *y) 
{ 
	int i, j; 
	float m00 = 0, m10 = 0, m01 = 0; 
	for(i = 0;i < height;i++) 
	{ 
		for(j = 0;j < width;j++) 
		{ 
			int tmp = data[i * width + j]; 
			m00 += tmp; 
			m10 += tmp * j; 
			m01 += tmp * i; 
		} 
	} 
	if(m00 != 0) 
	{ 
		*x = m10 / m00; 
		*y = m01 / m00; 
		return 1;
	} 
	else
	{
		* x=width/2;
		*y=height/2;
		return 0;
	}
} 


void getLRTB(unsigned char *img,int width,int height,
	int *retleft,int *retright,int *rettop,int *retbot)
{
	int i,j;
	int cnt=0;
	int strokewid=0;
	int left=-1,right=-1,top=-1,bot=-1;
	for(i=0;i<height;i++)
	{
		cnt=0;
		for(j=0;j<width;j++)
		{
			if(img[i*width+j]>0)
				cnt++;
		}
		if(cnt>strokewid/2)
		{ *rettop=i;break; }
	}
	for(i=height-1;i>=0;i--)
	{
		cnt=0;
		for(j=0;j<width;j++)
		{
			if(img[i*width+j]>0)
				cnt++;
		}
		if(cnt>strokewid/2)
		{ *retbot=i;break; }
	}
	for(j=0;j<width;j++)
	{
		cnt=0;
		for(i=0;i<height;i++)
		{
			if(img[i*width+j]>0)
				cnt++;
		}
		if(cnt>strokewid/2)
		{ *retleft=j;break;}
	}
	for(j=width-1;j>=0;j--)
	{
		cnt=0;
		for(i=0;i<height;i++)
		{
			if(img[i*width+j]>0)
				cnt++;
		}
		if(cnt>strokewid/2)
		{ *retright=j;break;}
	}
}
bool partitionBigGrp(Group*&allgroup_big,int groupnum1,bool *isconnext)
{
	int i,j;
	double curmax_zmpro=max_part_zoompro;
	double curmin_zmpro=min_part_zoompro;
	if(allgroup_big[0].strokenum==1)
	{
		curmax_zmpro=max_ss_zoompro;
		curmin_zmpro=min_ss_zoompro;
	}
	if(strcmp(allgroup_big[0].grpname,"heng_lr")==0
		||strcmp(allgroup_big[0].grpname,"heng_rl")==0
		||strcmp(allgroup_big[0].grpname,"shu_tb")==0
		||strcmp(allgroup_big[0].grpname,"shu_bt")==0
		||strcmp(allgroup_big[0].grpname,"pie_tb")==0
		||strcmp(allgroup_big[0].grpname,"pie_bt")==0
		||strcmp(allgroup_big[0].grpname,"na_tb")==0
		||strcmp(allgroup_big[0].grpname,"na_bt")==0
		)
		curmin_zmpro=glo_canvanish_stk_minpro;

	double rotval=realGuassGenerate((max_part_rotang_left+max_part_rotang_right)/2,(max_part_rotang_right-max_part_rotang_left)/6,max_part_rotang_left,max_part_rotang_right);//(1-rand()*2.0/RAND_MAX);


	float curzmprolr=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	float curzmprotb=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;

	if(allgroup_big[0].strokenum==1)
	{
		rotval=realGuassGenerate((max_ss_rotang_left+max_ss_rotang_right)/2,(max_ss_rotang_right-max_ss_rotang_left)/6,max_ss_rotang_left_starts,max_ss_rotang_right_starts);//(1-rand()*2.0/RAND_MAX);
	}

	glo_prev_rotang=rotval;

	glo_prev_sx=allgroup_big[0].draw_strokes[allgroup_big[0].strokenum-1].ptscol;
	glo_prev_sy=allgroup_big[0].draw_strokes[allgroup_big[0].strokenum-1].ptsrow;
	glo_prev_ex=allgroup_big[0].draw_strokes[allgroup_big[0].strokenum-1].ptecol;
	glo_prev_ey=allgroup_big[0].draw_strokes[allgroup_big[0].strokenum-1].pterow;

	float cuoqiexang=realGuassGenerate((glo_cuoqiex_leftang+glo_cuoqiex_rightang)/2,(glo_cuoqiex_rightang-glo_cuoqiex_leftang)/6,glo_cuoqiex_leftang,glo_cuoqiex_rightang);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
	float cuoqieyang=realGuassGenerate((glo_cuoqiey_topang+glo_cuoqiey_botang)/2,(glo_cuoqiey_botang-glo_cuoqiey_topang)/6,glo_cuoqiey_botang,glo_cuoqiey_topang);

	int oripostop=allgroup_big[0].top;
	int oriposleft=allgroup_big[0].left;

	updateGrp_draw(&(allgroup_big[0]));
	rotatePart3(&(allgroup_big[0]),rotval); 
	updateGrp_draw(&(allgroup_big[0]));
	if(allgroup_big[0].strokenum>1)
		zoomPart2_s(&(allgroup_big[0]),curzmprolr,curzmprotb,allgroup_big[0].top,allgroup_big[0].left);
	else
	{
		float smlpro=curzmprolr>curzmprotb?curzmprolr:curzmprotb;
		zoomPart2_s(&(allgroup_big[0]),smlpro,smlpro,allgroup_big[0].top,allgroup_big[0].left);
	}
	updateGrp_draw(&(allgroup_big[0]));

	if(allgroup_big[0].strokenum>1)
	{
		cuoqie_x(&(allgroup_big[0]),cuoqiexang);
		updateGrp_draw(&(allgroup_big[0]));
		cuoqie_y(&(allgroup_big[0]),cuoqieyang);
		updateGrp_draw(&(allgroup_big[0]));
	}

	int curwid=allgroup_big[0].right-allgroup_big[0].left+1;
	int curhei=allgroup_big[0].bot-allgroup_big[0].top+1;

	shiftPart2(&(allgroup_big[0]),oriposleft-allgroup_big[0].left,oripostop-allgroup_big[0].top);
	updateGrp_draw(&(allgroup_big[0]));

	allgroup_big[0].partition_top=oripostop;
	allgroup_big[0].partition_left=oriposleft;
	allgroup_big[0].partition_wid=curwid;
	allgroup_big[0].partition_hei=curhei;



	for(int i=1;i<groupnum1;i++)
	{
		//ȷ��allgroup_big[i]�Ĵ�С��Ȼ�󿴿������С��λ�÷�û��û�еĻ�����ȷ����С
		if(isconnext[i])
		{

			float curzmprolr,curzmprotb;

			double curmax_zmpro=max_part_zoompro;
			double curmin_zmpro=min_part_zoompro;
			if(allgroup_big[i].strokenum==1)
			{
				curmax_zmpro=max_ss_zoompro;
				curmin_zmpro=min_ss_zoompro;
			}
			if(strcmp(allgroup_big[i].grpname,"heng_lr")==0
				||strcmp(allgroup_big[i].grpname,"heng_rl")==0
				||strcmp(allgroup_big[i].grpname,"shu_tb")==0
				||strcmp(allgroup_big[i].grpname,"shu_bt")==0
				||strcmp(allgroup_big[i].grpname,"pie_tb")==0
				||strcmp(allgroup_big[i].grpname,"pie_bt")==0
				||strcmp(allgroup_big[i].grpname,"na_tb")==0
				||strcmp(allgroup_big[i].grpname,"na_bt")==0
				)
			{
				curmin_zmpro=glo_canvanish_stk_minpro;
			}

			rotval=realGuassGenerate((max_part_rotang_left+max_part_rotang_right)/2,(max_part_rotang_right-max_part_rotang_left)/6,max_part_rotang_left,max_part_rotang_right);//(1-rand()*2.0/RAND_MAX);

			if(allgroup_big[i].strokenum==1)
			{
				double oriang=ang_2line(
					glo_prev_sx,
					glo_prev_sy,
					glo_prev_ex,
					glo_prev_ey,

					allgroup_big[i].draw_strokes[0].ptscol,allgroup_big[i].draw_strokes[0].ptsrow,
					allgroup_big[i].draw_strokes[0].ptecol,allgroup_big[i].draw_strokes[0].pterow);

				if(abs(oriang)<glo_zeroang_min)
				{
					if(rand()%2==0)
						rotval=glo_prev_rotang;
					else
					{
						rotval=realGuassGenerate(0,0,max_ss_rotang_left/2,max_ss_rotang_right/2);//(1-rand()*2.0/RAND_MAX);
						rotval=glo_prev_rotang+rotval;
					}
					glo_prev_rotang=rotval;
				}
				else
				{
					if(fabs(oriang)/glo_rotang_pro>max_ss_rotang_right)

						rotval=realGuassGenerate((max_ss_rotang_left+max_ss_rotang_right)/2,(max_ss_rotang_right-max_ss_rotang_left)/6,max_ss_rotang_left,max_ss_rotang_right);//(1-rand()*2.0/RAND_MAX);
					else
						rotval=realGuassGenerate((max_ss_rotang_left+max_ss_rotang_right)/2,(max_ss_rotang_right-max_ss_rotang_left)/6,-fabs(oriang)/glo_rotang_pro,fabs(oriang)/glo_rotang_pro);//(1-rand()*2.0/RAND_MAX);

					glo_prev_rotang=rotval;
				}

				glo_prev_sx=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptscol;
				glo_prev_sy=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptsrow;
				glo_prev_ex=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptecol;
				glo_prev_ey=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].pterow;
			}

			curzmprolr=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
			curzmprotb=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
			updateGrp_draw(&(allgroup_big[i]));
			rotatePart3(&(allgroup_big[i]),rotval); 
			updateGrp_draw(&(allgroup_big[i]));

			if(allgroup_big[i].strokenum>1)
				zoomPart2_s(&(allgroup_big[i]),curzmprolr,curzmprotb,allgroup_big[i].top,allgroup_big[i].left);
			else
			{
				float smlpro=curzmprolr>curzmprotb?curzmprolr:curzmprotb;

				zoomPart2_s(&(allgroup_big[i]),smlpro,smlpro,allgroup_big[i].top,allgroup_big[i].left);
			}


			updateGrp_draw(&(allgroup_big[i]));

			float cuoqiexang=realGuassGenerate((glo_cuoqiex_leftang+glo_cuoqiex_rightang)/2,(glo_cuoqiex_rightang-glo_cuoqiex_leftang)/6,glo_cuoqiex_leftang,glo_cuoqiex_rightang);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
			float cuoqieyang=realGuassGenerate((glo_cuoqiey_topang+glo_cuoqiey_botang)/2,(glo_cuoqiey_botang-glo_cuoqiey_topang)/6,glo_cuoqiey_botang,glo_cuoqiey_topang);

			if(allgroup_big[i].strokenum>1)
			{
				cuoqie_x(&(allgroup_big[i]),cuoqiexang);
				updateGrp_draw(&(allgroup_big[i]));
				cuoqie_y(&(allgroup_big[i]),cuoqieyang);
				updateGrp_draw(&(allgroup_big[i]));
			}
			int curwid=allgroup_big[i].right-allgroup_big[i].left+1;
			int curhei=allgroup_big[i].bot-allgroup_big[i].top+1;
			int maxwid=curwid>curhei?curwid:curhei;
			allgroup_big[i].partition_wid=curwid;
			allgroup_big[i].partition_hei=curhei;



			int curright=findRightPos(&(allgroup_big[i]),allgroup_big);
			int curleft=findLeftPos(&(allgroup_big[i]),allgroup_big);
			int curtop=findTopPos(&(allgroup_big[i]),allgroup_big);
			int curbot=findBotPos(&(allgroup_big[i]),allgroup_big);

			allgroup_big[i].draw_strokes[0].ptecol=allgroup_big[i].draw_strokes[0].ptecol+(allgroup_big[i-1].draw_strokes[0].ptecol-allgroup_big[i].draw_strokes[0].ptscol);
			allgroup_big[i].draw_strokes[0].pterow=allgroup_big[i].draw_strokes[0].pterow+(allgroup_big[i-1].draw_strokes[0].pterow-allgroup_big[i].draw_strokes[0].ptsrow);		
			allgroup_big[i].draw_strokes[0].ptscol=allgroup_big[i-1].draw_strokes[0].ptecol;
			allgroup_big[i].draw_strokes[0].ptsrow=allgroup_big[i-1].draw_strokes[0].pterow;	

			if(allgroup_big[i].draw_strokes[0].ptscol>=curleft&&allgroup_big[i].draw_strokes[0].ptscol<=curright
				&&allgroup_big[i].draw_strokes[0].ptecol>=curleft&&allgroup_big[i].draw_strokes[0].ptecol<=curright
				&&allgroup_big[i].draw_strokes[0].ptsrow>=curtop&&allgroup_big[i].draw_strokes[0].ptsrow<=curbot
				&&allgroup_big[i].draw_strokes[0].pterow>=curtop&&allgroup_big[i].draw_strokes[0].pterow<=curbot)
			{




				updateGrp_draw(&(allgroup_big[i]));

				allgroup_big[i].partition_top=allgroup_big[i].top;
				allgroup_big[i].partition_left=allgroup_big[i].left;
				allgroup_big[i].partition_wid=allgroup_big[i].right-allgroup_big[i].left+1;
				allgroup_big[i].partition_hei=allgroup_big[i].bot-allgroup_big[i].top+1;
			}
			else
			{
				return false;
			}


		}
		else
		{
			float curzmprolr,curzmprotb;
			int cntcnt=0;
			while(cntcnt<1)
			{

				double curmax_zmpro=max_part_zoompro;
				double curmin_zmpro=min_part_zoompro;
				if(allgroup_big[i].strokenum==1)
				{
					curmax_zmpro=max_ss_zoompro;
					curmin_zmpro=min_ss_zoompro;
				}
				if(strcmp(allgroup_big[i].grpname,"heng_lr")==0
					||strcmp(allgroup_big[i].grpname,"heng_rl")==0
					||strcmp(allgroup_big[i].grpname,"shu_tb")==0
					||strcmp(allgroup_big[i].grpname,"shu_bt")==0
					||strcmp(allgroup_big[i].grpname,"pie_tb")==0
					||strcmp(allgroup_big[i].grpname,"pie_bt")==0
					||strcmp(allgroup_big[i].grpname,"na_tb")==0
					||strcmp(allgroup_big[i].grpname,"na_bt")==0
					)
				{
					curmin_zmpro=glo_canvanish_stk_minpro;
				}


				//int aaaa=strcmp(allgroup_big[i].grpname,"heng_lr");

				rotval=realGuassGenerate((max_part_rotang_left+max_part_rotang_right)/2,(max_part_rotang_right-max_part_rotang_left)/6,max_part_rotang_left,max_part_rotang_right);//(1-rand()*2.0/RAND_MAX);


				if(allgroup_big[i].strokenum==1)
				{
					rotval=realGuassGenerate((max_ss_rotang_left+max_ss_rotang_right)/2,(max_ss_rotang_right-max_ss_rotang_left)/6,max_ss_rotang_left_starts,max_ss_rotang_right_starts);//(1-rand()*2.0/RAND_MAX);
					glo_prev_rotang=rotval;

					glo_prev_sx=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptscol;
					glo_prev_sy=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptsrow;
					glo_prev_ex=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].ptecol;
					glo_prev_ey=allgroup_big[i].draw_strokes[allgroup_big[i].strokenum-1].pterow;

				}


				curzmprolr=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
				curzmprotb=realGuassGenerate((curmax_zmpro+curmin_zmpro)/2,(curmax_zmpro-curmin_zmpro)/6,curmin_zmpro,curmax_zmpro);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
				updateGrp_draw(&(allgroup_big[i]));
				rotatePart3(&(allgroup_big[i]),rotval); 
				updateGrp_draw(&(allgroup_big[i]));

				if(allgroup_big[i].strokenum>1)
					zoomPart2_s(&(allgroup_big[i]),curzmprolr,curzmprotb,allgroup_big[i].top,allgroup_big[i].left);
				else
				{
					float smlpro=curzmprolr>curzmprotb?curzmprolr:curzmprotb;

					zoomPart2_s(&(allgroup_big[i]),smlpro,smlpro,allgroup_big[i].top,allgroup_big[i].left);
				}


				updateGrp_draw(&(allgroup_big[i]));



				float cuoqiexang=realGuassGenerate((glo_cuoqiex_leftang+glo_cuoqiex_rightang)/2,(glo_cuoqiex_rightang-glo_cuoqiex_leftang)/6,glo_cuoqiex_leftang,glo_cuoqiex_rightang);//rand()*1.0/RAND_MAX*(curmax_zmpro-curmin_zmpro)+curmin_zmpro;
				float cuoqieyang=realGuassGenerate((glo_cuoqiey_topang+glo_cuoqiey_botang)/2,(glo_cuoqiey_botang-glo_cuoqiey_topang)/6,glo_cuoqiey_botang,glo_cuoqiey_topang);

				if(allgroup_big[i].strokenum>1)
				{
					cuoqie_x(&(allgroup_big[i]),cuoqiexang);
					updateGrp_draw(&(allgroup_big[i]));
					cuoqie_y(&(allgroup_big[i]),cuoqieyang);
					updateGrp_draw(&(allgroup_big[i]));
				}


				int curwid=allgroup_big[i].right-allgroup_big[i].left+1;
				int curhei=allgroup_big[i].bot-allgroup_big[i].top+1;
				allgroup_big[i].partition_wid=curwid;
				allgroup_big[i].partition_hei=curhei;

				int curright=findRightPos(&(allgroup_big[i]),allgroup_big);
				int curleft=findLeftPos(&(allgroup_big[i]),allgroup_big);
				int curtop=findTopPos(&(allgroup_big[i]),allgroup_big);
				int curbot=findBotPos(&(allgroup_big[i]),allgroup_big);
				//if(curright>9999||curbot>9999||curleft<-9999||curtop<-9999)
				//	//AfxMessageBox(L"Unconstraint Stroke!");
				if(curleft+curwid<=curright &&curtop+curhei<=curbot)
				{
					curwid=allgroup_big[i].right-allgroup_big[i].left+1;
					curhei=allgroup_big[i].bot-allgroup_big[i].top+1;
					allgroup_big[i].partition_wid=curwid;
					allgroup_big[i].partition_hei=curhei;
					allgroup_big[i].partition_top=realGuassGenerate(curtop+(curbot-curhei-curtop)/2.0,(curbot-curhei-curtop)/6.0,curtop,curbot-curhei);// curtop+(curbot-curhei-curtop)*(rand()*1.0/RAND_MAX);// 
					allgroup_big[i].partition_left=realGuassGenerate(curleft+(curright-curwid-curleft)/2.0,(curright-curwid-curleft)/6.0,curleft,curright-curwid);//curleft+(curright-curwid-curleft)*(rand()*1.0/RAND_MAX);//
					shiftPart2(&(allgroup_big[i]),allgroup_big[i].partition_left-allgroup_big[i].left,allgroup_big[i].partition_top-allgroup_big[i].top);
					updateGrp_draw(&(allgroup_big[i]));
					break;
				}
				cntcnt++;
			}
			if(cntcnt==1)
				return false;
		}

	}

	return true;

}



int findRightPos(Group *grp,Group*allgroup_big)
{
	int i,j;
	int curright=100000;
	for(int j=0;j<grp->ptind_right_num;j++)
	{
		int fixgrp=grp->ptind_right_grpidx[j];
		int fixstroke=grp->ptind_right[j];
		float fixwei_self=grp->ptind_right_wei_self[j];
		float fixwei=grp->ptind_right_wei[j];
		int worh_self=grp->ptind_right_worh_self[j];
		int worh=grp->ptind_right_worh[j];
		float dis=grp->ptind_right_dis[j];

		int strokeidx=fixstroke/2;
		int isstart=fixstroke%2;

		int ihei=allgroup_big[fixgrp].partition_hei;  
		int iwid=allgroup_big[fixgrp].partition_wid;

		int selfhei=grp->partition_hei;
		int selfwid=grp->partition_wid;

		int multi_self_wid=selfhei;
		if(worh_self==0)
			multi_self_wid=selfwid;

		int multi_wid=ihei;
		if(worh==0)
			multi_wid=iwid;

		int curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptecol;
		if(isstart==0)
			curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptscol;

		int tmpright=curpts_ps+fixwei*multi_wid+fixwei_self*multi_self_wid+dis*glo_grp_dis_wei;
		if(tmpright<curright)
			curright=tmpright;

	}
	return curright;
}


int findBotPos(Group *grp,Group*allgroup_big)
{
	int i,j;
	int curbot=100000;
	for(int j=0;j<grp->ptind_bot_num;j++)
	{
		int fixgrp=grp->ptind_bot_grpidx[j];
		int fixstroke=grp->ptind_bot[j];
		float fixwei_self=grp->ptind_bot_wei_self[j];
		float fixwei=grp->ptind_bot_wei[j];
		int worh_self=grp->ptind_bot_worh_self[j];
		int worh=grp->ptind_bot_worh[j];
		float dis=grp->ptind_bot_dis[j];

		int strokeidx=fixstroke/2;
		int isstart=fixstroke%2;

		int ihei=allgroup_big[fixgrp].partition_hei;  
		int iwid=allgroup_big[fixgrp].partition_wid;

		int selfhei=grp->partition_hei;
		int selfwid=grp->partition_wid;

		int multi_self_wid=selfhei;
		if(worh_self==0)
			multi_self_wid=selfwid;

		int multi_wid=ihei;
		if(worh==0)
			multi_wid=iwid;

		int curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].pterow;
		if(isstart==0)
			curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptsrow;

		int tmpbot=curpts_ps+fixwei*multi_wid+fixwei_self*multi_self_wid+dis*glo_grp_dis_wei;
		if(tmpbot<curbot)
			curbot=tmpbot;

	}
	return curbot;
}


int findTopPos(Group *grp,Group*allgroup_big)
{
	int i,j;
	int curtop=-100000;
	for(int j=0;j<grp->ptind_top_num;j++)
	{
		int fixgrp=grp->ptind_top_grpidx[j];
		int fixstroke=grp->ptind_top[j];
		float fixwei_self=grp->ptind_top_wei_self[j];
		float fixwei=grp->ptind_top_wei[j];
		int worh_self=grp->ptind_top_worh_self[j];
		int worh=grp->ptind_top_worh[j];
		float dis=grp->ptind_top_dis[j];

		int strokeidx=fixstroke/2;
		int isstart=fixstroke%2;

		int ihei=allgroup_big[fixgrp].partition_hei;  
		int iwid=allgroup_big[fixgrp].partition_wid;

		int selfhei=grp->partition_hei;
		int selfwid=grp->partition_wid;

		int multi_self_wid=selfhei;
		if(worh_self==0)
			multi_self_wid=selfwid;

		int multi_wid=ihei;
		if(worh==0)
			multi_wid=iwid;

		int curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].pterow;
		if(isstart==0)
			curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptsrow;

		int tmptop=curpts_ps+fixwei*multi_wid+fixwei_self*multi_self_wid+dis*glo_grp_dis_wei;
		if(tmptop>curtop)
			curtop=tmptop;

	}
	return curtop;
}
int findLeftPos(Group *grp,Group*allgroup_big)
{
	int i,j;
	int curleft=-100000;
	for(int j=0;j<grp->ptind_left_num;j++)
	{
		int fixgrp=grp->ptind_left_grpidx[j];
		int fixstroke=grp->ptind_left[j];
		float fixwei_self=grp->ptind_left_wei_self[j];
		float fixwei=grp->ptind_left_wei[j];
		int worh_self=grp->ptind_left_worh_self[j];
		int worh=grp->ptind_left_worh[j];
		float dis=grp->ptind_left_dis[j];

		int strokeidx=fixstroke/2;
		int isstart=fixstroke%2;
		int ihei=allgroup_big[fixgrp].partition_hei;  
		int iwid=allgroup_big[fixgrp].partition_wid;
		int selfhei=grp->partition_hei;
		int selfwid=grp->partition_wid;
		int multi_self_wid=selfhei;
		if(worh_self==0)
			multi_self_wid=selfwid;
		int multi_wid=ihei;
		if(worh==0)
			multi_wid=iwid;
		int curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptecol;
		if(isstart==0)
			curpts_ps=allgroup_big[fixgrp].draw_strokes[strokeidx].ptscol;
		int tmpleft=curpts_ps+fixwei*multi_wid+fixwei_self*multi_self_wid+dis*glo_grp_dis_wei;

		if(tmpleft>curleft)
			curleft=tmpleft;

	}
	return curleft;
}


void updateGrp_draw(Group *grp)
{
	int i,j;
	int curtop=10000,curbot=-100000,curleft=100000,curright=-100000;
	int curtopidx,curbotidx,curleftidx,currightidx;
	for(int j=0;j<grp->strokenum;j++)
	{
		if(grp->draw_strokes[j].ptsrow<curtop)
		{	
			curtop=grp->draw_strokes[j].ptsrow;
			curtopidx=j;
		}
		if(grp->draw_strokes[j].ptsrow>curbot)
		{	curbot=grp->draw_strokes[j].ptsrow;
		curbotidx=j;
		}
		if(grp->draw_strokes[j].pterow<curtop)
		{	curtop=grp->draw_strokes[j].pterow;curtopidx=j;
		}
		if(grp->draw_strokes[j].pterow>curbot)
		{	curbot=grp->draw_strokes[j].pterow;curbotidx=j;
		}

		if(grp->draw_strokes[j].ptscol<curleft)
		{	curleft=grp->draw_strokes[j].ptscol;curleftidx=j;
		}
		if(grp->draw_strokes[j].ptscol>curright)
		{	curright=grp->draw_strokes[j].ptscol;currightidx=j;
		}
		if(grp->draw_strokes[j].ptecol<curleft)
		{	curleft=grp->draw_strokes[j].ptecol;curleftidx=j;
		}
		if(grp->draw_strokes[j].ptecol>curright)
		{	curright=grp->draw_strokes[j].ptecol;currightidx=j;
		}

	}
	grp->top=curtop;
	grp->bot=curbot;
	grp->left=curleft;
	grp->right=curright;
	grp->partition_top=curtop;
	grp->partition_left=curleft;
	grp->partition_hei=curbot-curtop+1;
	grp->partition_wid=curright-curleft+1;

	grp->top_ssidx=curtopidx;
	grp->bot_ssidx=curbotidx;
	grp->left_ssidx=curleftidx;
	grp->right_ssidx=currightidx;

}
void randperm(int n,int **idx)
{	
	int i,j;
	*idx=new int[n];
	//	srand((int)time(NULL));
	/*	(*idx)[0]=rand()%n;
	for(i=1;i<n;i++)
	{
	(*idx)[i]=rand()%n;
	for(j=0;j<i;j++)
	{
	if((*idx)[i]==(*idx)[j])
	{
	i--;
	break;
	}
	}
	}*/
	for(i=0;i<n;i++)
	{
		(*idx)[i]=i;
	}
}
void ck_stroke_conornot_draw(Group *onegroup)
{

	for(int j=0;j<onegroup->strokenum-1;j++)
	{
		onegroup->con_ss[j].conNum=2;
		onegroup->con_ss[j].conInd[0]=j;
		if(start_end_con|| (abs(onegroup->draw_strokes[j].pterow-onegroup->draw_strokes[j+1].ptsrow)<=5
			&&abs(onegroup->draw_strokes[j].ptecol-onegroup->draw_strokes[j+1].ptscol)<=5
			)
			)//������ʻ����غϵĵ㣬�򲻿ɷ�
		{
			onegroup->con_ss[j].conInd[1]=j+1;
			onegroup->con_ss[j].canCut=0;
		}
		else
		{
			onegroup->con_ss[j].conInd[1]=j+1;
			onegroup->con_ss[j].canCut=1;
		}
		//	}
	}
}


void ck_stroke_conornot(Group *onegroup)
{
	int i,j;

	for(int j=0;j<onegroup->strokenum-1;j++)
	{
		onegroup->con_ss[j].conNum=2;
		onegroup->con_ss[j].conInd[0]=j;
		if( 
			(abs(onegroup->strokes[j].pterow-onegroup->strokes[j+1].ptsrow)<=5
			&&abs(onegroup->strokes[j].ptecol-onegroup->strokes[j+1].ptscol)<=5
			)
			)//������ʻ����غϵĵ㣬�򲻿ɷ�
		{
			onegroup->con_ss[j].conInd[1]=j+1;
			onegroup->con_ss[j].canCut=0;
		}
		else
		{
			onegroup->con_ss[j].conInd[1]=j+1;
			onegroup->con_ss[j].canCut=1;
		}
		//	}
	}
}

void copy_allgroup_toonegroup(Group* onegroup,Group*allgroup,int*  isendstroke_ofpart,int allgroupnum,int allstrokenum)
{
	int i,j;
	int cntcon=0;
	int base_stkidx=0;

	int pregrp_lastidx;
	int canbeendofpart=0;
	if(allstrokenum>allgroupnum)
	{
		canbeendofpart=1;
	}
	for(i=0;i<allgroupnum;i++)
	{		
		//	randperm(allgroup[i].strokenum,&(allgroup[i].rdidx));
		for(int j=0;j<allgroup[i].strokenum;j++)
		{
			onegroup->strokes[base_stkidx+j].ptscol=allgroup[i].strokes[j].ptscol;
			onegroup->strokes[base_stkidx+j].ptsrow=allgroup[i].strokes[j].ptsrow;
			onegroup->strokes[base_stkidx+j].ptecol=allgroup[i].strokes[j].ptecol;
			onegroup->strokes[base_stkidx+j].pterow=allgroup[i].strokes[j].pterow;


			if(j<allgroup[i].strokenum-1 && allgroup[i].con_ss[j].canCut==0)
			{
				onegroup->con_ss[base_stkidx+j].conNum=1;
				onegroup->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				onegroup->con_ss[base_stkidx+j].canCut=0;
			}
			else
			{
				onegroup->con_ss[base_stkidx+j].conNum=1;
				onegroup->con_ss[base_stkidx+j].conInd[1]=base_stkidx+j+1;
				onegroup->con_ss[base_stkidx+j].canCut=1;
			}

			onegroup->draw_strokes[base_stkidx+j].ptscol=allgroup[i].draw_strokes[j].ptscol;
			onegroup->draw_strokes[base_stkidx+j].ptsrow=allgroup[i].draw_strokes[j].ptsrow;
			onegroup->draw_strokes[base_stkidx+j].ptecol=allgroup[i].draw_strokes[j].ptecol;
			onegroup->draw_strokes[base_stkidx+j].pterow=allgroup[i].draw_strokes[j].pterow;


			isendstroke_ofpart[base_stkidx+j]=0;
		}
		onegroup->con_ss[base_stkidx+allgroup[i].strokenum-1].conNum=1;
		onegroup->con_ss[base_stkidx+allgroup[i].strokenum-1].conInd[1]=0;
		onegroup->con_ss[base_stkidx+allgroup[i].strokenum-1].canCut=1;
		//if(allgroup[i].strokenum>1)
		isendstroke_ofpart[base_stkidx+allgroup[i].strokenum-1]=canbeendofpart;
		//else
		//	isendstroke_ofpart[base_stkidx+allgroup[i].strokenum-1]=0;

		base_stkidx+=allgroup[i].strokenum;
	}
	onegroup->strokenum=base_stkidx;
}
double getdis(int col1,int row1,int col2 ,int row2)
{
	return sqrt(1.0*(col1-col2)*(col1-col2)+(row1-row2)*(row1-row2));
}

void cal_rel_intersect_twostrokes(Group *groupi,Group *groupk,int k)
{
	int threspro=5;
	int k_wid=1+groupk->right-groupk->left;
	int k_hei=1+groupk->bot-groupk->top;
	int i_wid=1+groupi->right-groupi->left;
	int i_hei=1+groupi->bot-groupi->top;
	double shift_dis_wei=1;

	if(k_wid/k_hei>threspro)//k is -
	{
		int intecol,interow;
		bool isinte=intersect3(
			groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
		if(isinte)//1   +
		{
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
			float disitop=interow-groupi->top;
			float disibot=groupi->bot-interow;

			groupi->ptind_top         [groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;


			groupi->ptind_bot         [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			float diskleft=intecol-groupk->left;
			float diskright=groupk->right-intecol;

			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=0;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei[groupi->ptind_left_num]=glo_stroke_inte_minpro;
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei[groupi->ptind_left_num]=glo_stroke_inte_minpro;
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}


			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_right         [groupi->ptind_right_num]=1;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_stroke_inte_minpro;
				groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}else
			{
				groupi->ptind_right         [groupi->ptind_right_num]=0;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_stroke_inte_minpro;
				groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}

		else if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupi->left,groupk->strokes[0].ptsrow))//2   /-  \-
		{

			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupi->left,groupk->strokes[0].ptsrow,intecol,interow);

			float disitop=interow-groupi->top;
			float disibot=groupi->bot-interow;

			groupi->ptind_top         [groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;


			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=0;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	

				groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_dis_inte_pie_heng;
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;	

				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	

				groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_dis_inte_pie_heng;
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;		
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}

			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_right         [groupi->ptind_right_num]=0;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}else
			{
				groupi->ptind_right         [groupi->ptind_right_num]=1;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}

		}
		else//3   -\  -/
		{

			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupi->right,groupk->strokes[0].pterow,intecol,interow);

			float disitop=interow-groupi->top;
			float disibot=groupi->bot-interow;

			groupi->ptind_top         [groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;


			groupi->ptind_bot         [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_worh   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;




			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=0;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;		
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}

			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_right         [groupi->ptind_right_num]=1;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

				groupi->ptind_right_wei[groupi->ptind_right_num]=glo_dis_inte_pie_heng;
				groupi->ptind_right_worh[groupi->ptind_right_num]=0;
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}else
			{
				groupi->ptind_right         [groupi->ptind_right_num]=0;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
				groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

				groupi->ptind_right_wei[groupi->ptind_right_num]=glo_dis_inte_pie_heng;
				groupi->ptind_right_worh[groupi->ptind_right_num]=0;
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}
	}
	else if(k_hei/k_wid>threspro)//k is |
	{
		int intecol,interow;
		bool isinte=intersect3(
			groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
		if(isinte)//1 +
		{
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
			float disileft=intecol-groupi->left;
			float disiright=groupi->right-intecol;

			groupi->ptind_left         [groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			groupi->ptind_right         [groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			float disktop=interow-groupk->top;
			float diskbot=groupk->bot-interow;

			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=0;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
				groupi->ptind_top_worh   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
				groupi->ptind_top_worh   [groupi->ptind_top_num]=1;		
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}


			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
				groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}else
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=0;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
				groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
		else if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupk->strokes[0].ptscol,groupi->top))//  /| 
		{
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupi->top,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

			float disileft=intecol-groupi->left;
			float disiright=groupi->right-intecol;

			groupi->ptind_left         [groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			groupi->ptind_right         [groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;



			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=0;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_dis_inte_pie_heng;
				groupi->ptind_top_worh[groupi->ptind_top_num]=1;
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_dis_inte_pie_heng;
				groupi->ptind_top_worh[groupi->ptind_top_num]=1;
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}

			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=0;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}else
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}

		}

		else//3 \|  |/
		{
			int intecol,interow;
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupi->bot,intecol,interow);			
			float disileft=intecol-groupi->left;
			float disiright=groupi->right-intecol;

			groupi->ptind_left         [groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-1;
			groupi->ptind_left_worh[groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			groupi->ptind_right         [groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
			groupi->ptind_right         [groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
			groupi->ptind_right_wei[groupi->ptind_right_num]=1;
			groupi->ptind_right_worh[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;


			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=0;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
				groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}

			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_wei[groupi->ptind_bot_num]=glo_dis_inte_pie_heng;
				groupi->ptind_bot_worh [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}else
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=0;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
				groupi->ptind_bot_worh_self [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_wei[groupi->ptind_bot_num]=glo_dis_inte_pie_heng;
				groupi->ptind_bot_worh [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
	}
	else if((groupk->top==groupk->strokes[0].ptsrow && groupk->right==groupk->strokes[0].ptscol)
		||(groupk->top==groupk->strokes[0].pterow && groupk->right==groupk->strokes[0].ptecol))//k is /
	{
		int intecol,interow;
		bool isinte=intersect3(
			groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
		if(isinte)//1 5 7   -/  |/  \/
		{
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

			if(i_wid/i_hei>threspro)//1 heng inte pie
			{
				float disileft=intecol-groupk->left;
				float disiright=groupk->right-intecol;

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				float disktop=interow-groupi->top;
				float diskbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
					groupi->ptind_top_worh[groupi->ptind_top_num]=1;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
					groupi->ptind_top_worh[groupi->ptind_top_num]=1;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}


				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


			}else if(i_hei/i_wid>threspro)//5 shu inte pie 
			{

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
			else//7  x   na inte pie
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
		}
		else if(i_hei/i_wid>threspro)//2 3 i is shu |  k is pie / does not intersect
		{
			if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupk->bot,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow))//2 shu topper
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupk->bot,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				float diskleft=intecol-groupk->left;
				float diskright=groupk->right-intecol;

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{	
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{	
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}


				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}

			}
			else//3 shu is at the bottom of pie
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupk->top,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);


				float diskleft=intecol-groupk->left;
				float diskright=groupk->right-intecol;

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{	
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	

					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{	
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}





				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
			}

		}
		else if(i_wid/i_hei>threspro)//4 6 /-    -/     k is pie
		{

			if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupk->left,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow))//4  heng is at right
			{

				GetCrossPoint(	groupk->left,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

				float disitop=interow-groupk->top;
				float disibot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}






				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
			}
			else//6  -/  k is pie
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->right,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

				float disitop=interow-groupk->top;
				float disibot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}






				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

			}
		}
		else //8 9 10 11   y  lambda   another case  close //
		{
			float ki=(groupi->strokes[0].pterow-groupi->strokes[0].ptsrow)*1.0/(0.1+groupi->strokes[0].ptecol-groupi->strokes[0].ptscol);
			float bi=groupi->strokes[0].ptsrow-groupi->strokes[0].ptscol*ki;

			float kk=(groupk->strokes[0].pterow-groupk->strokes[0].ptsrow)*1.0/(0.1+groupk->strokes[0].ptecol-groupk->strokes[0].ptscol);
			float bk=groupk->strokes[0].ptsrow-groupk->strokes[0].ptscol*kk;

			bool isintesect_like_yup=false;// y ��
			if(groupi->strokes[0].ptscol<groupi->strokes[0].ptecol)
			{
				isintesect_like_yup=intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->right,ki*(groupk->right)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}
			else
			{
				isintesect_like_yup=intersect3(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->right,ki*(groupk->right)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}

			bool isintesect_like_ybot=false;// y ��
			if(groupi->strokes[0].ptscol>groupi->strokes[0].ptecol)
			{

				isintesect_like_ybot=intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->left,ki*(groupk->left)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}
			else
			{
				isintesect_like_ybot=intersect3(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->left,ki*(groupk->left)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}


			bool isintesect_like_Y=false;//\/
			// \             //
			if(groupk->strokes[0].ptscol>groupk->strokes[0].ptecol)
			{

				isintesect_like_Y=intersect3(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupi->left,kk*(groupi->left)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			else
			{
				isintesect_like_Y=intersect3(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
					groupi->left,kk*(groupi->left)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			bool isintesect_like_lambda=false; //\
			// /\             //
			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				isintesect_like_lambda=intersect3(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupi->right,kk*(groupi->right)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			else
			{
				isintesect_like_lambda=intersect3(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
					groupi->right,kk*(groupi->right)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}



			if(isintesect_like_yup)//8
			{
				if(groupi->strokes[0].ptscol<groupi->strokes[0].ptecol)
				{
					GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupk->right,ki*(groupk->right)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
						groupk->right,ki*(groupk->right)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}

				float distop=interow-groupk->top;
				float disbot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self [groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self [groupi->ptind_left_num]=0;		
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else if(isintesect_like_ybot)//9
			{
				if(groupi->strokes[0].ptscol>groupi->strokes[0].ptecol)
				{
					GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupk->left,ki*(groupk->left)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
						groupk->left,ki*(groupk->left)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}
				float distop=interow-groupk->top;
				float disbot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}



				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self  [groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self  [groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else if(isintesect_like_Y)//10  k is pie
			{
				if(groupk->strokes[0].ptscol>groupk->strokes[0].ptecol)
				{

					GetCrossPoint(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupi->left,kk*(groupi->left)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
						groupi->left,kk*(groupi->left)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				float distop=interow-groupi->top;
				float disbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;			
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else if(isintesect_like_lambda)//11
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{

					GetCrossPoint(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupi->right,kk*(groupi->right)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
						groupi->right,kk*(groupi->right)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				float distop=interow-groupi->top;
				float disbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else //  pie pie //  //
			{

			}
		}
	}
	else //k is na
	{
		int intecol,interow;
		bool isinte=intersect3(
			groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
			groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
			groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
			groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
		if(isinte)//1 5 7   \-  \|  \/
		{
			GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

			if(i_wid/i_hei>threspro)//1 heng inte na
			{
				float disileft=intecol-groupk->left;
				float disiright=groupk->right-intecol;

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				float disktop=interow-groupi->top;
				float diskbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
					groupi->ptind_top_worh[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_stroke_inte_minpro;
					groupi->ptind_top_worh[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}


				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


			}else if(i_hei/i_wid>threspro)//5 shu inte na
			{

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_wei[groupi->ptind_left_num]=glo_stroke_inte_minpro;
					groupi->ptind_left_worh[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_wei[groupi->ptind_left_num]=glo_stroke_inte_minpro;
					groupi->ptind_left_worh[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_stroke_inte_minpro;
					groupi->ptind_right_worh[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_stroke_inte_minpro;
					groupi->ptind_right_worh[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
			else//7  x   pie inte na
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1+glo_stroke_inte_minpro;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1-glo_stroke_inte_minpro;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
		}
		else if(i_hei/i_wid>threspro)//2 3 i is shu |  k is na \ does not intersect
		{
			if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupk->bot,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow))//2 shu topper
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupk->bot,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				float diskleft=intecol-groupk->left;
				float diskright=groupk->right-intecol;

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{	
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	

					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{	
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}


				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;


					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}

			}
			else//3 shu is at the bottom of pie
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupk->top,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);


				float diskleft=intecol-groupk->left;
				float diskright=groupk->right-intecol;
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{	
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	

					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{	
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}


				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
			}

		}
		else if(i_wid/i_hei>threspro)//4 6 \-    -\     k is na
		{

			if(intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupk->left,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow))//4  heng is at right
			{

				GetCrossPoint(	groupk->left,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

				float disitop=interow-groupk->top;
				float disibot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
			}
			else//6  -\  k is na
			{

				GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->right,groupi->strokes[0].pterow,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);

				float disitop=interow-groupk->top;
				float disibot=groupk->bot-interow;
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}




				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

			}
		}
		else //8 9 10 11   pie na  na na
		{
			float ki=(groupi->strokes[0].pterow-groupi->strokes[0].ptsrow)*1.0/(0.1+groupi->strokes[0].ptecol-groupi->strokes[0].ptscol);
			float bi=groupi->strokes[0].ptsrow-groupi->strokes[0].ptscol*ki;

			float kk=(groupk->strokes[0].pterow-groupk->strokes[0].ptsrow)*1.0/(0.1+groupk->strokes[0].ptecol-groupk->strokes[0].ptscol);
			float bk=groupk->strokes[0].ptsrow-groupk->strokes[0].ptscol*kk;

			bool isintesect_like_yup=false;//\/
			// \   //
			if(groupi->strokes[0].ptscol>groupi->strokes[0].ptecol)
			{
				isintesect_like_yup=intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->left,ki*(groupk->left)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}
			else
			{
				isintesect_like_yup=intersect3(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->left,ki*(groupk->left)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}

			bool isintesect_like_ybot=false;// lambda

			if(groupi->strokes[0].ptscol<groupi->strokes[0].ptecol)
			{

				isintesect_like_ybot=intersect3(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupk->right,ki*(groupk->right)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}
			else
			{
				isintesect_like_ybot=intersect3(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
					groupk->right,ki*(groupk->right)+bi,
					groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			}


			bool isintesect_like_Y=false;//y          
			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{

				isintesect_like_Y=intersect3(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupi->right,kk*(groupi->right)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			else
			{
				isintesect_like_Y=intersect3(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
					groupi->right,kk*(groupi->right)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			bool isintesect_like_lambda=false; //��
			if(groupk->strokes[0].ptscol>groupk->strokes[0].ptecol)
			{
				isintesect_like_lambda=intersect3(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
					groupi->left,kk*(groupi->left)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}
			else
			{
				isintesect_like_lambda=intersect3(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
					groupi->left,kk*(groupi->left)+bk,
					groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
					groupi->strokes[0].ptecol,groupi->strokes[0].pterow);
			}



			if(isintesect_like_yup)//\/  //
				// \  //
			{

				if(groupi->strokes[0].ptscol>groupi->strokes[0].ptecol)
				{
					GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupk->left,ki*(groupk->left)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
						groupk->left,ki*(groupk->left)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}


				float distop=interow-groupk->top;
				float disbot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self [groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self [groupi->ptind_right_num]=0;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else if(isintesect_like_ybot)// lambda
			{
				if(groupi->strokes[0].ptscol<groupi->strokes[0].ptecol)
				{

					GetCrossPoint(	groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupk->right,ki*(groupk->right)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
						groupk->right,ki*(groupk->right)+bi,
						groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupk->strokes[0].ptecol,groupk->strokes[0].pterow,intecol,interow);
				}

				float distop=interow-groupk->top;
				float disbot=groupk->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;


					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}



				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else if(isintesect_like_Y)// y    k is na
			{

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{

					GetCrossPoint(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupi->right,kk*(groupi->right)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
						groupi->right,kk*(groupi->right)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}

				float distop=interow-groupi->top;
				float disbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1+glo_dis_inte_pie_heng;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;			
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
			}
			else if(isintesect_like_lambda)//��  k is na
			{
				if(groupk->strokes[0].ptscol>groupk->strokes[0].ptecol)
				{
					GetCrossPoint(	groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
						groupi->left,kk*(groupi->left)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}
				else
				{
					GetCrossPoint(	groupk->strokes[0].ptecol,groupk->strokes[0].pterow,
						groupi->left,kk*(groupi->left)+bk,
						groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
						groupi->strokes[0].ptecol,groupi->strokes[0].pterow,intecol,interow);
				}

				float distop=interow-groupi->top;
				float disbot=groupi->bot-interow;

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=0;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{	
					groupi->ptind_top         [groupi->ptind_top_num]=1;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	

					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}

				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;		
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{	
					groupi->ptind_bot         [groupi->ptind_bot_num]=1;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
					groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	

					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}


				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=0;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=1;
					groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;		
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}

				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=0;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-1-glo_dis_inte_pie_heng;
					groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	

					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
			}
			else //  na na //  \\  //
			{

			}
		}
	}
}
void cal_rel_atright_andinte(Group *groupi,Group *groupk,int k)
{

	int k_wid=1+groupk->right-groupk->left;
	int k_hei=1+groupk->bot-groupk->top;
	int i_wid=1+groupi->right-groupi->left;
	int i_hei=1+groupi->bot-groupi->top;
	int threspro=5;
	float locdispro=0;
	float dis_ki=abs(groupi->left - groupk->right);

	double shift_dis_wei=1+dis_ki/glo_max_dis_fordiswei;
	if(i_hei/k_hei>threspro)//1 2  3   ~| -| _| 
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
			//glo_lrtb_part_canintepro
			groupi->ptind_left_wei   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
			groupi->ptind_left_wei   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
			groupi->ptind_right_wei_self   [groupi->ptind_right_num]=glo_selfpro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;		
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
			groupi->ptind_right_wei_self   [groupi->ptind_right_num]=glo_selfpro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}

		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/i_hei;
			if(locdispro<0&& abs(groupi->right-groupk->right)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/i_hei;
			if(locdispro<0&& abs(groupi->right-groupk->right)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
			if(locdispro>0&& abs(groupi->right-groupk->right)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
			if(locdispro>0&& abs(groupi->right-groupk->right)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
	}
	else if(k_hei/i_hei>threspro)//5 6 7  |~ |- |_
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;			
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
			groupi->ptind_right_wei_self   [groupi->ptind_right_num]=glo_selfpro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
			groupi->ptind_right_wei_self   [groupi->ptind_right_num]=glo_selfpro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}


		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

			locdispro=(groupi->top-groupk->top)*1.0/k_hei;
			if(locdispro<0&& abs(groupi->left-groupk->left)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;

			groupi->ptind_top_wei[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_top_worh[groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/k_hei;
			if(locdispro<0&& abs(groupi->left-groupk->left)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_top_worh[groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;

			locdispro=(groupi->bot-groupk->bot)*1.0/k_hei;
			if(locdispro>0&& abs(groupi->left-groupk->left)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/k_hei;
			if(locdispro>0&& abs(groupi->left-groupk->left)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}



	}
	else if(i_wid/i_hei>threspro && k_wid/k_hei>threspro)//8  - -
	{
		/*for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
		groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;		
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
		<groupk->strokes[groupk->right_ssidx].ptecol)
		{
		groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
		groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
		groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
		groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}


		if(groupk->strokes[groupk->bot_ssidx].ptsrow
		<groupk->strokes[groupk->bot_ssidx].pterow)
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
		groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
		groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=1;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
		groupi->ptind_bot_wei[groupi->ptind_bot_num]=1;
		groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}

		if(groupk->strokes[groupk->top_ssidx].ptsrow
		<groupk->strokes[groupk->top_ssidx].pterow)
		{
		groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
		groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
		groupi->ptind_top_worh   [groupi->ptind_top_num]=0;
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
		groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-1;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
		groupi->ptind_top_wei[groupi->ptind_top_num]=-1;
		groupi->ptind_top_worh   [groupi->ptind_top_num]=0;
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}*/
	}
	else//4  ||   / /    \ \           /|     \|    / \  
	{
		if(groupk->strokenum==1 && groupi->strokenum==1)
		{
			bool is_two_strokes_parall=false;
			float ang=ang_2line(groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			if(ang<20*3.1415/180)
			{
				is_two_strokes_parall=true;
			} 
			int stkidx=0;
			if(is_two_strokes_parall)//  || \\ //
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei[groupi->ptind_left_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_left_worh   [groupi->ptind_left_num]=1;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro+glo_paral_stroke_maxdis_wei;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_wei[groupi->ptind_left_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_left_worh   [groupi->ptind_left_num]=1;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro+glo_paral_stroke_maxdis_wei;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else//        /|     \|    / \  
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					if(groupk->right-groupk->left>groupi->right-groupi->left)
					{
						groupi->ptind_left_wei  [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
					}
					else
					{
						groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;

					}
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
					if(groupk->right-groupk->left>groupi->right-groupi->left)
					{
						groupi->ptind_left_wei  [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
					}
					else
					{
						groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;

					}
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_num=groupi->ptind_top_num+1;

				groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;

				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
			else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;		
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;
				groupi->ptind_top_num=groupi->ptind_top_num+1;

				groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;

				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
		else//two groups
		{	

			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->right_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			if(groupk->right-groupk->left<groupi->right-groupi->left)
			{
				groupi->ptind_left_wei  [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			}
			else
			{
				groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;

			}

			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_grpdis_selfwei;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->right_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;	
			if(groupk->right-groupk->left<groupi->right-groupi->left)
			{
				groupi->ptind_left_wei  [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			}
			else
			{
				groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;

			}
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;	
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_grpdis_selfwei;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;


			if(groupk->strokes[groupk->top_ssidx].ptsrow<groupk->strokes[groupk->top_ssidx].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}
			else
			{

				groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;		
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}
			if(groupk->strokes[groupk->bot_ssidx].ptsrow<groupk->strokes[groupk->bot_ssidx].pterow)
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
			else
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;		
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
	}
}
void cal_rel_atleft_andinte(Group *groupi,Group *groupk,int k)
{
	int k_wid=1+groupk->right-groupk->left;
	int k_hei=1+groupk->bot-groupk->top;
	int i_wid=1+groupi->right-groupi->left;
	int i_hei=1+groupi->bot-groupi->top;
	int threspro=5;
	float locdispro=0;


	float dis_ki=abs(groupk->left - groupi->right);
	double shift_dis_wei=1+dis_ki/glo_max_dis_fordiswei;
	if(i_hei/k_hei>threspro)//5 6 7  |~ |- |_
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
			groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
			groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_selfpro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;

			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_selfpro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	

			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}


		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/i_hei;
			if(locdispro<0&& abs(groupi->left-groupk->left)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;

			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/i_hei;
			if(locdispro<0&& abs(groupi->left-groupk->left)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_top_worh_self[groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
			if(locdispro>0&& abs(groupi->left-groupk->left)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
			if(locdispro>0&& abs(groupi->left-groupk->left)*1.0/(groupk->right-groupk->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_bot_worh_self[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}

	}
	else if(k_hei/i_hei>threspro)////1 2  3   ~| -| _| 
	{

		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
			groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
			groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_selfpro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
			groupi->ptind_left_wei_self   [groupi->ptind_left_num]=-glo_selfpro;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/k_hei;
			if(locdispro<0&& abs(groupi->right-groupk->right)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;


			groupi->ptind_top_wei[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_top_worh[groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			locdispro=(groupi->top-groupk->top)*1.0/k_hei;
			if(locdispro<0&& abs(groupi->right-groupk->right)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_top_wei[groupi->ptind_top_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_top_worh[groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/k_hei;
			if(locdispro>0&& abs(groupi->right-groupk->right)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			locdispro=(groupi->bot-groupk->bot)*1.0/k_hei;
			if(locdispro>0&& abs(groupi->right-groupk->right)*1.0/(groupi->right-groupi->left+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_bot_worh[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
	}
	else if(i_wid/i_hei>threspro && k_wid/k_hei>threspro)//8  - -
	{
		/*for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
		groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;		
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}

		if(groupk->strokes[groupk->left_ssidx].ptscol
		<groupk->strokes[groupk->left_ssidx].ptecol)
		{
		groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
		groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
		groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
		groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
		<groupk->strokes[groupk->bot_ssidx].pterow)
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
		groupi->ptind_bot_wei[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
		groupi->ptind_bot_wei[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}

		if(groupk->strokes[groupk->top_ssidx].ptsrow
		<groupk->strokes[groupk->top_ssidx].pterow)
		{
		groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
		groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh   [groupi->ptind_top_num]=0;
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
		groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
		groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh   [groupi->ptind_top_num]=0;
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}*/
	}
	else//4  ||   / /    \ \           /|     \|    / \  
	{
		if(groupk->strokenum==1 && groupi->strokenum==1)
		{
			bool is_two_strokes_parall=false;
			float ang=ang_2line(groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			if(ang<20*3.1415/180)
			{
				is_two_strokes_parall=true;
			} 
			int stkidx=0;
			if(is_two_strokes_parall)//  || \\ //
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro-glo_paral_stroke_maxdis_wei;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;
					groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_right_worh   [groupi->ptind_right_num]=1;	
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
				else
				{
					groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro-glo_paral_stroke_maxdis_wei;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;

					groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
					groupi->ptind_right_wei_self[groupi->ptind_right_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;
					groupi->ptind_right_wei[groupi->ptind_right_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_right_worh   [groupi->ptind_right_num]=1;
					groupi->ptind_right_num=groupi->ptind_right_num+1;
				}
			}
			else//        /|     \|    / \  
			{
				if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
				{
					groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
					if(groupi->right-groupi->left > groupk->right-groupk->left)
					{
						groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
					}
					else
					{
						groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_right_worh  [groupi->ptind_right_num]=0;
					}
					groupi->ptind_right_num=groupi->ptind_right_num+1;

					groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
				else
				{
					groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
					groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
					if(groupi->right-groupi->left > groupk->right-groupk->left)
					{
						groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
					}
					else
					{
						groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_right_worh  [groupi->ptind_right_num]=0;
					}
					groupi->ptind_right_num=groupi->ptind_right_num+1;

					groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
					groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
					groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;	
					groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;	
					groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
					groupi->ptind_left_num=groupi->ptind_left_num+1;
				}
			}
			if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	

				groupi->ptind_top_num=groupi->ptind_top_num+1;

				groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;	
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
			else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;


				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;

				groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;	
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
		else
		{	

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	

			if(groupi->right-groupi->left < groupk->right-groupk->left)
			{
				groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			}
			else
			{
				groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_right_worh [groupi->ptind_right_num]=0;
			}

			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;	
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_grpdis_selfwei;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;	
			if(groupi->right-groupi->left < groupk->right-groupk->left)
			{
				groupi->ptind_right_wei_self  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
			}
			else
			{
				groupi->ptind_right_wei  [groupi->ptind_right_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_right_worh  [groupi->ptind_right_num]=0;
			}
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;	
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_grpdis_selfwei;	
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			if(groupk->strokes[groupk->top_ssidx].ptsrow<groupk->strokes[groupk->top_ssidx].pterow)
			{
				groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}
			else
			{
				groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
				groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
				locdispro=(groupi->top-groupk->top)*1.0/i_hei;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_top_wei_self[groupi->ptind_top_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
				groupi->ptind_top_num=groupi->ptind_top_num+1;
			}
			if(groupk->strokes[groupk->bot_ssidx].ptsrow<groupk->strokes[groupk->bot_ssidx].pterow)
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;

				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
			else
			{
				groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
				groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
				locdispro=(groupi->bot-groupk->bot)*1.0/i_hei;
				if(locdispro>0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
				groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			}
		}
	}
}
void cal_rel_atbot_andinte(Group *groupi,Group *groupk,int k)
{

	int k_wid=1+groupk->right-groupk->left;
	int k_hei=1+groupk->bot-groupk->top;
	int i_wid=1+groupi->right-groupi->left;
	int i_hei=1+groupi->bot-groupi->top;
	int threspro=5;

	float locdispro=0;



	float dis_ki=groupi->top - groupk->bot;
	double shift_dis_wei=1+dis_ki/glo_max_dis_fordiswei;
	if(i_wid/k_wid>threspro)//1 2  3   like   _| -| ~|  rot pi/2
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

			groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;

			groupi->ptind_top_num=groupi->ptind_top_num+1;
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	

			groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;

			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
			groupi->ptind_bot_wei_self   [groupi->ptind_bot_num]=glo_selfpro;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;		
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
			groupi->ptind_bot_wei_self   [groupi->ptind_bot_num]=glo_selfpro;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/i_wid;

			if(locdispro<0&& abs(groupi->bot-groupk->bot)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;

			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/i_wid;
			if(locdispro<0&& abs(groupi->bot-groupk->bot)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/i_wid;
			if(locdispro>0&& abs(groupi->bot-groupk->bot)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/i_wid;
			if(locdispro>0&& abs(groupi->bot-groupk->bot)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
	}
	else if(k_wid/i_wid>threspro)//5 6 7 |_  |-  |~  rot pi/2
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;

			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;


			groupi->ptind_top_num=groupi->ptind_top_num+1;
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	

			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;


			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		if(groupk->strokes[groupk->bot_ssidx].ptsrow
			<groupk->strokes[groupk->bot_ssidx].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
			groupi->ptind_bot_wei_self   [groupi->ptind_bot_num]=glo_selfpro;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;		
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
			groupi->ptind_bot_wei_self   [groupi->ptind_bot_num]=glo_selfpro;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}

		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/k_wid;
			if(locdispro<0&& abs(groupi->top-groupk->top)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_left_worh[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/k_wid;
			if(locdispro<0&& abs(groupi->top-groupk->top)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_left_worh[groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/k_wid;
			if(locdispro>0&& abs(groupi->top-groupk->top)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh[groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/k_wid;
			if(locdispro>0&& abs(groupi->top-groupk->top)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
	}
	else if(i_hei/i_wid>threspro && k_hei/k_wid>threspro)//8  - - rot pi/2
	{
		/*for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
		groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;		
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->bot_ssidx].ptsrow
		<groupk->strokes[groupk->bot_ssidx].pterow)
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
		groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;
		groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;
		groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}



		if(groupk->strokes[groupk->right_ssidx].ptscol
		<groupk->strokes[groupk->right_ssidx].ptecol)
		{
		groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
		groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;	
		groupi->ptind_right_wei[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh   [groupi->ptind_right_num]=1;
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
		groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
		groupi->ptind_right_dis[groupi->ptind_right_num]=dis_ki;
		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;	
		groupi->ptind_right_wei[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh   [groupi->ptind_right_num]=1;
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}

		if(groupk->strokes[groupk->left_ssidx].ptscol
		<groupk->strokes[groupk->left_ssidx].ptecol)
		{
		groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
		groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
		groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh   [groupi->ptind_left_num]=1;
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
		groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
		groupi->ptind_left_dis[groupi->ptind_left_num]=-dis_ki;
		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
		groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh   [groupi->ptind_left_num]=1;
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}*/
	}
	else//4  ||   / /    \ \           /|     \|    / \  
	{
		if(groupk->strokenum==1 && groupi->strokenum==1)
		{
			bool is_two_strokes_parall=false;
			float ang=ang_2line(groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			if(ang<20*3.1415/180)
			{
				is_two_strokes_parall=true;
			} 
			int stkidx=0;
			if(is_two_strokes_parall)//  || \\ //
			{
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_top_worh   [groupi->ptind_top_num]=0;	
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro+glo_paral_stroke_maxdis_wei;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_wei[groupi->ptind_top_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_top_worh   [groupi->ptind_top_num]=0;	
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=glo_paral_stroke_dis_wei;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=0;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro+glo_paral_stroke_maxdis_wei;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
			else//        /|     \|    / \  
			{
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					if(groupk->bot-groupk->top>groupi->bot-groupi->top)
					{
						groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
					}
					else
					{
						groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;

					}
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					if(groupk->bot-groupk->top>groupi->bot-groupi->top)
					{
						groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
					}
					else
					{
						groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
						groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;

					}
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_selfpro;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;


				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;

				groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
			else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;


				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;

				groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	

				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}
		else//two groups
		{	

			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;	

			if(groupk->bot-groupk->top<groupi->bot-groupi->top)
			{
				groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			}
			else
			{
				groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;

			}

			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_grpdis_selfwei;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->bot_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			if(groupk->bot-groupk->top<groupi->bot-groupi->top)
			{
				groupi->ptind_top_wei  [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			}
			else
			{
				groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_lrtb_part_canintepro;	
				groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;

			}
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_dis[groupi->ptind_bot_num]=dis_ki;	
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_grpdis_selfwei;	
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;


			if(groupk->strokes[groupk->left_ssidx].ptscol<groupk->strokes[groupk->left_ssidx].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	

				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}
			else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}
			if(groupk->strokes[groupk->right_ssidx].ptscol<groupk->strokes[groupk->right_ssidx].ptecol)
			{
				groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;		
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;

				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
			else
			{
				groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;		
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}
	}
}
void cal_rel_attop_andinte(Group *groupi,Group *groupk,int k)
{
	int k_wid=1+groupk->right-groupk->left;
	int k_hei=1+groupk->bot-groupk->top;
	int i_wid=1+groupi->right-groupi->left;
	int i_hei=1+groupi->bot-groupi->top;
	int threspro=5;
	float locdispro=0;


	float dis_ki=abs(groupk->top - groupi->bot);
	double shift_dis_wei=1+dis_ki/glo_max_dis_fordiswei;
	if(i_wid/k_wid>threspro)//5 6 7  |~ |- |_
	{
		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;		
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
			groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_selfpro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_selfpro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/i_wid;

			if(locdispro<0&& abs(groupi->top-groupk->top)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;


			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/i_wid;
			if(locdispro<0&& abs(groupi->top-groupk->top)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_left_worh_self[groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/i_wid;
			if(locdispro>0&& abs(groupi->top-groupk->top)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/i_wid;
			if(locdispro>0&& abs(groupi->top-groupk->top)*1.0/(groupk->bot-groupk->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh_self[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}


	}
	else if(k_wid/i_wid>threspro)////1 2  3   ~| -| _| 
	{

		for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
			groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_bot_worh_self  [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
			groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
			groupi->ptind_bot_worh_self  [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		if(groupk->strokes[groupk->top_ssidx].ptsrow
			<groupk->strokes[groupk->top_ssidx].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_selfpro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
			groupi->ptind_top_wei_self   [groupi->ptind_top_num]=-glo_selfpro;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;		
			groupi->ptind_top_num=groupi->ptind_top_num+1;
		}

		if(groupk->strokes[groupk->left_ssidx].ptscol
			<groupk->strokes[groupk->left_ssidx].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/k_wid;
			if(locdispro<0&& abs(groupi->bot-groupk->bot)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_left_worh[groupi->ptind_left_num]=0;	
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			locdispro=(groupi->left-groupk->left)*1.0/k_wid;
			if(locdispro<0&& abs(groupi->bot-groupk->bot)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_left_wei[groupi->ptind_left_num]=-shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;

			groupi->ptind_left_worh[groupi->ptind_left_num]=0;		
			groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
			<groupk->strokes[groupk->right_ssidx].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/k_wid;
			if(locdispro>0&& abs(groupi->bot-groupk->bot)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;


			groupi->ptind_right_worh[groupi->ptind_right_num]=0;	
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{

			groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			locdispro=(groupi->right-groupk->right)*1.0/k_wid;
			if(locdispro>0&& abs(groupi->bot-groupk->bot)*1.0/(groupi->bot-groupi->top+1)>0.5)
				locdispro*=glo_lr_or_tb_smlinter_shiftpro;
			groupi->ptind_right_wei[groupi->ptind_right_num]=shift_dis_wei*glo_hengshu_lrtb_wei+locdispro;
			groupi->ptind_right_worh[groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
	}
	else if(i_hei/i_wid>threspro && k_hei/k_wid>threspro)//8  - -
	{
		/*for(int stkidx=0;stkidx<groupk->strokenum;stkidx++)
		{
		groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
		groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;		
		groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}

		if(groupk->strokes[groupk->top_ssidx].ptsrow
		<groupk->strokes[groupk->top_ssidx].pterow)
		{
		groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}
		else
		{
		groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
		groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
		groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
		groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;
		groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
		groupi->ptind_top_num=groupi->ptind_top_num+1;
		}




		if(groupk->strokes[groupk->left_ssidx].ptscol
		<groupk->strokes[groupk->left_ssidx].ptecol)
		{
		groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
		groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh   [groupi->ptind_left_num]=1;
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}
		else
		{
		groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
		groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

		groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh_self   [groupi->ptind_left_num]=1;	
		groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_selfpro;
		groupi->ptind_left_worh   [groupi->ptind_left_num]=1;
		groupi->ptind_left_num=groupi->ptind_left_num+1;
		}

		if(groupk->strokes[groupk->right_ssidx].ptscol
		<groupk->strokes[groupk->right_ssidx].ptecol)
		{
		groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;	
		groupi->ptind_right_wei[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh   [groupi->ptind_right_num]=1;
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
		groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
		groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;

		groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh_self   [groupi->ptind_right_num]=1;	
		groupi->ptind_right_wei[groupi->ptind_right_num]=glo_selfpro;
		groupi->ptind_right_worh   [groupi->ptind_right_num]=1;
		groupi->ptind_right_num=groupi->ptind_right_num+1;
		}*/
	}
	else//4  ||   / /    \ \           /|     \|    / \  
	{
		if(groupk->strokenum==1 && groupi->strokenum==1)
		{
			bool is_two_strokes_parall=false;
			float ang=ang_2line(groupi->strokes[0].ptscol,groupi->strokes[0].ptsrow,
				groupi->strokes[0].ptecol,groupi->strokes[0].pterow,
				groupk->strokes[0].ptscol,groupk->strokes[0].ptsrow,
				groupk->strokes[0].ptecol,groupk->strokes[0].pterow);
			if(ang<20*3.1415/180)
			{
				is_two_strokes_parall=true;
			} 
			int stkidx=0;
			if(is_two_strokes_parall)//  || \\ //
			{
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro-glo_paral_stroke_maxdis_wei;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
				else
				{
					groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro-glo_paral_stroke_maxdis_wei;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;

					groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
					groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=0;	
					groupi->ptind_bot_wei[groupi->ptind_bot_num]=-glo_paral_stroke_dis_wei;	
					groupi->ptind_bot_worh   [groupi->ptind_bot_num]=0;
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;
				}
			}
			else//        /|     \|    / \  
			{
				if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
					if(groupi->bot-groupi->top > groupk->bot-groupk->top)
					{
						groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					}
					else
					{
						groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_bot_worh [groupi->ptind_bot_num]=1;
					}
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;

					groupi->ptind_top         [groupi->ptind_top_num]=2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;	
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
				else
				{
					groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*stkidx;
					groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
					if(groupi->bot-groupi->top > groupk->bot-groupk->top)
					{
						groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
					}
					else
					{
						groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
						groupi->ptind_bot_worh [groupi->ptind_bot_num]=1;
					}
					groupi->ptind_bot_num=groupi->ptind_bot_num+1;

					groupi->ptind_top         [groupi->ptind_top_num]=1+2*stkidx;
					groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
					groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;	
					groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_selfpro;	
					groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
					groupi->ptind_top_num=groupi->ptind_top_num+1;
				}
			}
			if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=2*stkidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;


				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	

				groupi->ptind_left_num=groupi->ptind_left_num+1;

				groupi->ptind_right         [groupi->ptind_right_num]=1+2*stkidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;


				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
			else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1+2*stkidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;

				groupi->ptind_right         [groupi->ptind_right_num]=2*stkidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;


				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}
		else
		{	

			groupi->ptind_bot         [groupi->ptind_bot_num]=2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	

			if(groupi->bot-groupi->top < groupk->bot-groupk->top)
			{
				groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			}
			else
			{
				groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_bot_worh [groupi->ptind_bot_num]=1;
			}

			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;	
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_grpdis_selfwei;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot         [groupi->ptind_bot_num]=1+2*groupk->bot_ssidx;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;	
			if(groupi->bot-groupi->top < groupk->bot-groupk->top)
			{
				groupi->ptind_bot_wei_self  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;
			}
			else
			{
				groupi->ptind_bot_wei  [groupi->ptind_bot_num]=glo_lrtb_part_canintepro;	
				groupi->ptind_bot_worh  [groupi->ptind_bot_num]=1;
			}
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_top         [groupi->ptind_top_num]=1+2*groupk->top_ssidx;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_dis[groupi->ptind_top_num]=-dis_ki;	
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_grpdis_selfwei;	
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_num=groupi->ptind_top_num+1;


			if(groupk->strokes[groupk->left_ssidx].ptscol<groupk->strokes[groupk->left_ssidx].ptecol)
			{
				groupi->ptind_left         [groupi->ptind_left_num]=2*groupk->left_ssidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;

				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	


				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}
			else
			{
				groupi->ptind_left         [groupi->ptind_left_num]=1+2*groupk->left_ssidx;
				groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
				locdispro=(groupi->left-groupk->left)*1.0/i_wid;
				if(locdispro<0)
					locdispro*=glo_lr_or_tb_inter_shiftpro;
				groupi->ptind_left_wei_self[groupi->ptind_left_num]=-shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;

				groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
				groupi->ptind_left_num=groupi->ptind_left_num+1;
			}
			if(groupk->strokes[groupk->right_ssidx].ptscol<groupk->strokes[groupk->right_ssidx].ptecol)
			{
				groupi->ptind_right         [groupi->ptind_right_num]=1+2*groupk->right_ssidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;


				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;

				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
			else
			{
				groupi->ptind_right         [groupi->ptind_right_num]=2*groupk->right_ssidx;
				groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;


				locdispro=(groupi->right-groupk->right)*1.0/i_wid;if(locdispro>0)locdispro*=glo_lr_or_tb_inter_shiftpro;groupi->ptind_right_wei_self[groupi->ptind_right_num]=shift_dis_wei*glo_lr_or_tb_shift_wei+locdispro;	
				groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
				groupi->ptind_right_num=groupi->ptind_right_num+1;
			}
		}
	}
}

void cal_rel_hengheng(Group *groupi,Group*groupk,int k)
{

	if(groupi->right<groupk->left)//i is at left
	{
		if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
		{
			groupi->ptind_right         [groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_left				[groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-1-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh_self	[groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=0;
			groupi->ptind_left_dis			[groupi->ptind_left_num]=-(groupk->left-groupi->right);
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			groupi->ptind_top				[groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh_self	[groupi->ptind_top_num]=0;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=0;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self		[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=0;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh			[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
			groupi->ptind_right         [groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx  [groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh_self   [groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh   [groupi->ptind_right_num]=0;
			groupi->ptind_right_num=groupi->ptind_right_num+1;

			groupi->ptind_left				[groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-1-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh_self	[groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=0;
			groupi->ptind_left_dis			[groupi->ptind_left_num]=-(groupk->left-groupi->right);
			groupi->ptind_left_num=groupi->ptind_left_num+1;


			groupi->ptind_top				[groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh_self	[groupi->ptind_top_num]=0;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=0;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self		[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=0;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh			[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}


	}
	else//i is at the right
	{

		if(groupk->strokes[0].ptscol<groupk->strokes[0].ptecol)
		{
			groupi->ptind_left         [groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self	[groupi->ptind_right_num]=1+glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh		[groupi->ptind_right_num]=0;
			groupi->ptind_right_dis			[groupi->ptind_right_num]=abs(groupk->right-groupi->left);
			groupi->ptind_right_num=groupi->ptind_right_num+1;


			groupi->ptind_top				[groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh_self	    [groupi->ptind_top_num]=0;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=0;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self		[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=0;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh			[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
		}
		else
		{
			groupi->ptind_left         [groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx  [groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh_self   [groupi->ptind_left_num]=0;	
			groupi->ptind_left_wei[groupi->ptind_left_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_left_worh   [groupi->ptind_left_num]=0;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self	[groupi->ptind_right_num]=1+glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=0;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_right_worh		[groupi->ptind_right_num]=0;
			groupi->ptind_right_dis			[groupi->ptind_right_num]=abs(groupk->right-groupi->left);
			groupi->ptind_right_num=groupi->ptind_right_num+1;


			groupi->ptind_top				[groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh_self	    [groupi->ptind_top_num]=0;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=0;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self		[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=0;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_bot_worh			[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

		}
	}	
}


void cal_rel_shushu(Group *groupi,Group*groupk,int k)
{

	if(groupi->bot<groupk->top)//i is at top
	{
		if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
		{
			groupi->ptind_bot         [groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx  [groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh_self   [groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh   [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_top				[groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-1-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh_self	[groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=1;
			groupi->ptind_top_dis			[groupi->ptind_top_num]=-(groupk->top-groupi->bot);
			groupi->ptind_top_num=groupi->ptind_top_num+1;


			groupi->ptind_left				[groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh_self	[groupi->ptind_left_num]=1;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=1;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self		[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=1;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh			[groupi->ptind_right_num]=1;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
			groupi->ptind_bot				[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self		[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh_self		[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh          [groupi->ptind_bot_num]=1;
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;

			groupi->ptind_top				[groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx		[groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self		[groupi->ptind_top_num]=-1-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh_self		[groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei			[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh			[groupi->ptind_top_num]=1;
			groupi->ptind_top_dis			[groupi->ptind_top_num]=-(groupk->top-groupi->bot);
			groupi->ptind_top_num=groupi->ptind_top_num+1;


			groupi->ptind_left				[groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh_self	[groupi->ptind_left_num]=1;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=1;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self		[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=1;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh			[groupi->ptind_right_num]=1;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}


	}
	else//i is at the bot
	{

		if(groupk->strokes[0].ptsrow<groupk->strokes[0].pterow)
		{
			groupi->ptind_top         [groupi->ptind_top_num]=1;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self	[groupi->ptind_bot_num]=1+glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh		[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_dis			[groupi->ptind_bot_num]=abs(groupk->bot-groupi->top);
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;
			//glo_hengheng_shushu_inte_pro glo_hengheng_shushu_tb_pro

			groupi->ptind_left				[groupi->ptind_left_num]=1;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh_self	    [groupi->ptind_left_num]=1;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=1;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=1;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self		[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=1;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh			[groupi->ptind_right_num]=1;
			groupi->ptind_right_num=groupi->ptind_right_num+1;
		}
		else
		{
			groupi->ptind_top         [groupi->ptind_top_num]=0;
			groupi->ptind_top_grpidx  [groupi->ptind_top_num]=k;
			groupi->ptind_top_wei_self[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh_self   [groupi->ptind_top_num]=1;	
			groupi->ptind_top_wei[groupi->ptind_top_num]=-glo_hengheng_shushu_inte_pro;
			groupi->ptind_top_worh   [groupi->ptind_top_num]=1;
			groupi->ptind_top_num=groupi->ptind_top_num+1;

			groupi->ptind_bot				[groupi->ptind_bot_num]=0;
			groupi->ptind_bot_grpidx		[groupi->ptind_bot_num]=k;
			groupi->ptind_bot_wei_self	[groupi->ptind_bot_num]=1+glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh_self	[groupi->ptind_bot_num]=1;	
			groupi->ptind_bot_wei			[groupi->ptind_bot_num]=glo_hengheng_shushu_inte_pro;
			groupi->ptind_bot_worh		[groupi->ptind_bot_num]=1;
			groupi->ptind_bot_dis			[groupi->ptind_bot_num]=abs(groupk->bot-groupi->top);
			groupi->ptind_bot_num=groupi->ptind_bot_num+1;


			groupi->ptind_left				[groupi->ptind_left_num]=0;
			groupi->ptind_left_grpidx		[groupi->ptind_left_num]=k;
			groupi->ptind_left_wei_self		[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh_self	    [groupi->ptind_left_num]=1;	
			groupi->ptind_left_wei			[groupi->ptind_left_num]=-glo_hengheng_shushu_tb_pro;
			groupi->ptind_left_worh			[groupi->ptind_left_num]=1;
			groupi->ptind_left_num=groupi->ptind_left_num+1;

			groupi->ptind_right				[groupi->ptind_right_num]=0;
			groupi->ptind_right_grpidx		[groupi->ptind_right_num]=k;
			groupi->ptind_right_wei_self		[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh_self	[groupi->ptind_right_num]=1;	
			groupi->ptind_right_wei			[groupi->ptind_right_num]=glo_hengheng_shushu_tb_pro;
			groupi->ptind_right_worh			[groupi->ptind_right_num]=1;
			groupi->ptind_right_num=groupi->ptind_right_num+1;

		}
	}	
}
void group_relationship_big(Group*&allgroup_big,int groupnum1)
{
	for(int i=1;i<groupnum1;i++)
	{		
		for(int k=0;k<i;k++)
		{
			bool is_two_strokes=false;
			bool is_two_con=false;
			if(allgroup_big[i].strokenum==1 && allgroup_big[k].strokenum==1)
			{
				is_two_strokes=true;
			}
			bool is_two_strokes_parall=false;
			if(is_two_strokes)
			{
				float ang=ang_2line(allgroup_big[i].strokes[0].ptscol,allgroup_big[i].strokes[0].ptsrow,
					allgroup_big[i].strokes[0].ptecol,allgroup_big[i].strokes[0].pterow,
					allgroup_big[k].strokes[0].ptscol,allgroup_big[k].strokes[0].ptsrow,
					allgroup_big[k].strokes[0].ptecol,allgroup_big[k].strokes[0].pterow);
				if(ang<30*3.1415/180)
				{
					is_two_strokes_parall=true;
				}
				if(k==i-1 && abs(allgroup_big[i].strokes[0].ptscol-allgroup_big[k].strokes[0].ptecol)<10
					&& abs(allgroup_big[i].strokes[0].ptsrow-allgroup_big[k].strokes[0].pterow)<10
					)
				{
					is_two_con=true;
				}
			}

			if(is_two_con)
			{

				continue;
			}

			if(is_two_strokes)
			{
				if(   ( abs(allgroup_big[i].strokes[0].ptscol-allgroup_big[k].strokes[0].ptscol)<10
					&& abs(allgroup_big[i].strokes[0].ptsrow-allgroup_big[k].strokes[0].ptsrow)<10)
					||(abs(allgroup_big[i].strokes[0].ptecol-allgroup_big[k].strokes[0].ptscol)<10
					&& abs(allgroup_big[i].strokes[0].pterow-allgroup_big[k].strokes[0].ptsrow)<10)
					)
				{
					if(   allgroup_big[k].strokes[0].ptsrow+20<allgroup_big[i].strokes[0].ptsrow
						||allgroup_big[k].strokes[0].ptsrow+20<allgroup_big[i].strokes[0].pterow)
					{
						allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=0;
						allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
						allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
						allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh[allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;


						allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=0;
						allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
						allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh_self[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;
					}
					else 
					{
						allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=0;
						allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
						allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
						allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh[allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;


						allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=0;
						allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
						allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh_self[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;
					}

					if(   allgroup_big[k].strokes[0].ptscol+20<allgroup_big[i].strokes[0].ptscol
						||allgroup_big[k].strokes[0].ptscol+20<allgroup_big[i].strokes[0].ptecol)
					{
						allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
						allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_2strokes_con;
						allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
						allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh[allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;


						allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=0;
						allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
						allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh_self[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;
					}
					else
					{
						allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
						allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
						allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh[allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;


						allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=0;
						allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
						allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh_self[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;
					}

					continue;
				}


				if(   ( abs(allgroup_big[i].strokes[0].ptscol-allgroup_big[k].strokes[0].ptecol)<10
					&& abs(allgroup_big[i].strokes[0].ptsrow-allgroup_big[k].strokes[0].pterow)<10)
					||(abs(allgroup_big[i].strokes[0].ptecol-allgroup_big[k].strokes[0].ptecol)<10
					&& abs(allgroup_big[i].strokes[0].pterow-allgroup_big[k].strokes[0].pterow)<10)
					)
				{
					if(   allgroup_big[k].strokes[0].pterow+20<allgroup_big[i].strokes[0].ptsrow
						||allgroup_big[k].strokes[0].pterow+20<allgroup_big[i].strokes[0].pterow)
					{
						allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
						allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
						allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh[allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;


						allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1;
						allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
						allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh_self[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;
					}
					else 
					{
						allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
						allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
						allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_2strokes_con;
						allgroup_big[i].ptind_bot_worh[allgroup_big[i].ptind_bot_num]=1;
						allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;


						allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1;
						allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
						allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh_self[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_top_worh[allgroup_big[i].ptind_top_num]=1;	
						allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;
					}

					if(   allgroup_big[k].strokes[0].ptecol+20<allgroup_big[i].strokes[0].ptscol
						||allgroup_big[k].strokes[0].ptecol+20<allgroup_big[i].strokes[0].ptecol)
					{
						allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1;
						allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
						allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_2strokes_con;
						allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
						allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh[allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;


						allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1;
						allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
						allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh_self[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;
					}
					else
					{
						allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1;
						allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
						allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
						allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_2strokes_con;
						allgroup_big[i].ptind_right_worh[allgroup_big[i].ptind_right_num]=0;
						allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;


						allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1;
						allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
						allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh_self[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_2strokes_con;
						allgroup_big[i].ptind_left_worh[allgroup_big[i].ptind_left_num]=0;	
						allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;
					}

					continue;
				}



			}
			int loc_maxright=allgroup_big[i].right>allgroup_big[k].right?allgroup_big[i].right:allgroup_big[k].right;
			int loc_minleft=allgroup_big[i].left<allgroup_big[k].left?allgroup_big[i].left:allgroup_big[k].left;

			int loc_maxbot=allgroup_big[i].bot>allgroup_big[k].bot?allgroup_big[i].bot:allgroup_big[k].bot;
			int loc_mintop=allgroup_big[i].top<allgroup_big[k].top?allgroup_big[i].top:allgroup_big[k].top;

			if(loc_mintop+5>loc_maxbot && loc_maxright-loc_minleft<allgroup_big[i].right-allgroup_big[i].left+allgroup_big[k].right-allgroup_big[k].left)
			{
				continue;
			}
			else if(loc_minleft+5>loc_maxright && loc_maxbot-loc_mintop<allgroup_big[i].bot-allgroup_big[i].top+allgroup_big[k].bot-allgroup_big[k].top)
			{
				continue;
			}
			int loc_k_wid=allgroup_big[k].right-allgroup_big[k].left+1;
			int loc_k_hei=allgroup_big[k].bot-allgroup_big[k].top+1;
			int loc_j_wid=allgroup_big[i].right-allgroup_big[i].left+1;
			int loc_j_hei=allgroup_big[i].bot-allgroup_big[i].top+1;
			int max_k_wid=loc_k_wid>loc_k_hei?loc_k_wid:loc_k_hei;
			int max_j_wid=loc_j_wid>loc_j_hei?loc_j_wid:loc_j_hei;

			if(is_two_strokes&&i==groupnum1-1 &&k==0 && loc_k_wid/loc_k_hei>10 && loc_j_wid/loc_j_hei>10 
				&& abs(allgroup_big[i].top-allgroup_big[k].top)<10
				&&(allgroup_big[i].left>allgroup_big[k].right||allgroup_big[k].left>allgroup_big[i].right))
				// - -
			{
				cal_rel_hengheng(&(allgroup_big[i]),&(allgroup_big[k]), k);
				continue;
			}

			if(is_two_strokes&&i==groupnum1-1 &&k==0 && loc_k_hei/loc_k_wid>10 && loc_j_hei/loc_j_wid>10 
				&& abs(allgroup_big[i].left-allgroup_big[k].left)<10
				&&(allgroup_big[i].top>allgroup_big[k].bot||allgroup_big[k].top>allgroup_big[i].bot))// shushu
			{
				cal_rel_shushu(&(allgroup_big[i]),&(allgroup_big[k]), k);
				continue;
			}

			bool 	isinte=false;
			float dis_lr=((loc_maxright-loc_minleft)-loc_j_wid-loc_k_wid);
			float dis_tb=((loc_maxbot-loc_mintop)-loc_j_hei-loc_k_hei);
			if(dis_lr<=0 && dis_tb<=0)
			{
				if( (fabs(dis_lr)<3&& (abs(allgroup_big[i].left-allgroup_big[k].left)<3||abs(allgroup_big[i].right-allgroup_big[k].right)<3))
					||
					(fabs(dis_tb)<3&& (abs(allgroup_big[i].top-allgroup_big[k].top)<3||abs(allgroup_big[i].bot-allgroup_big[k].bot)<3)))
				{
				}
				else
				{

					isinte=true;
				}
			}
			bool isatright=false;
			bool isatleft=false;
			bool isattop=false;
			bool isatbot=false;
			if(allgroup_big[i].left>= allgroup_big[k].right)
				isatright=true;
			if(allgroup_big[i].right<= allgroup_big[k].left)
				isatleft=true;
			if(allgroup_big[i].top>=allgroup_big[k].bot)
				isatbot=true;
			if(allgroup_big[i].bot< allgroup_big[k].top)
				isattop=true;


			if(isatright && !isatbot && !isattop
				)//j is at the right of k 1
			{	

				float locdis=loc_maxright-loc_minleft-loc_k_wid-loc_j_wid;
				float interhei=loc_k_hei+loc_j_hei-(loc_maxbot-loc_mintop);
				float interpro1=interhei/loc_k_hei;
				float interpro2=interhei/loc_j_hei;
				if((interpro1<glo_as_lrtb_inter_min_pro || interpro2<glo_as_lrtb_inter_min_pro)
					&&!(loc_k_wid/loc_k_hei>3 && loc_j_hei/loc_j_wid>3||loc_j_wid/loc_j_hei>3 && loc_k_hei/loc_k_wid>3))
					continue;
				if(locdis<2||locdis>glo_as_lrtb_inter_maxdis_pro*loc_k_hei && locdis>glo_as_lrtb_inter_maxdis_pro*loc_j_hei)
					continue;
				cal_rel_atright_andinte(&(allgroup_big[i]),&(allgroup_big[k]), k);
			}
			else if(isatleft && !isatbot && !isattop)//j is at the left of k 2
			{
				float locdis=loc_maxright-loc_minleft-loc_k_wid-loc_j_wid;
				float interhei=loc_k_hei+loc_j_hei-(loc_maxbot-loc_mintop);
				float interpro1=interhei/loc_k_hei;
				float interpro2=interhei/loc_j_hei;
				if((interpro1<glo_as_lrtb_inter_min_pro ||  interpro2<glo_as_lrtb_inter_min_pro)
					&&!(loc_k_wid/loc_k_hei>3 && loc_j_hei/loc_j_wid>3||loc_j_wid/loc_j_hei>3 && loc_k_hei/loc_k_wid>3))
					continue;
				if(locdis<2||locdis>glo_as_lrtb_inter_maxdis_pro*loc_k_hei && locdis>glo_as_lrtb_inter_maxdis_pro*loc_j_hei)
					continue;
				cal_rel_atleft_andinte(&(allgroup_big[i]),&(allgroup_big[k]), k);
			}
			else if(isatbot && !isatleft && !isatright)//j is at the bot of k 3
			{
				float locdis=loc_maxbot-loc_mintop-loc_k_hei-loc_j_hei;
				float interwid=loc_k_wid+loc_j_wid-(loc_maxright-loc_minleft);
				float interpro1=interwid/loc_k_wid;
				float interpro2=interwid/loc_j_wid;
				if((interpro1<glo_as_lrtb_inter_min_pro ||  interpro2<glo_as_lrtb_inter_min_pro)
					&&!(loc_k_wid/loc_k_hei>3 && loc_j_hei/loc_j_wid>3||loc_j_wid/loc_j_hei>3 && loc_k_hei/loc_k_wid>3))
					continue;
				if(locdis<2||locdis>glo_as_lrtb_inter_maxdis_pro*loc_k_wid && locdis>glo_as_lrtb_inter_maxdis_pro*loc_j_wid)
					continue;
				cal_rel_atbot_andinte(&(allgroup_big[i]),&(allgroup_big[k]), k);
			}
			else if(isattop && !isatleft && !isatright)//j is at the top of k 4
			{
				//glo_as_lrtb_inter_min_pro glo_as_lrtb_inter_maxdis_pro
				float locdis=loc_maxbot-loc_mintop-loc_k_hei-loc_j_hei;
				float interwid=loc_k_wid+loc_j_wid-(loc_maxright-loc_minleft);
				float interpro1=interwid/loc_k_wid;
				float interpro2=interwid/loc_j_wid;
				if((interpro1<glo_as_lrtb_inter_min_pro ||  interpro2<glo_as_lrtb_inter_min_pro)
					&&!(loc_k_wid/loc_k_hei>3 && loc_j_hei/loc_j_wid>3||loc_j_wid/loc_j_hei>3 && loc_k_hei/loc_k_wid>3))
					continue;
				if(locdis<2||locdis>glo_as_lrtb_inter_maxdis_pro*loc_k_wid && locdis>glo_as_lrtb_inter_maxdis_pro*loc_j_wid)
					continue;
				cal_rel_attop_andinte(&(allgroup_big[i]),&(allgroup_big[k]), k);
			}
			else if(isinte)	
			{

				float interwid=loc_k_wid+loc_j_wid-(loc_maxright-loc_minleft);

				float interhei=loc_k_hei+loc_j_hei-(loc_maxbot-loc_mintop);
				float interpro1=interhei*interwid/(loc_k_wid*loc_k_hei);
				float interpro2=interhei*interwid/(loc_j_wid*loc_j_hei);
				if(interpro1<glo_as_lrtb_inter_min_pro*glo_as_lrtb_inter_min_pro 
					&& interpro2<glo_as_lrtb_inter_min_pro*glo_as_lrtb_inter_min_pro 
					&& !(loc_k_wid/loc_k_hei>3 && loc_j_hei/loc_j_wid>3||loc_j_wid/loc_j_hei>3 && loc_k_hei/loc_k_wid>3))
					continue;

				if(allgroup_big[i].strokenum==1 && allgroup_big[k].strokenum==1)
				{

					cal_rel_intersect_twostrokes(&(allgroup_big[i]),&(allgroup_big[k]), k);

				}
				else
				{
					for(int s=0;s<allgroup_big[k].strokenum;s++)
					{
						int curscol=allgroup_big[k].strokes[s].ptscol;
						int cursrow=allgroup_big[k].strokes[s].ptsrow;
						int curecol=allgroup_big[k].strokes[s].ptecol;
						int curerow=allgroup_big[k].strokes[s].pterow;

						int curleft=allgroup_big[i].left;
						int curtop=allgroup_big[i].top;
						int curbot=allgroup_big[i].bot;
						int curright=allgroup_big[i].right;

						int cenrow1=(cursrow+curerow)/2;
						int cencol1=(curscol+curecol)/2;
						int cenrow2=(cursrow+cenrow1)/2;
						int cencol2=(curscol+cencol1)/2;
						int cenrow3=(curerow+cenrow1)/2;
						int cencol3=(curecol+cencol1)/2;

						int curhei=curbot-curtop;
						int curwid=curright-curleft;
						//fix top
						if(curtop>cursrow)
						{
							if(curscol<curright && curscol>curleft)//just on the top
							{
								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-cursrow;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
								allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
								allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1;
								allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
								allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

								allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
								allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
								allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1;
								allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
								allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
							}
							else
							{
								//compute 3 centers

								if((curtop>cenrow1 &&(cencol1<curright && cencol1>curleft))
									||(curtop>cenrow2 &&(cencol2<curright && cencol2>curleft))
									||(curtop>cenrow3 &&(cencol3<curright && cencol3>curleft)))//still on the top
								{

									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-cursrow;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;


									


								}
								else//not right top, fix top by dis
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-cursrow;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
								}
							}
						}
						//fix top
						if(curtop>curerow)
						{
							if(curecol<curright && curecol>curleft)//just on the top
							{
								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-curerow;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1;
									allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
							}
							else
							{
								//compute 3 centers

								if((curtop>cenrow1 &&(cencol1<curright && cencol1>curleft))
									||(curtop>cenrow2 &&(cencol2<curright && cencol2>curleft))
									||(curtop>cenrow3 &&(cencol3<curright && cencol3>curleft)))//still on the top
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-curerow;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
								}
								else//not right top, fix top by dis
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_wei[allgroup_big[i].ptind_top_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_top_worh   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_dis[allgroup_big[i].ptind_bot_num]=curtop-curerow;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
								}
							}
						}

						//fix bot
						if(curbot<cursrow)
						{
							if(curscol<curright && curscol>curleft)//just on the bot
							{
								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-cursrow;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1;
									allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
								

							}
							else
							{
								//compute 3 centers

								if((curbot<cenrow1 &&(cencol1<curright && cencol1>curleft))
									||(curbot<cenrow2 &&(cencol2<curright && cencol2>curleft))
									||(curbot<cenrow3 &&(cencol3<curright && cencol3>curleft)))//still on the bot
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-cursrow;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

								}
								else//not right bot, fix bot by dis
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-cursrow;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh_self   [allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh   [allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;



								}
							}
						}

						//fix bot
						if(curbot<curerow)
						{
							if(curecol<curright && curecol>curleft)//just on the bot
							{
								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-curerow;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1;
									allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
							}
							else
							{
								//compute 3 centers

								if((curbot<cenrow1 &&(cencol1<curright && cencol1>curleft))
									||(curbot<cenrow2 &&(cencol2<curright && cencol2>curleft))
									||(curbot<cenrow3 &&(cencol3<curright && cencol3>curleft)))//still on the bot
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-curerow;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
								}
								else//not right bot, fix bot by dis
								{
									allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
									allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
									allgroup_big[i].ptind_top_dis[allgroup_big[i].ptind_top_num]=curbot-curerow;
									allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
									allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

									allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
									allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
									allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh_self   [allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_wei[allgroup_big[i].ptind_bot_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_bot_worh   [allgroup_big[i].ptind_bot_num]=1;	
									allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
								}
							}
						}




						//fix left
						if(curleft>curscol)
						{
							if(cursrow<curbot && cursrow>curtop)//just on the left
							{
								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
								allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
								allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
								allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
								allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

								allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
								allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
								allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curscol;
								allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
								allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
								allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
							}
							else
							{
								//compute 3 centers

								if((curleft>cencol1 &&(cenrow1<curbot && cenrow1>curtop))
									||(curleft>cencol2 &&(cenrow2<curbot && cenrow2>curtop))
									||(curleft>cencol3 &&(cenrow3<curbot && cenrow3>curtop)))//still on the left
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curscol;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
								}
								else//not right left, fix left by dis
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curscol;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
								}
							}
						}

						//fix left
						if(curleft>curecol)
						{
							if(curerow<curbot && curerow>curtop)//just on the left
							{
								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
								allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
								allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
								allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
								allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

								allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
								allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
								allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curecol;
								allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
								allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
								allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;
							}
							else
							{
								//compute 3 centers

								if((curleft>cencol1 &&(cenrow1<curbot && cenrow1>curtop))
									||(curleft>cencol2 &&(cenrow2<curbot && cenrow2>curtop))
									||(curleft>cencol3 &&(cenrow3<curbot && cenrow3>curtop)))//still on the left
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curecol;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
								}
								else//not right left, fix left by dis
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_wei[allgroup_big[i].ptind_left_num]=-glo_part_caninte_pt;
									allgroup_big[i].ptind_left_worh   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_dis[allgroup_big[i].ptind_right_num]=curleft-curecol;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=1+glo_part_disself_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;
								}
							}
						}



						//fix right
						if(curright<curscol)
						{
							if(cursrow<curbot && cursrow>curtop)//just on the right
							{
								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
								allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
								allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curscol;
								allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
								allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
								allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

								allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
								allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
								allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
								allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
								allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

							}
							else
							{
								//compute 3 centers


								if((curright<cencol1 &&(cenrow1<curbot && cenrow1>curtop))
									||(curright<cencol2 &&(cenrow2<curbot && cenrow2>curtop))
									||(curright<cencol3 &&(cenrow3<curbot && cenrow3>curtop)))//still on the right
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curscol;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								}
								else//not right right, fix right by dis
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curscol;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;



								}
							}
						}

						//fix right
						if(curright<curecol)
						{
							if(curerow<curbot && curerow>curtop)//just on the right
							{
								allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
								allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
								allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curecol;
								allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
								allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
								allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

								allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
								allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
								allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
								allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
								allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								allgroup_big[i].ptind_top         [allgroup_big[i].ptind_top_num]=1+2*s;
								allgroup_big[i].ptind_top_grpidx  [allgroup_big[i].ptind_top_num]=k;
								allgroup_big[i].ptind_top_wei_self[allgroup_big[i].ptind_top_num]=-1;
								allgroup_big[i].ptind_top_worh_self   [allgroup_big[i].ptind_top_num]=1;	
								allgroup_big[i].ptind_top_num=allgroup_big[i].ptind_top_num+1;

								allgroup_big[i].ptind_bot         [allgroup_big[i].ptind_bot_num]=1+2*s;
								allgroup_big[i].ptind_bot_grpidx  [allgroup_big[i].ptind_bot_num]=k;
								allgroup_big[i].ptind_bot_wei_self[allgroup_big[i].ptind_bot_num]=1;
								allgroup_big[i].ptind_bot_worh_self[allgroup_big[i].ptind_bot_num]=1;	
								allgroup_big[i].ptind_bot_num=allgroup_big[i].ptind_bot_num+1;

							}
							else
							{
								//compute 3 centers


								if((curright<cencol1 &&(cenrow1<curbot && cenrow1>curtop))
									||(curright<cencol2 &&(cenrow2<curbot && cenrow2>curtop))
									||(curright<cencol3 &&(cenrow3<curbot && cenrow3>curtop)))//still on the right
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curecol;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh_self[allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

								}
								else//not right right, fix right by dis
								{
									allgroup_big[i].ptind_left         [allgroup_big[i].ptind_left_num]=1+2*s;
									allgroup_big[i].ptind_left_grpidx  [allgroup_big[i].ptind_left_num]=k;
									allgroup_big[i].ptind_left_dis[allgroup_big[i].ptind_left_num]=curright-curecol;
									allgroup_big[i].ptind_left_wei_self[allgroup_big[i].ptind_left_num]=-1-glo_part_disself_pt;
									allgroup_big[i].ptind_left_worh_self   [allgroup_big[i].ptind_left_num]=0;	
									allgroup_big[i].ptind_left_num=allgroup_big[i].ptind_left_num+1;

									allgroup_big[i].ptind_right         [allgroup_big[i].ptind_right_num]=1+2*s;
									allgroup_big[i].ptind_right_grpidx  [allgroup_big[i].ptind_right_num]=k;
									allgroup_big[i].ptind_right_wei_self[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh_self   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_wei[allgroup_big[i].ptind_right_num]=glo_part_caninte_pt;
									allgroup_big[i].ptind_right_worh   [allgroup_big[i].ptind_right_num]=0;	
									allgroup_big[i].ptind_right_num=allgroup_big[i].ptind_right_num+1;

									//glo_part_caninte_pt
									//	glo_part_disself_pt

								}
							}
						}

					}
				}
			}

		}
	}



}



void rotatePart3(Group *curgrp,double rotval)
{
	double retval=0;
	int ssind=0;

	int cencol_d=0,cenrow_d=0,cencol2_d=0,cenrow2_d=0;

	/*for(ssind=0;ssind<curgrp->strokenum;ssind++)
	{		

	cencol_d+=curgrp->draw_strokes[ssind].ptscol;
	cencol_d+=curgrp->draw_strokes[ssind].ptecol;
	cenrow_d+=curgrp->draw_strokes[ssind].ptsrow;
	cenrow_d+=curgrp->draw_strokes[ssind].pterow;
	}*/
	cencol_d=curgrp->left+(curgrp->right-curgrp->left+1)/2.0;
	cenrow_d=curgrp->top+(curgrp->bot-curgrp->top+1)/2.0;

	/*	if(cencol_d>0||cenrow_d>0)
	{

	cencol_d/=curgrp->strokenum;
	cenrow_d/=curgrp->strokenum;
	cencol_d/=2;cenrow_d/=2;
	}*/
	int mincol=10000;
	int minrow=10000;
	if(cencol_d>0||cenrow_d>0)
	{

		int retx,rety;
		//void rotate_point(int orix,int oriy,int cx,int cy,int &retx,int &rety,float a)

		for(ssind=0;ssind<curgrp->strokenum;ssind++)
		{
			rotate_point(curgrp->draw_strokes[ssind].ptscol,curgrp->draw_strokes[ssind].ptsrow,cencol_d,cenrow_d,retx,rety,rotval);
			curgrp->draw_strokes[ssind].ptscol=retx;curgrp->draw_strokes[ssind].ptsrow=rety;
			
			rotate_point(curgrp->draw_strokes[ssind].ptecol,curgrp->draw_strokes[ssind].pterow,cencol_d,cenrow_d,retx,rety,rotval);
			curgrp->draw_strokes[ssind].ptecol=retx;curgrp->draw_strokes[ssind].pterow=rety;

			
		}
	}
	//	return retval;

	

}

void zoomPart2(Group *curgrp,float zmprolr,float zmprotb,int top,int left)
{
	int ssind=0;
	for(ssind=0;ssind<curgrp->strokenum;ssind++)
	{		

		curgrp->draw_strokes[ssind].ptscol=(curgrp->draw_strokes[ssind].ptscol-left)*zmprolr+left;
		curgrp->draw_strokes[ssind].ptecol=(curgrp->draw_strokes[ssind].ptecol-left)*zmprolr+left;
		curgrp->draw_strokes[ssind].ptsrow=(curgrp->draw_strokes[ssind].ptsrow-top)*zmprotb+top;
		curgrp->draw_strokes[ssind].pterow=(curgrp->draw_strokes[ssind].pterow-top)*zmprotb+top;
	}

}


void shiftPart2(Group *curgrp,int shiftlr,int shifttb)
{
	int ssind=0;
	for(ssind=0;ssind<curgrp->strokenum;ssind++)
	{		


		curgrp->draw_strokes[ssind].ptscol+=shiftlr;
		curgrp->draw_strokes[ssind].ptecol+=shiftlr;
		curgrp->draw_strokes[ssind].ptsrow+=shifttb;
		curgrp->draw_strokes[ssind].pterow+=shifttb;
	}

}


void zoomPart2_s(Group *curgrp,float zmprolr,float zmprotb,int top,int left)
{
	int ssind=0;
	for(ssind=0;ssind<curgrp->strokenum;ssind++)
	{		

		curgrp->draw_strokes[ssind].ptscol=(curgrp->draw_strokes[ssind].ptscol-left)*zmprolr+left;
		curgrp->draw_strokes[ssind].ptecol=(curgrp->draw_strokes[ssind].ptecol-left)*zmprolr+left;
		curgrp->draw_strokes[ssind].ptsrow=(curgrp->draw_strokes[ssind].ptsrow-top)*zmprotb+top;
		curgrp->draw_strokes[ssind].pterow=(curgrp->draw_strokes[ssind].pterow-top)*zmprotb+top;

		curgrp->strokes[ssind].ptscol=curgrp->draw_strokes[ssind].ptscol;
		curgrp->strokes[ssind].ptecol=curgrp->draw_strokes[ssind].ptecol;
		curgrp->strokes[ssind].ptsrow=curgrp->draw_strokes[ssind].ptsrow;
		curgrp->strokes[ssind].pterow=curgrp->draw_strokes[ssind].pterow;

	}

}


void shiftPart2_s(Group *curgrp,int shiftlr,int shifttb)
{
	int ssind=0;
	for(ssind=0;ssind<curgrp->strokenum;ssind++)
	{		


		curgrp->draw_strokes[ssind].ptscol+=shiftlr;
		curgrp->draw_strokes[ssind].ptecol+=shiftlr;
		curgrp->draw_strokes[ssind].ptsrow+=shifttb;
		curgrp->draw_strokes[ssind].pterow+=shifttb;

		curgrp->strokes[ssind].ptscol=curgrp->draw_strokes[ssind].ptscol;
		curgrp->strokes[ssind].ptecol=curgrp->draw_strokes[ssind].ptecol;
		curgrp->strokes[ssind].ptsrow=curgrp->draw_strokes[ssind].ptsrow;
		curgrp->strokes[ssind].pterow=curgrp->draw_strokes[ssind].pterow;

	}

}

void InitGrammer(char *path,char *hanziname,int rdziti,int &allstrokenum,int &allgroupnum,
	Group* allgroup)
{
	int strokenum;
	int i,j;
	int zitinum=0;
	char numfilename[1024]="";
	char filename[1024]="";

	sprintf(numfilename,"%s\\%s\\%s_num.txt",rootpath,glo_learnresultpath,hanziname);
	FILE *fp=fopen(numfilename,"r");
	int isusedpart;
	fscanf(fp,"%d",&zitinum);
	fclose(fp);
	//int rdziti=1+rand()%(zitinum-1);
	//	rdziti=1;
	sprintf(filename,"%s\\%s\\%s_%d.txt",rootpath,glo_learnresultpath,hanziname,rdziti);
	fp=fopen(filename,"r");
	fscanf(fp,"%d",&(strokenum));
	fscanf(fp,"%d",&(allgroupnum));
	strokenum=1;
	allstrokenum=strokenum;
	int ptscol,ptecol,ptsrow,pterow;
	for(i=0;i<allgroupnum;i++)
	{
		allgroup[i].strokenum=1;


		for(int jj=0;jj<allgroup[i].strokenum;jj++)
		{
			fscanf(fp,"%d%d%d%d",&(ptscol),&(ptsrow),&(ptecol),&(pterow));
			allgroup[i].strokes[jj].ptscol=ptscol;
			allgroup[i].strokes[jj].ptsrow=ptsrow;
			allgroup[i].strokes[jj].ptecol=ptecol;
			allgroup[i].strokes[jj].pterow=pterow;

			allgroup[i].draw_strokes[jj].ptscol=ptscol;
			allgroup[i].draw_strokes[jj].ptsrow=ptsrow;
			allgroup[i].draw_strokes[jj].ptecol=ptecol;
			allgroup[i].draw_strokes[jj].pterow=pterow;

		}

	}
	fclose(fp);


}

void cuoqie_x(Group*curgrp,float ang)
{
	float ta=tan(ang);
	int width=curgrp->right-curgrp->left+1;
	int height=curgrp->bot-curgrp->top+1;



	for(int i=0;i<curgrp->strokenum;i++)
	{
		int shiftdis=(height-1-(curgrp->draw_strokes[i].ptsrow-curgrp->top))*ta;
		curgrp->draw_strokes[i].ptscol+=shiftdis;

		shiftdis=(height-1-(curgrp->draw_strokes[i].pterow-curgrp->top))*ta;
		curgrp->draw_strokes[i].ptecol+=shiftdis;
	}
	
}
void cuoqie_y(Group*curgrp,float ang)
{
	float ta=tan(ang);
	int width=curgrp->right-curgrp->left+1;
	int height=curgrp->bot-curgrp->top+1;


	for(int i=0;i<curgrp->strokenum;i++)
	{
		int shiftdis=(width-1-(curgrp->draw_strokes[i].ptscol-curgrp->left))*ta;
		curgrp->draw_strokes[i].ptsrow+=shiftdis;

		shiftdis=(width-1-(curgrp->draw_strokes[i].ptecol-curgrp->left))*ta;
		curgrp->draw_strokes[i].pterow+=shiftdis;
	}

	
}
void ReleaseGrammer(Group *&allgroup,Group *&allgroup_cp,int allgroupnum)
{
	int i,j;
	for(int i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup[i].rdidx;
		delete []allgroup[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].con_ss;//�������ʻ�����
		delete []allgroup[i].draw_curves;

		delete []allgroup[i].ptind_left;//
		delete []allgroup[i].ptind_right;
		delete []allgroup[i].ptind_top;
		delete []allgroup[i].ptind_bot;

		delete []allgroup[i].ptind_left_grpidx;//
		delete []allgroup[i].ptind_right_grpidx;
		delete []allgroup[i].ptind_top_grpidx;
		delete []allgroup[i].ptind_bot_grpidx;

		delete []allgroup[i].ptind_left_wei_self;
		delete []allgroup[i].ptind_right_wei_self;
		delete []allgroup[i].ptind_top_wei_self;
		delete []allgroup[i].ptind_bot_wei_self;

		delete []allgroup[i].ptind_left_wei;
		delete []allgroup[i].ptind_right_wei;
		delete []allgroup[i].ptind_top_wei;
		delete []allgroup[i].ptind_bot_wei;

		delete []allgroup[i].ptind_left_worh;
		delete []allgroup[i].ptind_right_worh;
		delete []allgroup[i].ptind_top_worh;
		delete []allgroup[i].ptind_bot_worh;

		delete []allgroup[i].ptind_left_worh_self;
		delete []allgroup[i].ptind_right_worh_self;
		delete []allgroup[i].ptind_top_worh_self;
		delete []allgroup[i].ptind_bot_worh_self;

		delete []allgroup[i].ptind_left_dis;
		delete []allgroup[i].ptind_right_dis;
		delete []allgroup[i].ptind_top_dis;
		delete []allgroup[i].ptind_bot_dis;
	}

	delete []allgroup;


	for( i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup_cp[i].rdidx;
		delete []allgroup_cp[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup_cp[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup_cp[i].con_ss;//�������ʻ�����
		delete []allgroup_cp[i].draw_curves;

		delete []allgroup_cp[i].ptind_left;//
		delete []allgroup_cp[i].ptind_right;
		delete []allgroup_cp[i].ptind_top;
		delete []allgroup_cp[i].ptind_bot;

		delete []allgroup_cp[i].ptind_left_grpidx;//
		delete []allgroup_cp[i].ptind_right_grpidx;
		delete []allgroup_cp[i].ptind_top_grpidx;
		delete []allgroup_cp[i].ptind_bot_grpidx;

		delete []allgroup_cp[i].ptind_left_wei_self;
		delete []allgroup_cp[i].ptind_right_wei_self;
		delete []allgroup_cp[i].ptind_top_wei_self;
		delete []allgroup_cp[i].ptind_bot_wei_self;

		delete []allgroup_cp[i].ptind_left_wei;
		delete []allgroup_cp[i].ptind_right_wei;
		delete []allgroup_cp[i].ptind_top_wei;
		delete []allgroup_cp[i].ptind_bot_wei;


		delete []allgroup_cp[i].ptind_left_worh;
		delete []allgroup_cp[i].ptind_right_worh;
		delete []allgroup_cp[i].ptind_top_worh;
		delete []allgroup_cp[i].ptind_bot_worh;

		delete []allgroup_cp[i].ptind_left_worh_self;
		delete []allgroup_cp[i].ptind_right_worh_self;
		delete []allgroup_cp[i].ptind_top_worh_self;
		delete []allgroup_cp[i].ptind_bot_worh_self;

		delete []allgroup_cp[i].ptind_left_dis;
		delete []allgroup_cp[i].ptind_right_dis;
		delete []allgroup_cp[i].ptind_top_dis;
		delete []allgroup_cp[i].ptind_bot_dis;
	}

	delete []allgroup_cp;


}

void ReleaseGrammer(Group *&allgroup,int allgroupnum)
{
	int i,j;
	for(int i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup[i].rdidx;
		delete []allgroup[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].con_ss;//�������ʻ�����
		delete []allgroup[i].draw_curves;

		delete []allgroup[i].ptind_left;//
		delete []allgroup[i].ptind_right;
		delete []allgroup[i].ptind_top;
		delete []allgroup[i].ptind_bot;

		delete []allgroup[i].ptind_left_grpidx;//
		delete []allgroup[i].ptind_right_grpidx;
		delete []allgroup[i].ptind_top_grpidx;
		delete []allgroup[i].ptind_bot_grpidx;

		delete []allgroup[i].ptind_left_wei_self;
		delete []allgroup[i].ptind_right_wei_self;
		delete []allgroup[i].ptind_top_wei_self;
		delete []allgroup[i].ptind_bot_wei_self;

		delete []allgroup[i].ptind_left_wei;
		delete []allgroup[i].ptind_right_wei;
		delete []allgroup[i].ptind_top_wei;
		delete []allgroup[i].ptind_bot_wei;


		delete []allgroup[i].ptind_left_worh;
		delete []allgroup[i].ptind_right_worh;
		delete []allgroup[i].ptind_top_worh;
		delete []allgroup[i].ptind_bot_worh;

		delete []allgroup[i].ptind_left_worh_self;
		delete []allgroup[i].ptind_right_worh_self;
		delete []allgroup[i].ptind_top_worh_self;
		delete []allgroup[i].ptind_bot_worh_self;

		delete []allgroup[i].ptind_left_dis;
		delete []allgroup[i].ptind_right_dis;
		delete []allgroup[i].ptind_top_dis;
		delete []allgroup[i].ptind_bot_dis;
	}




	delete []allgroup;





}

void ReleaseGrammer1(Group *&onegroup)
{
	int i,j;
	//	delete []onegroup->rdidx;
	delete []onegroup->strokes;//�ýṹ�����ʻ�����ʼ��
	delete []onegroup->draw_strokes;//�ýṹ�����ʻ�����ʼ��
	delete []onegroup->con_ss;//�������ʻ�����
	delete []onegroup->draw_curves;

	delete []onegroup->ptind_left;//
	delete []onegroup->ptind_right;
	delete []onegroup->ptind_top;
	delete []onegroup->ptind_bot;

	delete []onegroup->ptind_left_grpidx;//
	delete []onegroup->ptind_right_grpidx;
	delete []onegroup->ptind_top_grpidx;
	delete []onegroup->ptind_bot_grpidx;

	delete []onegroup->ptind_left_wei_self;
	delete []onegroup->ptind_right_wei_self;
	delete []onegroup->ptind_top_wei_self;
	delete []onegroup->ptind_bot_wei_self;

	delete []onegroup->ptind_left_wei;
	delete []onegroup->ptind_right_wei;
	delete []onegroup->ptind_top_wei;
	delete []onegroup->ptind_bot_wei;


	delete []onegroup->ptind_left_worh;
	delete []onegroup->ptind_right_worh;
	delete []onegroup->ptind_top_worh;
	delete []onegroup->ptind_bot_worh;

	delete []onegroup->ptind_left_worh_self;
	delete []onegroup->ptind_right_worh_self;
	delete []onegroup->ptind_top_worh_self;
	delete []onegroup->ptind_bot_worh_self;

	delete []onegroup->ptind_left_dis;
	delete []onegroup->ptind_right_dis;
	delete []onegroup->ptind_top_dis;
	delete []onegroup->ptind_bot_dis;

	delete 	onegroup;



}
void ReleaseGrammer4(Group *&allgroup,Group *&allgroup_cp,int allgroupnum)
{
	int i,j;
	for(int i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup[i].rdidx;
		delete []allgroup[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].con_ss;//�������ʻ�����
		delete []allgroup[i].draw_curves;
	}
	delete []allgroup;
	for( i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup_cp[i].rdidx;
		delete []allgroup_cp[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup_cp[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup_cp[i].con_ss;//�������ʻ�����
		delete []allgroup_cp[i].draw_curves;
	}
	delete []allgroup_cp;
}

void ReleaseGrammer4(Group *&allgroup,int allgroupnum)
{
	int i,j;
	for(int i=0;i<allgroupnum;i++)
	{
		//	delete []allgroup[i].rdidx;
		delete []allgroup[i].strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].draw_strokes;//�ýṹ�����ʻ�����ʼ��
		delete []allgroup[i].con_ss;//�������ʻ�����
		delete []allgroup[i].draw_curves;
	}
	delete []allgroup;
}

void drawGrammer(Group *grp)
{
	int i,j;
	if(grp->strokenum>0)
	{
		int ssind=0;
		for(ssind=0;ssind<grp->strokenum;ssind++)
		{
			double rotval=realGuassGenerate(stroke_rotate_maxang,stroke_rotate_maxang/6,-stroke_rotate_maxang,stroke_rotate_maxang);//(1-rand()*2.0/RAND_MAX);
			int retx,rety;
			//rotate_point(grp->draw_strokes[ssind].ptecol,grp->draw_strokes[ssind].pterow,
			//grp->draw_strokes[ssind].ptscol,grp->draw_strokes[ssind].ptsrow,retx,rety,rotval);
			grp->draw_strokes[ssind].ptscol=grp->strokes[ssind].ptscol;
			grp->draw_strokes[ssind].ptsrow=grp->strokes[ssind].ptsrow;
			grp->draw_strokes[ssind].ptecol=grp->strokes[ssind].ptecol;
			grp->draw_strokes[ssind].pterow=grp->strokes[ssind].pterow;
		}
	}

}


void rotateEachStroke(Group *grp)
{
	int i,j;
	if(grp->strokenum>0)
	{
		int ssind=0;
		for(ssind=0;ssind<grp->strokenum;ssind++)
		{
			double rotval=realGuassGenerate(stroke_rotate_maxang,stroke_rotate_maxang/6,-stroke_rotate_maxang,stroke_rotate_maxang);//(1-rand()*2.0/RAND_MAX);
			int retx,rety;
			rotate_point(grp->draw_strokes[ssind].ptecol,grp->draw_strokes[ssind].pterow,
				grp->draw_strokes[ssind].ptscol,grp->draw_strokes[ssind].ptsrow,retx,rety,rotval);

			grp->draw_strokes[ssind].ptecol=retx;//grp->strokes[ssind].ptecol;
			grp->draw_strokes[ssind].pterow=rety;//grp->strokes[ssind].pterow;

			if(ssind<grp->strokenum-1 && grp->con_ss[ssind].canCut==0)
			{
				grp->draw_strokes[ssind+1].ptecol=grp->draw_strokes[ssind+1].ptecol+grp->draw_strokes[ssind].ptecol-grp->draw_strokes[ssind+1].ptscol;
				grp->draw_strokes[ssind+1].pterow=grp->draw_strokes[ssind+1].pterow+grp->draw_strokes[ssind].pterow-grp->draw_strokes[ssind+1].ptsrow;

				grp->draw_strokes[ssind+1].ptscol=grp->draw_strokes[ssind].ptecol;
				grp->draw_strokes[ssind+1].ptsrow=grp->draw_strokes[ssind].pterow;
			}
		}
	}

}


int iscontinue_con(int iscancut, int ex,int ey,int sx,int sy,int wid,int hei,int islikecon)
{
	if(iscancut==0)
		return true;
	float disw=abs(ex-sx)*1.0/wid;
	float dish=abs(ey-sy)*1.0/hei;
	int rdv=rand();
	double problong=prob_longdis_connect;
	double probsht=prob_shortdis_connet;

	if(islikecon==1)
	{
		problong=prob_like_con_weilong;
		probsht=prob_like_con_weishort;
	}
	if(disw>det_long_short_connect || dish>det_long_short_connect)//long
	{
		if( rdv*1.0/RAND_MAX<=problong)
			return 1;
		else
			return 0;
	}
	else//short
	{
		if( rdv*1.0/RAND_MAX<=probsht)
			return 1;
		else
			return 0;
	}

}

void get_point_onstroke_around(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,int maxwid)
{
	if(!glo_is_writing_Chi)
	{	
		int len;
		get_randpoint_onstroke(ptsrow,ptscol,pterow,ptecol,crow,ccol,len);
		float pro=1.0*maxwid/len;
		float weicurpro=1;//log(5+pro);
		/*	if(pro<2)
		weicurpro=1;
		else if(pro<3)
		weicurpro=1.5;
		else if(pro<4)
		weicurpro=2;
		else
		weicurpro=2.5;
		*/
		float temp_curvepro=(1-rand()*2.0/RAND_MAX)*(glo_max_curvepro)*weicurpro;
		float temp_curvepro2=(1-rand()*2.0/RAND_MAX)*(glo_max_curvepro)*weicurpro;
		/*	if(temp_curvepro>0.3)
		temp_curvepro=0.3;
		if(temp_curvepro<-0.3)
		temp_curvepro=-0.3;*/
		int rx,ry;
		crow=crow+len*temp_curvepro;
		ccol=ccol+len*temp_curvepro2;
	}
	else
	{
		int len;
		get_randpoint_onstroke(ptsrow,ptscol,pterow,ptecol,crow,ccol,len);
		float pro=1.0*maxwid/len;
		float weicurpro=1;//log(5+pro);
		/*	if(pro<2)
		weicurpro=0.5;
		else if(pro<3)
		weicurpro=0.75;
		else if(pro<4)
		weicurpro=1;
		else
		weicurpro=1.25;
		*/
		float temp_curvepro=(1-rand()*2.0/RAND_MAX)*(glo_max_curvepro)*weicurpro;
		float temp_curvepro2=(1-rand()*2.0/RAND_MAX)*(glo_max_curvepro)*weicurpro;

		/*	float maxcurpro=0.4;
		if(temp_curvepro>maxcurpro)
		temp_curvepro=maxcurpro;
		if(temp_curvepro<-maxcurpro)
		temp_curvepro=-maxcurpro;*/
		int rx,ry;
		crow=crow+len*temp_curvepro;
		ccol=ccol+len*temp_curvepro2;
	}
}



void get_con_stroke_pts(int i_ptsrow,int i_ptscol,int i_pterow,int i_ptecol,
	int i1_ptsrow,int i1_ptscol,int i1_pterow,int i1_ptecol,
	int &ip_crow,int &ip_ccol,int &i_crow,int &i_ccol,int &x_crow,int &x_ccol,int &i1_crow,int &i1_ccol,
	int &i1f_crow,int &i1f_ccol,int &i1ff_crow,int &i1ff_ccol
	)
{
	int i_disrow=abs(i_pterow-i_ptsrow);
	int i_discol=abs(i_ptecol-i_ptscol);

	if(i_disrow==0 && i_discol==0)
	{
		i_crow=i_ptsrow;i_ccol=i_ptscol;ip_crow=i_ptsrow;ip_ccol=i_ptscol;
	}
	else
	{
		float val=glo_constroke_start_pro+glo_constroke_max_lenpro*rand()*1.0/RAND_MAX;
		if(val<1)
		{

			ip_crow=i_ptsrow+(i_pterow-i_ptsrow)*val;
			ip_ccol=i_ptscol+(i_ptecol-i_ptscol)*val;
			i_crow=i_pterow;
			i_ccol=i_ptecol;
		}
		else
		{
			i_crow=i_ptsrow+(i_pterow-i_ptsrow)*val;
			i_ccol=i_ptscol+(i_ptecol-i_ptscol)*val;	
			ip_crow=i_pterow;
			ip_ccol=i_ptecol;
		}
	}


	int i1_disrow=abs(i1_pterow-i1_ptsrow);
	int i1_discol=abs(i1_ptecol-i1_ptscol);

	if(i1_disrow==0 && i1_discol==0)
	{
		i1_crow=i1_ptsrow;i1_ccol=i1_ptscol;i1f_crow=i1_ptsrow;i1f_ccol=i1_ptscol;i1ff_crow=i1_ptsrow;i1ff_ccol=i1_ptscol;
	}
	else
	{
		float val=glo_constroke_start_pro+glo_constroke_max_lenpro*rand()*1.0/RAND_MAX;
		if(val<1)
		{
			i1f_crow=i1_pterow+(i1_ptsrow-i1_pterow)*val;
			i1f_ccol=i1_ptecol+(i1_ptscol-i1_ptecol)*val;

			i1_crow=i1_ptsrow;
			i1_ccol=i1_ptscol;

			get_point_onstroke(i1f_crow,i1f_ccol,i1_pterow,i1_ptecol,i1ff_crow,i1ff_ccol,rand()*1.0/RAND_MAX);
		}
		else
		{

			i1_crow=i1_pterow+(i1_ptsrow-i1_pterow)*val;
			i1_ccol=i1_ptecol+(i1_ptscol-i1_ptecol)*val;

			i1f_crow=i1_ptsrow;
			i1f_ccol=i1_ptscol;
			get_point_onstroke(i1f_crow,i1f_ccol,i1_pterow,i1_ptecol,i1ff_crow,i1ff_ccol,rand()*1.0/RAND_MAX);
		}
	}


	get_point_onstroke(i_crow,i_ccol,i1_crow,i1_ccol,x_crow,x_ccol,rand()*1.0/RAND_MAX);
}

void get_randpoint_onstroke(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,int &len)
{
	int disrow=abs(pterow-ptsrow);
	int discol=abs(ptecol-ptscol);
	len=sqrt(1.0*disrow*disrow+discol*discol);
	float rdv=rand()*1.0/RAND_MAX;
	if(disrow==0 && discol==0)
	{
		crow=ptsrow;ccol=ptscol;len=0;
	}
	else
	{
		if(disrow>discol)
		{

			crow=ptsrow+(pterow-ptsrow)*rdv;
			ccol=ptscol+(crow-ptsrow)*(ptecol-ptscol)	/(pterow-ptsrow);
		}
		else
		{

			ccol=ptscol+(ptecol-ptscol)*rdv;
			crow=ptsrow+(ccol-ptscol)*(pterow-ptsrow)/(ptecol-ptscol);
		}
	}
}

void get_randpoint_inTri(int i_pterow,int i_ptecol,int ia1_ptsrow,int ia1_ptscol,int i_x_ptrow,int i_x_ptcol,int &crow,int &ccol)
{
	int trow,tcol,tlen;
	get_randpoint_onstroke(ia1_ptsrow,ia1_ptscol,i_x_ptrow,i_x_ptcol,trow,tcol,tlen);
	get_randpoint_onstroke(i_pterow,i_ptecol,trow+trow-i_pterow,tcol+tcol-i_ptecol,crow,ccol,tlen);
}




void get_point_onstroke(int ptsrow,int ptscol,int pterow,int ptecol,int &crow,int &ccol,float val)
{
	int disrow=abs(pterow-ptsrow);
	int discol=abs(ptecol-ptscol);

	if(disrow==0 && discol==0)
	{
		crow=ptsrow;ccol=ptscol;
	}
	else
	{

		crow=ptsrow+(pterow-ptsrow)*val;

		ccol=ptscol+(ptecol-ptscol)*val;

	}
}

int LineToCurve_con2str(Group *grp,int* isendstroke_ofpart)
{
	int islikecon=0;
	if( (rand()%10)/10.0<=prob_like_con)
		islikecon=1;
	int i;
	int cntdcnum=0;	
	int cntpnum=0;
	int crow,ccol,len;
	int rx,ry;
	double rdptpro=0.2;
	int grp_max_wid=grp->right-grp->left;
	if(grp->bot-grp->top>grp_max_wid)
		grp_max_wid=grp->bot-grp->top;

	bool isallcon=true;
	for(int j=0;j<grp->strokenum-1;j++)
	{
		if(grp->con_ss[j].canCut==1)
		{
			isallcon=false;
			break;
		}
	}

	if(isallcon)
	{

		int crow,ccol,len=0;
		bool loc_iscut=false;
		for(int j=0;j<grp->strokenum;j++)
		{
			int randval=rand();
			if(j>0 && j<grp->strokenum-1&&(randval%100>glo_cutcon_pro))
			{
				int retpnum=0,retdcnum=0;
				con_2stk_pos(grp,j-1,cntdcnum,cntpnum,retpnum,retdcnum);
				cntpnum=retpnum;
				cntdcnum=retdcnum;

			}
			else
			{
				get_point_onstroke_around(grp->draw_strokes[j].ptsrow,grp->draw_strokes[j].ptscol,grp->draw_strokes[j].pterow,
					grp->draw_strokes[j].ptecol,rx,ry,grp_max_wid);
				int randval=rand();
				if(randval%100>glo_add_stroke_pro)//and a stroke
				{
					get_point_onstroke(grp->draw_strokes[j].ptsrow,grp->draw_strokes[j].ptscol,grp->draw_strokes[j].pterow,
						grp->draw_strokes[j].ptecol,rx,ry,rand()*1.0/RAND_MAX);

					int rx1,ry1;
					int rx2,ry2;
					get_point_onstroke_around(grp->draw_strokes[j].ptsrow,grp->draw_strokes[j].ptscol,rx,ry,rx1,ry1,grp_max_wid);
					get_point_onstroke_around(	rx,ry,grp->draw_strokes[j].pterow,grp->draw_strokes[j].ptecol,rx2,ry2,grp_max_wid);

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[j].ptsrow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[j].ptscol;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx1;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry1;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx2;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry2;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[j].pterow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[j].ptecol;
					cntpnum++;
				}
				else
				{
					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[j].ptsrow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[j].ptscol;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[j].pterow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[j].ptecol;
					cntpnum++;
				}
			}
		}
		grp->draw_curves[cntdcnum].pnum=cntpnum;
		grp->draw_curves[cntdcnum].isCon=0;
		cntdcnum++;
	}
	else
	{
		bool loc_iscut=false;

		for(i=0;i<grp->strokenum;i++)
		{

			int randval=rand();
			if(i>0 && isendstroke_ofpart[i-1]!=-1 &&iscontinue_con(grp->con_ss[i-1].canCut,grp->draw_strokes[i-1].ptecol,grp->draw_strokes[i-1].pterow,
				grp->draw_strokes[i].ptscol,grp->draw_strokes[i].ptsrow,grp->right-grp->left,grp->bot-grp->top,islikecon))
			{
				int randval=rand();
				if((randval%100>glo_cutcon_pro && !grp->con_ss[i-1].canCut)||(randval%100>glo_cutcon_pro2 && grp->con_ss[i-1].canCut))
				{
					int retpnum=0,retdcnum=0;
					con_2stk_pos(grp,i-1,cntdcnum,cntpnum,retpnum,retdcnum);
					cntpnum=retpnum;
					cntdcnum=retdcnum;
				}
				else
				{

					if((i>=2 && (isendstroke_ofpart[i-1]-isendstroke_ofpart[i-2]<0 ))
						|| isendstroke_ofpart[i-1]-isendstroke_ofpart[i]<0)
					{
						if(rand()%2==0)
						{
							int reptnum=3;
							int reptnum2=3;
							for(int rdnbs=0;rdnbs<reptnum;rdnbs++)
							{
								grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i-1].pterow;
								grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i-1].ptecol;
								cntpnum++;
							}
							for(int rdnbs=0;rdnbs<reptnum2;rdnbs++)
							{
								grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
								grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
								cntpnum++;
							}

							if(cntpnum>0)
							{
								grp->draw_curves[cntdcnum].pnum=cntpnum;
								grp->draw_curves[cntdcnum].isCon=0;
								cntdcnum++;	
								cntpnum=0;
							}
						}
						else
						{
							int reptnum=3+rand()%13;
							int reptnum2=3+rand()%13;
							for(int rdnbs=0;rdnbs<reptnum;rdnbs++)
							{
								grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i-1].pterow;
								grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i-1].ptecol;
								cntpnum++;
							}
							for(int rdnbs=0;rdnbs<reptnum2;rdnbs++)
							{
								grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
								grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
								cntpnum++;
							}
						}


					}
					else if(grp->con_ss[i-1].canCut)
					{
						int reptnum=0+rand()%7;
						int reptnum2=0+rand()%7;
						for(int rdnbs=0;rdnbs<reptnum;rdnbs++)
						{
							grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i-1].pterow;
							grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i-1].ptecol;
							cntpnum++;
						}
						for(int rdnbs=0;rdnbs<reptnum2;rdnbs++)
						{
							grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
							grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
							cntpnum++;
						}

					}
					get_point_onstroke_around(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,grp->draw_strokes[i].pterow,
						grp->draw_strokes[i].ptecol,rx,ry,grp_max_wid);
					int randval=rand();
					if(randval%100>glo_add_stroke_pro)//and a stroke
					{
						get_point_onstroke(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,grp->draw_strokes[i].pterow,
							grp->draw_strokes[i].ptecol,rx,ry,rand()*1.0/RAND_MAX);

						int rx1,ry1;
						int rx2,ry2;
						get_point_onstroke_around(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,rx,ry,rx1,ry1,grp_max_wid);
						get_point_onstroke_around(	rx,ry,grp->draw_strokes[i].pterow,grp->draw_strokes[i].ptecol,rx2,ry2,grp_max_wid);

						grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
						grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=rx1;
						grp->draw_curves[cntdcnum].y[cntpnum]=ry1;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=rx;
						grp->draw_curves[cntdcnum].y[cntpnum]=ry;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=rx;
						grp->draw_curves[cntdcnum].y[cntpnum]=ry;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=rx2;
						grp->draw_curves[cntdcnum].y[cntpnum]=ry2;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].pterow;
						grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptecol;
						cntpnum++;
					}
					else
					{
						grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
						grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=rx;
						grp->draw_curves[cntdcnum].y[cntpnum]=ry;
						cntpnum++;

						grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].pterow;
						grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptecol;
						cntpnum++;
					}
				}

			}
			else
			{
				if(cntpnum>0)
				{
					grp->draw_curves[cntdcnum].pnum=cntpnum;
					grp->draw_curves[cntdcnum].isCon=0;
					cntdcnum++;	
					cntpnum=0;
				}
				int crow,ccol,len=0;
				get_point_onstroke_around(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,
					grp->draw_strokes[i].pterow,grp->draw_strokes[i].ptecol,rx,ry,grp_max_wid);

				int randval=rand();
				if(randval%100>glo_add_stroke_pro)//and a stroke
				{
					get_point_onstroke(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,grp->draw_strokes[i].pterow,
						grp->draw_strokes[i].ptecol,rx,ry,rand()*1.0/RAND_MAX);

					int rx1,ry1;
					int rx2,ry2;
					get_point_onstroke_around(grp->draw_strokes[i].ptsrow,grp->draw_strokes[i].ptscol,rx,ry,rx1,ry1,grp_max_wid);
					get_point_onstroke_around(	rx,ry,grp->draw_strokes[i].pterow,grp->draw_strokes[i].ptecol,rx2,ry2,grp_max_wid);

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx1;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry1;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx2;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry2;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].pterow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptecol;
					cntpnum++;
				}
				else
				{
					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].ptsrow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptscol;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=rx;
					grp->draw_curves[cntdcnum].y[cntpnum]=ry;
					cntpnum++;

					grp->draw_curves[cntdcnum].x[cntpnum]=grp->draw_strokes[i].pterow;
					grp->draw_curves[cntdcnum].y[cntpnum]=grp->draw_strokes[i].ptecol;
					cntpnum++;
				}

			}




		}
		if(cntpnum>0)
		{
			grp->draw_curves[cntdcnum].pnum=cntpnum;
			grp->draw_curves[cntdcnum].isCon=0;
			cntdcnum++;	
		}


	}
	return cntdcnum;
}
void con_2stk_pos(Group *grp,int i,int cntdcnum,int cntpnum,int &retcntpnum,int &retcntdcnum)//
{
	bool iscuti=false;
	bool iscutia1=false;

	int grp_max_wid=grp->right-grp->left;
	if(grp->bot-grp->top>grp_max_wid)
		grp_max_wid=grp->bot-grp->top;


	int i_crow,i_ccol,ip_crow,ip_ccol;
	int x_crow,x_ccol;
	int i1_crow,i1_ccol,i1f_crow,i1f_ccol,i1ff_crow,i1ff_ccol;
	get_con_stroke_pts(grp->draw_strokes[i].ptsrow,
		grp->draw_strokes[i].ptscol,
		grp->draw_strokes[i].pterow,
		grp->draw_strokes[i].ptecol,
		grp->draw_strokes[i+1].ptsrow,
		grp->draw_strokes[i+1].ptscol,
		grp->draw_strokes[i+1].pterow,
		grp->draw_strokes[i+1].ptecol,

		ip_crow,ip_ccol,i_crow,i_ccol,x_crow,x_ccol,i1_crow,i1_ccol,i1f_crow,i1f_ccol ,i1ff_crow,i1ff_ccol);

	get_point_onstroke_around(i_crow,i_ccol,i1_crow,i1_ccol,x_crow,x_ccol,grp_max_wid);
	get_point_onstroke_around(i1_crow,i1_ccol,grp->draw_strokes[i+1].pterow,grp->draw_strokes[i+1].ptecol,i1f_crow,i1f_ccol,grp_max_wid);
	int cnt=0;		
	float cutipro=1;
	if(grp->con_ss[i-1].canCut==0)
	{
		cutipro=0.5;
	}
	float cutia1pro=1;
	if(grp->con_ss[i].canCut==0)
	{
		cutia1pro=0.5;
	}
	if(rand()%10<cutipro*glo_pro_cut_iend)//cut i end glo_pro_cut_iend 8
	{
		iscuti=1;
		cnt=0;
		grp->draw_curves[cntdcnum].x[cntpnum-1]=i_crow;
		grp->draw_curves[cntdcnum].y[cntpnum-1]=i_ccol;
		grp->draw_curves[cntdcnum].pnum=cntpnum;
		grp->draw_curves[cntdcnum].isCon=0;
		cntdcnum++;

		grp->draw_curves[cntdcnum].x[cnt]=i_crow;
		grp->draw_curves[cntdcnum].y[cnt]=i_ccol;
		cnt++;
		if(rand()%10<5)
		{
			int tmp_crow,tmp_ccol;
			get_point_onstroke_around(i_crow,i_ccol,x_crow,x_ccol,tmp_crow,tmp_ccol,grp_max_wid);
			grp->draw_curves[cntdcnum].x[cnt]=tmp_crow;
			grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol;
			cnt++;
		}
		grp->draw_curves[cntdcnum].x[cnt]=x_crow;
		grp->draw_curves[cntdcnum].y[cnt]=x_ccol;
		cnt++;
		if(rand()%10<5)
		{
			int tmp_crow,tmp_ccol;
			get_point_onstroke_around(x_crow,x_ccol,i1_crow,i1_ccol,tmp_crow,tmp_ccol,grp_max_wid);
			grp->draw_curves[cntdcnum].x[cnt]=tmp_crow;
			grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol;
			cnt++;
			if(rand()%10<5)
			{
				int tmp_crow2,tmp_ccol2;
				get_point_onstroke_around(tmp_crow,tmp_ccol,i1_crow,i1_ccol,tmp_crow2,tmp_ccol2,grp_max_wid);
				grp->draw_curves[cntdcnum].x[cnt]=tmp_crow2;
				grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol2;
				cnt++;
			}
		}
		grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
		grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
		cnt++;

		if(rand()%10<cutia1pro*glo_pro_cut_ia1end)//cut ia1 end glo_pro_cut_ia1end 5
		{
			iscutia1=1;
			grp->draw_curves[cntdcnum].pnum=cnt;
			grp->draw_curves[cntdcnum].isCon=1;
			cntdcnum++;
			cnt=0;
			grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=i1f_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1f_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=grp->draw_strokes[i+1].pterow;
			grp->draw_curves[cntdcnum].y[cnt]=grp->draw_strokes[i+1].ptecol;
			cnt++;
		}
		else
		{
			iscutia1=0;
			grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=i1f_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1f_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=grp->draw_strokes[i+1].pterow;
			grp->draw_curves[cntdcnum].y[cnt]=grp->draw_strokes[i+1].ptecol;
			cnt++;
		}
	}
	else// not cut i
	{
		iscuti=0;
		cnt=cntpnum;
		grp->draw_curves[cntdcnum].x[cnt]=i_crow;
		grp->draw_curves[cntdcnum].y[cnt]=i_ccol;
		cnt++;
		if(rand()%10<5)
		{
			int tmp_crow,tmp_ccol;
			get_point_onstroke_around(i_crow,i_ccol,x_crow,x_ccol,tmp_crow,tmp_ccol,grp_max_wid);
			grp->draw_curves[cntdcnum].x[cnt]=tmp_crow;
			grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol;
			cnt++;
		}
		grp->draw_curves[cntdcnum].x[cnt]=x_crow;
		grp->draw_curves[cntdcnum].y[cnt]=x_ccol;
		cnt++;
		if(rand()%10<5)
		{
			int tmp_crow,tmp_ccol;
			get_point_onstroke_around(x_crow,x_ccol,i1_crow,i1_ccol,tmp_crow,tmp_ccol,grp_max_wid);
			grp->draw_curves[cntdcnum].x[cnt]=tmp_crow;
			grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol;
			cnt++;
			if(rand()%10<5)
			{
				int tmp_crow2,tmp_ccol2;
				get_point_onstroke_around(tmp_crow,tmp_ccol,i1_crow,i1_ccol,tmp_crow2,tmp_ccol2,grp_max_wid);
				grp->draw_curves[cntdcnum].x[cnt]=tmp_crow2;
				grp->draw_curves[cntdcnum].y[cnt]=tmp_ccol2;
				cnt++;
			}
		}
		grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
		grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
		cnt++;

		if(rand()%10<cutia1pro*glo_pro_cut_ia1end)//cut ia1 end glo_pro_cut_ia1end 5
		{
			iscutia1=1;
			grp->draw_curves[cntdcnum].pnum=cnt;
			grp->draw_curves[cntdcnum].isCon=0;
			cntdcnum++;
			cnt=0;
			grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=i1f_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1f_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=grp->draw_strokes[i+1].pterow;
			grp->draw_curves[cntdcnum].y[cnt]=grp->draw_strokes[i+1].ptecol;
			cnt++;
		}
		else
		{
			iscutia1=0;
			grp->draw_curves[cntdcnum].x[cnt]=i1_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=i1f_crow;
			grp->draw_curves[cntdcnum].y[cnt]=i1f_ccol;
			cnt++;
			grp->draw_curves[cntdcnum].x[cnt]=grp->draw_strokes[i+1].pterow;
			grp->draw_curves[cntdcnum].y[cnt]=grp->draw_strokes[i+1].ptecol;
			cnt++;
		}
	}
	retcntpnum=cnt;
	retcntdcnum=cntdcnum;
}
double sol2(int nn,int k)  //�������ʽ��ϵ��C(nn,k)  
{  
	int i;  
	double sum=1;  
	for(i=1;i<=nn;i++)  
		sum*=i;  
	for(i=1;i<=k;i++)  
		sum/=i;  
	for(i=1;i<=nn-k;i++)  
		sum/=i;  
	return sum;  
}  
void sol3(int n,int* px,int* py,double t,double &retx,double &rety)  //����Bezier�����ϵ������  
{  
	double x=0,y=0,Ber;  
	int k;  
	for(k=0;k<n;k++)  
	{  
		Ber=sol2(n-1,k)*pow(t,k)*pow(1-t,n-1-k);  
		x+=px[k]*Ber;  
		y+=py[k]*Ber;  
	}  
	retx=x;rety=y;
	//putpixel((int)x,(int)y,GREEN);  
}  

double get_curlen(int n,int* px,int* py)  //����Bezier�����ϵ������  
{  
	double len=0;  
	int k;  
	for(k=0;k<n-1;k++)  
	{  
		len+=sqrt(1.0*(px[k]-px[k+1])*(px[k]-px[k+1])+(py[k]-py[k+1])*(py[k]-py[k+1]));

	}  
	return len;
}  

/*void sol4()  //���ݿ��Ƶ㣬�������ϵ�m����  
{  
int m=500,i;  
for(i=0;i<=m;i++)  
sol3((double)i/(double)m);  
} */ 


void drawCurveOnImg_Bezier(Group *grp,int onegroupwid,int onegrouphei)
{
	float stk_rdmax=1.25;//1+rand()*0.25/RAND_MAX;
	float stk_rdmin=0.75;//+rand()*0.25/RAND_MAX;
	int dcind=0;
	int strrdval=5+rand()%grayval;
	int iNumber=3;
	double u,x,y;
	int minwid=0;
	int glograyval=grayval;
	int pregrayval=glograyval;
	//if(grp->strokenum<2)
	minwid=(onegroupwid+onegrouphei)/2;
	//else
	//	minwid=(onegroupwid<onegrouphei)?onegroupwid:onegrouphei;
	int maxwid=(onegroupwid>onegrouphei)?onegroupwid:onegrouphei;

	int sw=2+rand()%3;//+minwid*strokewidpro+maxwid*strokewidpro_rd*realGuassGenerate(0,1.0/3,-1,1);
	int curminsw=3;
	int curmaxsw=15;
	int raodong=0.1*sw;
	if(raodong<1)
		raodong=1;
	int prestrokewid=sw;
	int gray_like_lorh=rand()%10>=5;
	int sw_like_cuorxi=rand()%10>=5;
	while(dcind<grp->curvenum)
	{
		double len=get_curlen(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y);
		double ustep=0.001;//sqrt(1.0*grp->draw_curves[dcind].pnum)* 0.005*sw/len;
		prestrokewid=sw;
		if(1)
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);
			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;			
			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);
			lastrdvvvv=(1-lastrdvvvv);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;

			for(u=0;u<=1;u=u+ustep)
			{		
				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);					
				int cr=(int)x;int cc=(int)y;
				if(cr<0)	cr=0;	if(cc<0)	cc=0;
				if(cr>height-1)	cr=height-1;if(cc>width-1)	cc=width-1;
				//int curgrayval=glograyval;
				int si,ei,sj,ej;

				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;

						sw_like_cuorxi=rand()%10>=5;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;
						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				int curgrayval=0;
				if((pregrayval<stk_rdmax*glograyval&&gray_like_lorh)||pregrayval<stk_rdmin*glograyval)
				{
					if(rand()%10>=2)
						curgrayval=pregrayval;
					else
						curgrayval=pregrayval+1;

					gray_like_lorh=rand()%10>=5;
				}
				else if((pregrayval>stk_rdmin*glograyval&&(!gray_like_lorh))||pregrayval>stk_rdmax*glograyval)
				{
					if(rand()%10>=2)
						curgrayval=pregrayval;
					else
						curgrayval=pregrayval-1;

					gray_like_lorh=rand()%10>=5;
				}

				if(curgrayval<50)
					curgrayval=50;
				if(curgrayval>255)
					curgrayval=255;
				pregrayval=curgrayval;

				if(cursw>6)
				{
					printf("err");
				}

				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));

				//float rds=((mi-si)+(mj-sj))/2;
				glo_graydec=curgrayval/rds;
				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>=rds)
							curgrayval_in=0;
						else
							curgrayval_in=curgrayval+(strrdval-(rand()%(2*strrdval)))-glo_graydec*cdis;//
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>255)curgrayval_in=255;
						//if(glo_img[li*width+lj]>0)
						//	glo_img[li*width+lj]=(glo_img[li*width+lj]+curgrayval_in)/2;
						//else
						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}
		}
		else
		{
			float umax=0;
			for(u=0;u<=umax;u=u+0.001)
			{
				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=0;
				if((pregrayval<stk_rdmax*glograyval&&gray_like_lorh)||pregrayval<stk_rdmin*glograyval)
				{
					if(rand()%10>=2)
						curgrayval=pregrayval;
					else
						curgrayval=pregrayval+1;

					gray_like_lorh=rand()%10>=5;
				}
				else if((pregrayval>stk_rdmin*glograyval&&(!gray_like_lorh))||pregrayval>stk_rdmax*glograyval)
				{
					if(rand()%10>=2)
						curgrayval=pregrayval;
					else
						curgrayval=pregrayval-1;

					gray_like_lorh=rand()%10>=5;
				}

				if(curgrayval<50)
					curgrayval=50;
				if(curgrayval>255)
					curgrayval=255;
				pregrayval=curgrayval;


				int si,ei,sj,ej;
				int cursw=0;
				if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid+1;

					sw_like_cuorxi=rand()%10>=5;
				}
				else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid-1;
					sw_like_cuorxi=rand()%10>=5;
				}


				if(cursw<glo_minsw)
					cursw=glo_minsw;

				prestrokewid=cursw;

				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));

				//float rds=((mi-si)+(mj-sj))/2;
				glo_graydec=curgrayval/rds;
				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>=rds)
							curgrayval_in=0;
						else
							curgrayval_in=curgrayval+(strrdval-(rand()%(2*strrdval)))-glo_graydec*cdis;//
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>255)curgrayval_in=255;
						//if(glo_img[li*width+lj]>0)
						//	glo_img[li*width+lj]=(glo_img[li*width+lj]+curgrayval_in)/2;
						//else
						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}
			}
		}
		dcind++;
	}


}

void drawCurveOnImg_Bezier(Group *grp,int onegroupwid,int onegrouphei,int width,int height)
{
	int dcind=0;
	int iNumber=3;
	double u,x,y;
	int minwid=0;
	int glograyval=grayval;
	int pregrayval=glograyval;
	//if(grp->strokenum<2)
	minwid=(onegroupwid+onegrouphei)/2;
	//else
	//	minwid=(onegroupwid<onegrouphei)?onegroupwid:onegrouphei;
	int maxwid=(onegroupwid>onegrouphei)?onegroupwid:onegrouphei;

	int sw=2+rand()%3;//+minwid*strokewidpro+maxwid*strokewidpro_rd*realGuassGenerate(0,1.0/3,-1,1);
	if(sw<2)
		sw=2;
	int raodong=0.1*sw;
	if(raodong<1)
		raodong=1;
	int prestrokewid=sw;
	int gray_like_lorh=rand()%10>=5;
	int sw_like_cuorxi=rand()%10>=5;
	while(dcind<grp->curvenum)
	{
		float umax=0;
		if(!grp->draw_curves[dcind].isCon)
		{
			//glograyval=255;
			umax=1;
		}
		else
		{
			//glograyval=255;
			umax=1;//rand()*1.0/RAND_MAX;
		}
		for(u=0;u<=umax;u=u+0.001)
		{
			x=0;y=0;
			sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

			int cr=(int)x;
			int cc=(int)y;
			if(cr<0)
				cr=0;
			if(cc<0)
				cc=0;
			if(cr>height-1)
				cr=height-1;
			if(cc>width-1)
				cc=width-1;

			int curgrayval=0;
			if((pregrayval<1.25*glograyval&&gray_like_lorh)||pregrayval<0.8*glograyval)
			{
				if(rand()%10>=2)
					curgrayval=pregrayval;
				else
					curgrayval=pregrayval+1;

				gray_like_lorh=rand()%10>=2;
			}
			else if((pregrayval>0.8*glograyval&&(!gray_like_lorh))||pregrayval>1.25*glograyval)
			{
				if(rand()%10>=2)
					curgrayval=pregrayval;
				else
					curgrayval=pregrayval-1;

				gray_like_lorh=rand()%10>=8;
			}

			if(curgrayval<50)
				curgrayval=50;
			if(curgrayval>255)
				curgrayval=255;
			pregrayval=curgrayval;


			int si,ei,sj,ej;
			int cursw=0;
			if((prestrokewid<1.25*sw&&sw_like_cuorxi)||prestrokewid<0.8*sw)
			{
				if(rand()%10>=2)
					cursw=prestrokewid;
				else
					cursw=prestrokewid+1;
				sw_like_cuorxi=rand()%10>=2;
			}
			else if((prestrokewid>0.8*sw&&(!sw_like_cuorxi))||prestrokewid>1.25*sw)
			{
				if(rand()%10>=2)
					cursw=prestrokewid;
				else
					cursw=prestrokewid-1;

				sw_like_cuorxi=rand()%10>=5;
			}

			if(cursw<glo_minsw)
				cursw=glo_minsw;

			prestrokewid=cursw;

			si=cr-cursw/2>=0?cr-cursw/2:0;
			ei=si+cursw-1;	
			sj=cc-cursw/2>=0?cc-cursw/2:0;
			ej=sj+cursw-1;
			if(ei>=height)
			{	ei=height-1;si=ei-cursw+1;}
			if(ej>=width)
			{	ej=width-1;sj=ej-cursw+1;}

			float mi=(si+ei)/2.0;
			float mj=(sj+ej)/2.0;
			float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));

			//float rds=((mi-si)+(mj-sj))/2;
			glo_graydec=curgrayval/rds;
			for(int li=si;li<=ei;li++)
			{
				for(int lj=sj;lj<=ej;lj++)
				{
					int curgrayval_in;
					float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
					if(cdis>=rds)
						curgrayval_in=0;
					else
						curgrayval_in=curgrayval+(30-(rand()%60));//-glo_graydec*cdis;//
					if(curgrayval_in<0)curgrayval_in=0;
					if(curgrayval_in>255)curgrayval_in=255;
					//if(glo_img[li*width+lj]>0)
					//	glo_img[li*width+lj]=(glo_img[li*width+lj]+curgrayval_in)/2;
					//else
					glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
				}
			}
		}

		dcind++;
	}


}

int getGrpWid(Group *grp,int &maxhei)
{
	int minwid=1000000;

	for(int i=0;i<20;i++)
	{


		if(grp->partition_wid<minwid)
		{
			minwid=grp->partition_wid;
			if(grp->partition_hei>maxhei)
				maxhei=grp->partition_hei;
		}



		rotatePart3((grp),0.2); //rotval
		updateGrp_draw((grp));


	}
	for(int i=0;i<20;i++)
	{
		rotatePart3((grp),-0.2); //rotval
		updateGrp_draw((grp));
	}

	return minwid;
}
float get_minParalStkDis(Group *grp,int min_charwid,int min_charhei)
{
	int mindis=1000000;
	float intepro1=0.1;

	for(int i=0;i<grp->strokenum;i++)
	{

		for(int j=i+1;j<grp->strokenum;j++)
		{

			int mintop=grp->strokes[i].ptsrow;
			if(grp->strokes[i].pterow<mintop)
				mintop=grp->strokes[i].pterow;
			if(grp->strokes[j].pterow<mintop)
				mintop=grp->strokes[j].pterow;
			if(grp->strokes[j].ptsrow<mintop)
				mintop=grp->strokes[j].ptsrow;

			int maxbot=grp->strokes[i].ptsrow;
			if(grp->strokes[i].pterow>maxbot)
				maxbot=grp->strokes[i].pterow;
			if(grp->strokes[j].pterow>maxbot)
				maxbot=grp->strokes[j].pterow;
			if(grp->strokes[j].ptsrow>maxbot)
				maxbot=grp->strokes[j].ptsrow;

			int minleft=grp->strokes[i].ptscol;
			if(grp->strokes[i].ptecol<minleft)
				minleft=grp->strokes[i].ptecol;
			if(grp->strokes[j].ptecol<minleft)
				minleft=grp->strokes[j].ptecol;
			if(grp->strokes[j].ptscol<minleft)
				minleft=grp->strokes[j].ptscol;

			int maxright=grp->strokes[i].ptscol;
			if(grp->strokes[i].ptecol>maxright)
				maxright=grp->strokes[i].ptecol;
			if(grp->strokes[j].ptecol>maxright)
				maxright=grp->strokes[j].ptecol;
			if(grp->strokes[j].ptscol>maxright)
				maxright=grp->strokes[j].ptscol;

			int intedis=(abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)+abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow))-(maxbot-mintop);
			int intedis2=(abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)+abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol))-(maxright-minleft);
			if(
				((  intedis>intepro1*abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)
				||intedis>intepro1*abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow)
				)&&(!(abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)*1.0/abs(0.001+grp->strokes[i].ptscol-grp->strokes[i].ptecol)<0.5
				&&abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow)*1.0/abs(0.001+grp->strokes[j].ptscol-grp->strokes[j].ptecol)<0.5))
				)
				||
				((  intedis2>intepro1*abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)
				||intedis2>intepro1*abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol)
				)&&(!(abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)*1.0/abs(0.001+grp->strokes[i].ptsrow-grp->strokes[i].pterow)<0.5
				&&abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol)*1.0/abs(0.001+grp->strokes[j].ptsrow-grp->strokes[j].pterow)<0.5))
				)
				)


			{
				//dis1=the maxdis between is and j, ie and j     dis2=the maxdis between js and i, je and i
				//the mindis of dis1 and dis2 is the dis between i and j

				float dis1= getdis_toj(grp->strokes[i].ptsrow,grp->strokes[i].ptscol,
					grp->strokes[i].pterow,grp->strokes[i].ptecol,
					grp->strokes[j].ptsrow,grp->strokes[j].ptscol,
					grp->strokes[j].pterow,grp->strokes[j].ptecol);

				float dis2= getdis_toj(grp->strokes[j].ptsrow,grp->strokes[j].ptscol,
					grp->strokes[j].pterow,grp->strokes[j].ptecol,
					grp->strokes[i].ptsrow,grp->strokes[i].ptscol,
					grp->strokes[i].pterow,grp->strokes[i].ptecol);
				float curmindis=dis1>dis2?dis2:dis1;


				if( !(curmindis<min_charwid/4 && curmindis<min_charhei/4) && curmindis<mindis)
					mindis=curmindis;

			}
		}

	}
	if(mindis>1000)
	{
		for(int i=0;i<grp->strokenum;i++)
		{

			for(int j=i+1;j<grp->strokenum;j++)
			{

				int mintop=grp->strokes[i].ptsrow;
				if(grp->strokes[i].pterow<mintop)
					mintop=grp->strokes[i].pterow;
				if(grp->strokes[j].pterow<mintop)
					mintop=grp->strokes[j].pterow;
				if(grp->strokes[j].ptsrow<mintop)
					mintop=grp->strokes[j].ptsrow;

				int maxbot=grp->strokes[i].ptsrow;
				if(grp->strokes[i].pterow>maxbot)
					maxbot=grp->strokes[i].pterow;
				if(grp->strokes[j].pterow>maxbot)
					maxbot=grp->strokes[j].pterow;
				if(grp->strokes[j].ptsrow>maxbot)
					maxbot=grp->strokes[j].ptsrow;

				int minleft=grp->strokes[i].ptscol;
				if(grp->strokes[i].ptecol<minleft)
					minleft=grp->strokes[i].ptecol;
				if(grp->strokes[j].ptecol<minleft)
					minleft=grp->strokes[j].ptecol;
				if(grp->strokes[j].ptscol<minleft)
					minleft=grp->strokes[j].ptscol;

				int maxright=grp->strokes[i].ptscol;
				if(grp->strokes[i].ptecol>maxright)
					maxright=grp->strokes[i].ptecol;
				if(grp->strokes[j].ptecol>maxright)
					maxright=grp->strokes[j].ptecol;
				if(grp->strokes[j].ptscol>maxright)
					maxright=grp->strokes[j].ptscol;

				int intedis=(abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)+abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow))-(maxbot-mintop);
				int intedis2=(abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)+abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol))-(maxright-minleft);
				if(
					((  intedis>intepro1*abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)
					||intedis>intepro1*abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow)
					)&&(!(abs(grp->strokes[i].ptsrow-grp->strokes[i].pterow)*1.0/abs(0.001+grp->strokes[i].ptscol-grp->strokes[i].ptecol)<0.5
					&&abs(grp->strokes[j].ptsrow-grp->strokes[j].pterow)*1.0/abs(0.001+grp->strokes[j].ptscol-grp->strokes[j].ptecol)<0.5))
					)
					||
					((  intedis2>intepro1*abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)
					||intedis2>intepro1*abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol)
					)&&(!(abs(grp->strokes[i].ptscol-grp->strokes[i].ptecol)*1.0/abs(0.001+grp->strokes[i].ptsrow-grp->strokes[i].pterow)<0.5
					&&abs(grp->strokes[j].ptscol-grp->strokes[j].ptecol)*1.0/abs(0.001+grp->strokes[j].ptsrow-grp->strokes[j].pterow)<0.5))
					)
					)


				{
					//dis1=the maxdis between is and j, ie and j     dis2=the maxdis between js and i, je and i
					//the mindis of dis1 and dis2 is the dis between i and j

					float dis1= getdis_toj(grp->strokes[i].ptsrow,grp->strokes[i].ptscol,
						grp->strokes[i].pterow,grp->strokes[i].ptecol,
						grp->strokes[j].ptsrow,grp->strokes[j].ptscol,
						grp->strokes[j].pterow,grp->strokes[j].ptecol);

					float dis2= getdis_toj(grp->strokes[j].ptsrow,grp->strokes[j].ptscol,
						grp->strokes[j].pterow,grp->strokes[j].ptecol,
						grp->strokes[i].ptsrow,grp->strokes[i].ptscol,
						grp->strokes[i].pterow,grp->strokes[i].ptecol);
					float curmindis=dis1>dis2?dis2:dis1;


					if( !(curmindis<min_charwid/8 && curmindis<min_charhei/8) && curmindis<mindis)
						mindis=curmindis;

				}
			}

		}
	}
	return mindis;
}
float getdis_toj(int isr,int isc,int ier,int iec,int jsr,int jsc,int jer,int jec)
{
	if(jsc==jec)
	{
		float dis1=abs(isc-jsc);
		float dis2=abs(iec-jsc);
		return dis1>dis2?dis1:dis2;
	}
	else
	{
		float kj=(jsr-jer)*1.0/(jsc-jec);
		float b=jsr-kj*jsc;

		float dis1=abs(kj*isc-isr+b)*1.0/sqrt(kj*kj+1);
		float dis2=abs(kj*iec-ier+b)*1.0/sqrt(kj*kj+1);
		return dis1>dis2?dis1:dis2;
	}

}
float get_stkpro_incurve(Group *grp,int dcind)
{
	if(dcind==0)
	{	
		float sumlen=0;
		float sumlen1=0;
		for(int i=1;i<grp->draw_curves[dcind].pnum;i++)
		{
			sumlen+=sqrt(1.0*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])+
				(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1])*(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1]));
			if(i<3)
				sumlen1+=sqrt(1.0*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])+
				(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1])*(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1]));

		}
		return sumlen1/sumlen;
	}
	else if(dcind==grp->curvenum-1)
	{
		float sumlen=0;
		float sumlen1=0;
		for(int i=1;i<grp->draw_curves[dcind].pnum;i++)
		{
			sumlen+=sqrt(1.0*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])+
				(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1])*(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1]));
			if(i>grp->draw_curves[dcind].pnum-3)
				sumlen1+=sqrt(1.0*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])*(grp->draw_curves[dcind].x[i]-grp->draw_curves[dcind].x[i-1])+
				(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1])*(grp->draw_curves[dcind].y[i]-grp->draw_curves[dcind].y[i-1]));

		}
		return sumlen1/sumlen;
	}

}
void drawCurveOnImg_Bezier_eng(Group *grp,int onegroupwid,int onegrouphei)
{
	float stk_rdmax=1.25;//1+rand()*0.25/RAND_MAX;
	float stk_rdmin=0.75;//+rand()*0.25/RAND_MAX;
	int dcind=0;
	int iNumber=3;
	double u,x,y;
	int minwid=0;
	int maxhei=0;
	int glograyval=grayval;//(1-rand()*2.0/RAND_MAX);
	int pregrayval=glograyval;
	minwid=getGrpWid(grp,maxhei);


	//int sw=(minwid+maxhei)*1.0/(grp->strokenum)*strokewidpro*realGuassGenerate(0.,0,0,1)+strokewidpro_rd*realGuassGenerate(1,1,0,1)*gen_nmwid/64.0;//0513

	float mindisbtstks=get_minParalStkDis(grp,minwid,maxhei);//onegroupwid,onegrouphei);
	//int sw=mindisbtstks*0.5*realGuassGenerate(1,1,0,1)+5*realGuassGenerate(1,1,0,1)*gen_nmwid_cen/gen_nmwid;//*gen_nmwid/64.0;//0513
	int sw=5*realGuassGenerate(1,1,0,1)*gen_nmwid_cen/gen_nmwid;//*gen_nmwid/64.0;//0513

	int cur_maxwid=onegroupwid>onegrouphei?onegroupwid:onegrouphei;
	int curminsw=2;
	int curmaxsw=15;
	if(sw>curmaxsw)
		sw=	curmaxsw*realGuassGenerate(1,1,0,1);
	if(sw<curminsw)
		sw=curminsw;//17*realGuassGenerate(1,1,0,1);	

	//int sw=11*realGuassGenerate(1,1,0,1)*gen_nmwid/64.0;

	glo_cur_used_sw=sw/2;

	int prestrokewid=sw;
	int gray_like_lorh=rand()%10>=5;
	int sw_like_cuorxi=rand()%10>=5;
	while(dcind<grp->curvenum)
	{
		double len=get_curlen(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y);
		double ustep=sqrt(1.0*grp->draw_curves[dcind].pnum)* 0.01*sw/len;
		prestrokewid=sw;
		if(dcind==0 && grp->curvenum==1)
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);

			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;

			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);

			lastrdvvvv=(1-lastrdvvvv);
			//lastrdvvvv=(lastrdvvvv-0.0001+rand()*(1-lastrdvvvv)/RAND_MAX);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;

			for(u=0;u<=1;u=u+ustep)
			{

				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);		

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;



				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;


						sw_like_cuorxi=rand()%10>=5;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;

						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;


				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}
		}
		else if(dcind==0)
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);

			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;

			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);

			lastrdvvvv=(1-lastrdvvvv);
			//lastrdvvvv=(lastrdvvvv-0.0001+rand()*(1-lastrdvvvv)/RAND_MAX);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;
			lastrdvvvv=1;
			for(u=0;u<=1;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);



				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;



				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;
						sw_like_cuorxi=rand()%10>=5;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;

						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;


				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}
		}
		else if(dcind==grp->curvenum-1)
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);

			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;

			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);

			lastrdvvvv=(1-lastrdvvvv);
			//lastrdvvvv=(lastrdvvvv-0.0001+rand()*(1-lastrdvvvv)/RAND_MAX);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;
			firstrdvvvv=0;
			for(u=0;u<=1;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);



				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;



				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;
						sw_like_cuorxi=rand()%10>=2;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;

						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;


				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}
		}

		else if(rand()%2<1)///
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);

			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;

			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);

			lastrdvvvv=(1-lastrdvvvv);
			//lastrdvvvv=(lastrdvvvv-0.0001+rand()*(1-lastrdvvvv)/RAND_MAX);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;

			for(u=0;u<=1;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);



				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;



				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;
						sw_like_cuorxi=rand()%10>=2;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;

						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;


				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}



		}
		else
		{
			float umax=0;
			if(!grp->draw_curves[dcind].isCon)
			{
				umax=1;
			}
			else
			{
				umax=rand()*1.0/RAND_MAX;
			}
			for(u=0;u<=umax;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;
				int cursw=0;

				if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid+1;
					sw_like_cuorxi=rand()%10>=2;
				}
				else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid-1;

					sw_like_cuorxi=rand()%10>=5;
				}
				//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
				//cursw=5;
				if(cursw<curminsw)
					cursw=curminsw;

				prestrokewid=cursw;

				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;




				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}
			}
		}
		dcind++;
	}


}
void drawCurveOnImg_Bezier_eng(Group *grp,int onegroupwid,int onegrouphei,int width,int height)
{
	float stk_rdmax=1.25;//1+rand()*0.25/RAND_MAX;
	float stk_rdmin=0.75;//+rand()*0.25/RAND_MAX;
	int dcind=0;
	int iNumber=3;
	double u,x,y;
	int minwid=0;
	int maxhei=0;
	int glograyval=grayval;//(1-rand()*2.0/RAND_MAX);
	int pregrayval=glograyval;
	minwid=getGrpWid(grp,maxhei);


	//int sw=(minwid+maxhei)*1.0/(grp->strokenum)*strokewidpro*realGuassGenerate(0.,0,0,1)+strokewidpro_rd*realGuassGenerate(1,1,0,1)*gen_nmwid/64.0;//0513

	float mindisbtstks=get_minParalStkDis(grp,minwid,maxhei);//onegroupwid,onegrouphei);
	int sw=2+4*realGuassGenerate(1,1,0,1);//*gen_nmwid/64.0;//0513

	int cur_maxwid=onegroupwid>onegrouphei?onegroupwid:onegrouphei;
	int curminsw=2;
	int curmaxsw=15;
	if(sw>curmaxsw)
		sw=	curmaxsw*realGuassGenerate(1,1,0,1);
	if(sw<curminsw)
		sw=curminsw;//17*realGuassGenerate(1,1,0,1);	

	//int sw=11*realGuassGenerate(1,1,0,1)*gen_nmwid/64.0;

	glo_cur_used_sw=sw/2;

	int prestrokewid=sw;
	int gray_like_lorh=rand()%10>=5;
	int sw_like_cuorxi=rand()%10>=5;
	while(dcind<grp->curvenum)
	{
		double len=get_curlen(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y);
		double ustep=sqrt(1.0*grp->draw_curves[dcind].pnum)* 0.01*sw/len;
		prestrokewid=sw;
		if(rand()%2==0)
		{
			float firststkpro=get_stkpro_incurve(grp,dcind);
			float firstrdvvvv=0.5*firststkpro*(rand()*1.0/RAND_MAX);

			if(firstrdvvvv>0.2)
				firstrdvvvv=0.2;

			float lastkpro=get_stkpro_incurve(grp,dcind);
			float lastrdvvvv=0.5*lastkpro*(rand()*1.0/RAND_MAX);

			lastrdvvvv=(1-lastrdvvvv);
			//lastrdvvvv=(lastrdvvvv-0.0001+rand()*(1-lastrdvvvv)/RAND_MAX);
			if(lastrdvvvv<0.8)
				lastrdvvvv=0.8;

			for(u=0;u<=1;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);



				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;



				int cursw=sw;
				if(u<firstrdvvvv)
				{	
					cursw=u*sw/firstrdvvvv;

					if(cursw<curminsw)
						cursw=curminsw;
					prestrokewid=sw;
				}
				else if(u>lastrdvvvv)
				{
					cursw=prestrokewid+(u-lastrdvvvv)*(1.0-prestrokewid)/(1-lastrdvvvv);
					if(cursw<curminsw)
						cursw=curminsw;
					//prestrokewid=cursw;
				}
				else
				{

					if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid+1;
						sw_like_cuorxi=rand()%10>=2;
					}
					else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
					{
						if(rand()%10>=2)
							cursw=prestrokewid;
						else
							cursw=prestrokewid-1;

						sw_like_cuorxi=rand()%10>=5;
					}
					//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
					//cursw=5;
					if(cursw<curminsw)
						cursw=curminsw;

					prestrokewid=cursw;
				}



				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;


				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}



			}



		}
		else
		{
			float umax=0;
			if(!grp->draw_curves[dcind].isCon)
			{
				umax=1;
			}
			else
			{
				umax=rand()*1.0/RAND_MAX;
			}
			for(u=0;u<=umax;u=u+ustep)
			{


				x=0;y=0;
				sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=glograyval;

				int si,ei,sj,ej;
				int cursw=0;

				if((prestrokewid<=stk_rdmax*sw&&sw_like_cuorxi)||prestrokewid<=stk_rdmin*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid+1;
					sw_like_cuorxi=rand()%10>=2;
				}
				else if((prestrokewid>=stk_rdmin*sw&&(!sw_like_cuorxi))||prestrokewid>=stk_rdmax*sw)
				{
					if(rand()%10>=2)
						cursw=prestrokewid;
					else
						cursw=prestrokewid-1;

					sw_like_cuorxi=rand()%10>=5;
				}
				//cursw=(prestrokewid*0.5+0.5*(sw*realGuassGenerate(1,1,0.25,2)));
				//cursw=5;
				if(cursw<curminsw)
					cursw=curminsw;

				prestrokewid=cursw;

				si=cr-cursw/2>=0?cr-cursw/2:0;
				ei=si+cursw-1;	
				sj=cc-cursw/2>=0?cc-cursw/2:0;
				ej=sj+cursw-1;
				if(ei>=height)
				{	ei=height-1;si=ei-cursw+1;}
				if(ej>=width)
				{	ej=width-1;sj=ej-cursw+1;}

				float mi=(si+ei)/2.0;
				float mj=(sj+ej)/2.0;
				float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
				glo_graydec=0;//curgrayval/rds;




				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						int curgrayval_in=curgrayval;
						float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
						if(cdis>rds)
							curgrayval_in=0;
						//	curgrayval_in=curgrayval-glo_graydec*cdis;
						if(curgrayval_in<0)curgrayval_in=0;
						if(curgrayval_in>0)curgrayval_in=255;

						glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
					}
				}
			}
		}
		dcind++;
	}


}
/*
void drawCurveOnImg_Bezier(Group *grp,int onegroupwid,int onegrouphei,int width,int height)
{
int dcind=0;
int iNumber=3;
double u,x,y;
int minwid=0;
int glograyval=grayval+grayval_raodong*realGuassGenerate(0,1.0/3,-1,1);//(1-rand()*2.0/RAND_MAX);
int pregrayval=glograyval;
if(grp->strokenum<2)
minwid=(onegroupwid+onegrouphei)/2;
else
minwid=(onegroupwid<onegrouphei)?onegroupwid:onegrouphei;
minwid=(onegroupwid+onegrouphei)/2;
int maxwid=(onegroupwid>onegrouphei)?onegroupwid:onegrouphei;

int sw=minwid*strokewidpro+maxwid*strokewidpro_rd*realGuassGenerate(0,1.0/3,-1,1);

if(sw<3)
sw=3;
int raodong=0.1*sw;
if(raodong<1)
raodong=1;
int prestrokewid=sw;
int gray_like_lorh=rand()%10>=5;
int sw_like_cuorxi=rand()%10>=5;

while(dcind<grp->curvenum)
{
if(!grp->draw_curves[dcind].isCon)
{
for(u=0;u<=1;u=u+0.001)
{
x=0;y=0;
sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

int cr=(int)x;
int cc=(int)y;
if(cr<0)
cr=0;
if(cc<0)
cc=0;
if(cr>height-1)
cr=height-1;
if(cc>width-1)
cc=width-1;

int curgrayval=0;
if((pregrayval<1.25*glograyval&&gray_like_lorh)||pregrayval<0.8*glograyval)
{
if(rand()%10>=2)
curgrayval=pregrayval;
else
curgrayval=pregrayval+1;

gray_like_lorh=rand()%10>=2;
}
else if((pregrayval>0.8*glograyval&&(!gray_like_lorh))||pregrayval>1.25*glograyval)
{
if(rand()%10>=2)
curgrayval=pregrayval;
else
curgrayval=pregrayval-1;

gray_like_lorh=rand()%10>=8;
}

if(curgrayval<50)
curgrayval=50;
if(curgrayval>255)
curgrayval=255;
pregrayval=curgrayval;


int si,ei,sj,ej;
int cursw=0;
if((prestrokewid<1.25*sw&&sw_like_cuorxi)||prestrokewid<0.8*sw)
{
if(rand()%10>=2)
cursw=prestrokewid;
else
cursw=prestrokewid+1;
sw_like_cuorxi=rand()%10>=2;
}
else if((prestrokewid>0.8*sw&&(!sw_like_cuorxi))||prestrokewid>1.25*sw)
{
if(rand()%10>=2)
cursw=prestrokewid;
else
cursw=prestrokewid-1;

sw_like_cuorxi=rand()%10>=5;
}

if(cursw<glo_minsw)
cursw=glo_minsw;

prestrokewid=cursw;

si=cr-cursw/2>=0?cr-cursw/2:0;
ei=si+cursw-1;	
sj=cc-cursw/2>=0?cc-cursw/2:0;
ej=sj+cursw-1;
if(ei>=height)
{	ei=height-1;si=ei-cursw+1;}
if(ej>=width)
{	ej=width-1;sj=ej-cursw+1;}

float mi=(si+ei)/2.0;
float mj=(sj+ej)/2.0;
//float rds=((mi-si)+(mj-sj))/2;
float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
glo_graydec=curgrayval/rds;
for(int li=si;li<=ei;li++)
{
for(int lj=sj;lj<=ej;lj++)
{
int curgrayval_in;
float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
curgrayval_in=curgrayval-glo_graydec*cdis;
if(curgrayval_in<0)curgrayval_in=0;
if(curgrayval_in>255)curgrayval_in=255;
glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
}
}
}
}
else
{


double umax=realGuassGenerate(0.75,0.5/3,0.0,1);

//	usml=1;ubig=2;
for(u=0;u<=1;u=u+0.001)
{
x=0;y=0;
sol3(grp->draw_curves[dcind].pnum,grp->draw_curves[dcind].x,grp->draw_curves[dcind].y,u,x,y);

int cr=(int)x;
int cc=(int)y;
if(cr<0)
cr=0;
if(cc<0)
cc=0;
if(cr>height-1)
cr=height-1;
if(cc>width-1)
cc=width-1;

int curgrayval=0;
if((pregrayval<1.25*glograyval&&gray_like_lorh)||pregrayval<0.8*glograyval)
{
if(rand()%10>=2)
curgrayval=pregrayval;
else
curgrayval=pregrayval+1;

gray_like_lorh=rand()%10>=2;
}
else if((pregrayval>0.8*glograyval&&(!gray_like_lorh))||pregrayval>1.25*glograyval)
{
if(rand()%10>=2)
curgrayval=pregrayval;
else
curgrayval=pregrayval-1;

gray_like_lorh=rand()%10>=8;
}

if(curgrayval<50)
curgrayval=50;
if(curgrayval>255)
curgrayval=255;
pregrayval=curgrayval;


int si,ei,sj,ej;
int cursw=0;
if((prestrokewid<1.25*sw&&sw_like_cuorxi)||prestrokewid<0.8*sw)
{
if(rand()%10>=2)
cursw=prestrokewid;
else
cursw=prestrokewid+1;
sw_like_cuorxi=rand()%10>=2;
}
else if((prestrokewid>0.8*sw&&(!sw_like_cuorxi))||prestrokewid>1.25*sw)
{
if(rand()%10>=2)
cursw=prestrokewid;
else
cursw=prestrokewid-1;

sw_like_cuorxi=rand()%10>=5;
}

if(cursw<glo_minsw)
cursw=glo_minsw;

prestrokewid=cursw;

si=cr-cursw/2>=0?cr-cursw/2:0;
ei=si+cursw-1;	
sj=cc-cursw/2>=0?cc-cursw/2:0;
ej=sj+cursw-1;
if(ei>=height)
{	ei=height-1;si=ei-cursw+1;}
if(ej>=width)
{	ej=width-1;sj=ej-cursw+1;}

float mi=(si+ei)/2.0;
float mj=(sj+ej)/2.0;
//float rds=((mi-si)+(mj-sj))/2;
float rds=sqrt(1.0*(si-mi)*(si-mi)+(sj-mj)*(sj-mj));
glo_graydec=curgrayval/rds;
for(int li=si;li<=ei;li++)
{
for(int lj=sj;lj<=ej;lj++)
{
int curgrayval_in;
float cdis=sqrt(1.0*(li-mi)*(li-mi)+(lj-mj)*(lj-mj));
curgrayval_in=curgrayval-glo_graydec*cdis;
if(curgrayval_in<0)curgrayval_in=0;
if(curgrayval_in>255)curgrayval_in=255;
glo_img[li*width+lj]=curgrayval_in>glo_img[li*width+lj]?curgrayval_in:glo_img[li*width+lj];//curgrayval;//
}
}
}


}


dcind++;
}


}*/


void drawCurveOnImg(Group *grp,int onegroupwid,int onegrouphei)
{
	int dcind=0;
	int iNumber=3;
	double u,x,y;

	int sw=strokewid+strokewid*(rand()*1.0/RAND_MAX);
	int raodong=strokewid/2;
	while(dcind<grp->curvenum)
	{
		if(!grp->draw_curves[dcind].isCon)
		{
			for(u=0;u<=1;u=u+0.005)
			{
				x=0;y=0;
				for(int pind=0;pind<grp->draw_curves[dcind].pnum;pind++)
				{
					x+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].x[pind];
					y+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].y[pind];
				}
				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;
				int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
				glo_img[cr*width+cc]=curgrayval;
				int si,ei,sj,ej;

				int cursw=sw+raodong*(1-rand()*2.0/RAND_MAX);
				if(cr<height/2)
				{
					si=cr-cursw/2>=0?cr-cursw/2:0;
					ei=si+cursw;
				}
				else
				{
					ei=cr+cursw/2<height?cr+cursw/2:height-cursw;
					si=ei-cursw;
				}
				if(cc<width/2)
				{
					sj=cc-cursw/2>=0?cc-cursw/2:0;
					ej=sj+cursw;
				}
				else
				{
					ej=cc+cursw/2<width?cc+cursw/2:width-cursw;
					sj=ej-cursw;
				}
				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						//	int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
						glo_img[li*width+lj]=curgrayval;
					}
				}
			}
		}
		else if(grp->draw_curves[dcind].isCon==2)
		{

			double dishei=0.5*(abs(grp->draw_curves[dcind].x[0]-grp->draw_curves[dcind].x[1])+abs(grp->draw_curves[dcind].x[2]-grp->draw_curves[dcind].x[1]))*1.0/onegrouphei;
			double diswid=0.5*(abs(grp->draw_curves[dcind].y[0]-grp->draw_curves[dcind].y[1])+abs(grp->draw_curves[dcind].y[2]-grp->draw_curves[dcind].y[1]))*1.0/onegroupwid;

			double bigwei=dishei>diswid?dishei:diswid;
			double smlwei=1-bigwei;
			double usml=rand()*smlwei/RAND_MAX;
			double ubig=rand()*smlwei/RAND_MAX+bigwei;
			if(usml<0.1)
				usml=0.1;
			if(ubig>0.9)
				ubig=0.9;
			for(u=0;u<=usml;u=u+0.005)
			{
				x=0;y=0;
				for(int pind=0;pind<grp->draw_curves[dcind].pnum;pind++)
				{
					x+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].x[pind];
					y+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].y[pind];
				}

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;
				int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
				glo_img[cr*width+cc]=curgrayval;

				int cursw=sw;
				if(u<usml/3)
					cursw=sw*3/3+raodong*(1-rand()*2.0/RAND_MAX);
				else if(u<usml*2/3)
					cursw=sw*2/3+raodong*(1-rand()*2.0/RAND_MAX);
				else
					cursw=sw/3+raodong*(1-rand()*2.0/RAND_MAX);
				int si,ei,sj,ej;
				if(cr<height/2)
				{
					si=cr-cursw/2>=0?cr-cursw/2:0;
					ei=si+cursw;
				}
				else
				{
					ei=cr+cursw/2<height?cr+cursw/2:height-cursw;
					si=ei-cursw;
				}
				if(cc<width/2)
				{
					sj=cc-cursw/2>=0?cc-cursw/2:0;
					ej=sj+cursw;
				}
				else
				{
					ej=cc+cursw/2<width?cc+cursw/2:width-cursw;
					sj=ej-cursw;
				}

				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						//	int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
						glo_img[li*width+lj]=curgrayval;
					}
				}
			}
			/*	for(u=ubig;u<=1;u=u+0.005)
			{
			x=0;y=0;
			for(int pind=0;pind<grp->draw_curves[dcind].pnum;pind++)
			{
			x+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].x[pind];
			y+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].y[pind];
			}

			int cr=(int)x;
			int cc=(int)y;
			if(cr<0)
			cr=0;
			if(cc<0)
			cc=0;
			if(cr>height-1)
			cr=height-1;
			if(cc>width-1)
			cc=width-1;
			img[cr*width+cc]=255;

			int cursw=sw;
			if(u < ubig+(1-ubig)/3.0 )
			cursw=sw*1.0/3+raodong*(1-rand()*2.0/RAND_MAX);
			else if(u<ubig+(1-ubig)*2.0/3)
			cursw=sw*2/3+raodong*(1-rand()*2.0/RAND_MAX);
			else
			cursw=sw+raodong*(1-rand()*2.0/RAND_MAX);

			int si,ei,sj,ej;
			if(cr<height/2)
			{
			si=cr-cursw/2>=0?cr-cursw/2:0;
			ei=si+cursw;
			}
			else
			{
			ei=cr+cursw/2<height?cr+cursw/2:height-cursw;
			si=ei-cursw;
			}
			if(cc<width/2)
			{
			sj=cc-cursw/2>=0?cc-cursw/2:0;
			ej=sj+cursw;
			}
			else
			{
			ej=cc+cursw/2<width?cc+cursw/2:width-cursw;
			sj=ej-cursw;
			}
			for(int li=si;li<=ei;li++)
			{
			for(int lj=sj;lj<=ej;lj++)
			{
			img[li*width+lj]=255;
			}
			}
			}*/
		}
		else
		{
			for(u=0;u<=1;u=u+0.005)
			{
				x=0;y=0;
				for(int pind=0;pind<grp->draw_curves[dcind].pnum;pind++)
				{
					x+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].x[pind];
					y+=C(grp->draw_curves[dcind].pnum-1,pind)*N(u,pind)*N((1-u),(grp->draw_curves[dcind].pnum-1-pind))*grp->draw_curves[dcind].y[pind];
				}

				int cr=(int)x;
				int cc=(int)y;
				if(cr<0)
					cr=0;
				if(cc<0)
					cc=0;
				if(cr>height-1)
					cr=height-1;
				if(cc>width-1)
					cc=width-1;

				int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
				glo_img[cr*width+cc]=curgrayval;

				int cursw=sw;
				if(u>=0.5)
					cursw=1+(u-0.5)*(sw-1)*2;
				else
					cursw=sw+u*(1-sw)*2;

				int si,ei,sj,ej;
				if(cr<height/2)
				{
					si=cr-cursw/2>=0?cr-cursw/2:0;
					ei=si+cursw;
				}
				else
				{
					ei=cr+cursw/2<height?cr+cursw/2:height-cursw;
					si=ei-cursw;
				}
				if(cc<width/2)
				{
					sj=cc-cursw/2>=0?cc-cursw/2:0;
					ej=sj+cursw;
				}
				else
				{
					ej=cc+cursw/2<width?cc+cursw/2:width-cursw;
					sj=ej-cursw;
				}

				for(int li=si;li<=ei;li++)
				{
					for(int lj=sj;lj<=ej;lj++)
					{
						//	int curgrayval=grayval+grayval_raodong*(1-rand()*2.0/RAND_MAX);
						glo_img[li*width+lj]=curgrayval;
					}
				}
			}
		}
		dcind++;
	}


}
void test_realGuassGenerate()
{
	int cnt[10]={0};
	int i;
	for(i=0;i<10000;i++)
	{
		double rdv=realGuassGenerate(0.5,0.5/3,0,0.999);
		int idx=rdv*10;
		cnt[idx]++;
	}
	for( i=0;i<10;i++)
	{
		printf("%d ",cnt[i]);
	}
}
#define pi 3.14159

double rGuassGenerate(double mu, double theda,double min,double max)
{
	double t1,t2,a,r;
	double x;

	t1 = rand()*1.0/(RAND_MAX);
	t2 = rand()*1.0/(RAND_MAX);

	a = 2*pi*t1;            //a�Ǽ�����ĽǶȣ������0~2*pi�ľ��ȷֲ�
	r = sqrt(1.0*-2*log(t2));   //r�Ǽ�����ľ��룺�����Ȼ���������ŵ�һ�ֲַ�

	x = r*cos(a);
	double tttt=mu+theda*x;
	if(tttt<min ||tttt>max)
		return mu;
	else
		return tttt;
}


double realGuassGenerate(double mu, double theda,double min,double max)
{
	return min+rand()*(max-min)/RAND_MAX;/*
										 double t1,t2,a,r;
										 double x;

										 t1 = rand()*1.0/(RAND_MAX);
										 t2 = rand()*1.0/(RAND_MAX);

										 a = 2*pi*t1;            //a�Ǽ�����ĽǶȣ������0~2*pi�ľ��ȷֲ�
										 r = sqrt(1.0*-2*log(t2));   //r�Ǽ�����ľ��룺�����Ȼ���������ŵ�һ�ֲַ�

										 x = r*cos(a);
										 double tttt=mu+theda*x;
										 if(tttt<min ||tttt>max)
										 return mu;
										 else
										 return tttt;
										 //*/
}



//��n!
int JieCheng(int n)
{
	if(n==1||n==0)
	{
		return 1;
	}
	else
	{
		return n*JieCheng(n-1);
	}
}

//���������
double C(int n,int i)
{
	return ((double)JieCheng(n))/((double)(JieCheng(i)*JieCheng(n-i)));
}
//��һ����u��num�η�
double N(double u,int n)
{
	double sum=1.0;
	if (n==0)
	{
		return 1;
	}
	for(int i=0;i<n;i++)
	{
		sum*=u;
	}
	return sum;
}



void initgrp(Group *grp)
{
	grp->bot=0;
	grp->right=0;
	grp->left=100000;
	grp->top=100000;

	grp->top_ssidx=0;
	grp->left_ssidx=0;
	grp->right_ssidx=0;
	grp->bot_ssidx=0;

	grp->strokenum=0;
	grp->curvenum=0;

	grp->ptind_left_num=0;
	grp->ptind_right_num=0;
	grp->ptind_top_num=0;
	grp->ptind_bot_num=0;

}
///------------alg 3------------


bool GetCrossPoint(int aax,int aay,int bbx,int bby,int ccx,int ccy,int ddx,int ddy,int &x,int &y)
{

	//�󽻵�
	long tmpLeft,tmpRight;
	tmpLeft = (ddx - ccx) * (aay - bby) - (bbx - aax) * (ccy - ddy);
	tmpRight = (aay - ccy) * (bbx - aax) * (ddx - ccx) + ccx * (ddy - ccy) * (bbx - aax) - aax * (bby - aay) * (ddx - ccx);

	x = (int)((double)tmpRight/(double)tmpLeft);

	tmpLeft = (aax - bbx) * (ddy - ccy) - (bby - aay) * (ccx - ddx);
	tmpRight = bby * (aax - bbx) * (ddy - ccy) + (ddx- bbx) * (ddy - ccy) * (aay - bby) - ddy * (ccx - ddx) * (bby - aay); 
	y = (int)((double)tmpRight/(double)tmpLeft);

	return true;

}


double determinant(double v1, double v2, double v3, double v4)  // ����ʽ
{
	return (v1*v4-v2*v3);
}

bool intersect3(int aax,int aay,int bbx,int bby,int ccx,int ccy,int ddx,int ddy)
{
	double delta = determinant(bbx-aax, ccx-ddx, bby-aay, ccy-ddy);
	if ( delta<=(1e-6) && delta>=-(1e-6) )  // delta=0����ʾ���߶��غϻ�ƽ��
	{
		return false;
	}
	double namenda = determinant(ccx-aax, ccx-ddx, ccy-aay, ccy-ddy) / delta;
	if ( namenda>1 || namenda<0 )
	{
		return false;
	}
	double miu = determinant(bbx-aax, ccx-aax, bby-aay, ccy-aay) / delta;
	if ( miu>1 || miu<0 )
	{
		return false;
	}
	return true;
}
///------------alg 3------------