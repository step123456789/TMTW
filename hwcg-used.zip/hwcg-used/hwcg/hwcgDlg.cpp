
// hwcgDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "hwcg.h"
#include "hwcgDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ChwcgDlg �Ի���




ChwcgDlg::ChwcgDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(ChwcgDlg::IDD, pParent)
	, m_editChar(_T(""))
	, m_editPart(_T(""))
	, m_editString(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	width=555;
	height=555;
	left=375;
	top=60;
	m_has_det_part_pos=false;
	m_has_seld_part=0;
	m_cntPartPnt_Pre=0;
	m_cntPartPnt=0;
	m_curGrp_num=0;
	m_islbup=false;
	styleidx=1;
	is_start_show=false;
	strcpy(rootpath,"C:\\Users\\admin\\Desktop\\dsk\\hwcg\\hwcg-hanzi-engstr\\Release");
	eachsize=128;
	 rownum=4;
	showimg=new unsigned char[eachsize*rownum*eachsize*rownum];
	//hwcharimg=new unsigned char[64*8*64*8];
	bgimg_idx=0;
	m_editChar = _T("");
	m_slider_var_val=10;
	m_slider_con_val=10;
	 
}

void ChwcgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTN_HENG_LR, m_btn_heng_lr);
	//  DDX_Text(pDX, IDC_EDIT_CHAR, m_editChar);
	DDX_Text(pDX, IDC_EDIT_PART, m_editPart);
	DDX_Text(pDX, IDC_EDIT_STRING, m_editString);
	DDX_Control(pDX, IDC_BTN_HENGHF_LR, m_btn_henghf_lr);
	DDX_Control(pDX, IDC_BTN_HENGHF_RL, m_btn_henghf_rl);
	DDX_Control(pDX, IDC_BTN_HENG_RL, m_btn_heng_rl);
	DDX_Control(pDX, IDC_BTN_NA_BT, m_btn_na_bt);
	DDX_Control(pDX, IDC_BTN_NA_TB, m_btn_na_tb);
	DDX_Control(pDX, IDC_BTN_NAHF_BT, m_btn_nahf_bt);
	DDX_Control(pDX, IDC_BTN_NAHF_TB, m_btn_nahf_tb);
	DDX_Control(pDX, IDC_BTN_PIE_BT, m_btn_pie_bt);
	DDX_Control(pDX, IDC_BTN_PIE_TB, m_btn_pie_tb);
	DDX_Control(pDX, IDC_BTN_PIEHF_BT, m_btn_piehf_bt);
	DDX_Control(pDX, IDC_BTN_PIEHF_TB, m_btn_piehf_tb);
	DDX_Control(pDX, IDC_BTN_SHU_BT, m_btn_shu_bt);
	DDX_Control(pDX, IDC_BTN_SHU_TB, m_btn_shu_tb);
	//  DDX_Control(pDX, IDC_BTN_SHUHF_BT, m_btn_shuhf_tb);
	//  DDX_Control(pDX, IDC_BTN_SHUHF_TB, m_btn_shuhf_bt);
	DDX_Control(pDX, IDC_BTN_SHUHF_BT, m_btn_shuhf_bt);
	DDX_Control(pDX, IDC_BTN_SHUHF_TB, m_btn_shuhf_tb);
	DDX_Text(pDX, IDC_EDIT_CHAR, m_editChar);
	DDX_Control(pDX, IDC_SLIDER_CON, m_sliderCon);
	DDX_Control(pDX, IDC_SLIDER_VAR, m_sliderVar);
}

BEGIN_MESSAGE_MAP(ChwcgDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_OK, &ChwcgDlg::OnBnClickedBtnOk)
	ON_BN_CLICKED(IDC_BTN_HENGHF_LR, &ChwcgDlg::OnBnClickedBtnHenghfLr)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_BN_CLICKED(IDC_BTN_SELPART, &ChwcgDlg::OnBnClickedBtnSelpart)
	ON_BN_CLICKED(IDC_BUTTON_FIX, &ChwcgDlg::OnBnClickedButtonFix)
	ON_BN_CLICKED(IDC_BTN_STARTlEARNING, &ChwcgDlg::OnBnClickedBtnStartlearning)
	ON_BN_CLICKED(IDC_BTN_FINISHlEARNING, &ChwcgDlg::OnBnClickedBtnFinishlearning)
	ON_BN_CLICKED(IDC_BTN_WRITE, &ChwcgDlg::OnBnClickedBtnWrite)
	ON_BN_CLICKED(IDC_BTN_HENG_LR, &ChwcgDlg::OnBnClickedBtnHengLr)
	ON_BN_CLICKED(IDC_BTN_HENGHF_RL, &ChwcgDlg::OnBnClickedBtnHenghfRl)
	ON_BN_CLICKED(IDC_BTN_HENG_RL, &ChwcgDlg::OnBnClickedBtnHengRl)
	ON_BN_CLICKED(IDC_BTN_SHUHF_TB, &ChwcgDlg::OnBnClickedBtnShuhfTb)
	ON_BN_CLICKED(IDC_BTN_SHU_TB, &ChwcgDlg::OnBnClickedBtnShuTb)
	ON_BN_CLICKED(IDC_BTN_SHUHF_BT, &ChwcgDlg::OnBnClickedBtnShuhfBt)
	ON_BN_CLICKED(IDC_BTN_SHU_BT, &ChwcgDlg::OnBnClickedBtnShuBt)
	ON_BN_CLICKED(IDC_BTN_PIEHF_TB, &ChwcgDlg::OnBnClickedBtnPiehfTb)
	ON_BN_CLICKED(IDC_BTN_PIE_TB, &ChwcgDlg::OnBnClickedBtnPieTb)
	ON_BN_CLICKED(IDC_BTN_PIEHF_BT, &ChwcgDlg::OnBnClickedBtnPiehfBt)
	ON_BN_CLICKED(IDC_BTN_PIE_BT, &ChwcgDlg::OnBnClickedBtnPieBt)
	ON_BN_CLICKED(IDC_BTN_NAHF_TB, &ChwcgDlg::OnBnClickedBtnNahfTb)
	ON_BN_CLICKED(IDC_BTN_NA_TB, &ChwcgDlg::OnBnClickedBtnNaTb)
	ON_BN_CLICKED(IDC_BTN_NAHF_BT, &ChwcgDlg::OnBnClickedBtnNahfBt)
	ON_BN_CLICKED(IDC_BTN_NA_BT, &ChwcgDlg::OnBnClickedBtnNaBt)
	ON_BN_CLICKED(IDC_BTN_BATCHWRITE, &ChwcgDlg::OnBnClickedBtnBatchwrite)
	ON_BN_CLICKED(IDC_BTN_WRITESTRING, &ChwcgDlg::OnBnClickedBtnWritestring)
//	ON_EN_CHANGE(IDC_EDIT_STRING, &ChwcgDlg::OnEnChangeEditString)
//ON_WM_SIZE()
ON_BN_CLICKED(IDC_BTN_WRITE_ENG, &ChwcgDlg::OnBnClickedBtnWriteEng)
ON_WM_HSCROLL()
ON_EN_SETFOCUS(IDC_EDIT_CHAR, &ChwcgDlg::OnSetfocusEditChar)
ON_EN_SETFOCUS(IDC_EDIT_PART, &ChwcgDlg::OnSetfocusEditPart)
ON_EN_SETFOCUS(IDC_EDIT_STRING, &ChwcgDlg::OnSetfocusEditString)
//ON_BN_CLICKED(IDC_BTN_OK2, &ChwcgDlg::OnBnClickedBtnOk2)
ON_BN_CLICKED(IDC_BTN_BATCHWRITE2, &ChwcgDlg::OnBnClickedBtnBatchwrite2)
//ON_BN_CLICKED(IDC_BTN_WRITEERRORSTR, &ChwcgDlg::OnBnClickedBtnWriteerrorstr)
ON_BN_CLICKED(IDC_BTN_WRITECHISTR, &ChwcgDlg::OnBnClickedBtnWritechistr)
ON_BN_CLICKED(IDC_BUTTON2, &ChwcgDlg::OnBnClickedButton2)
ON_BN_CLICKED(IDC_BUTTON3, &ChwcgDlg::OnBnClickedButton3)
ON_BN_CLICKED(IDC_BTN_BATCHWRITESTR, &ChwcgDlg::OnBnClickedBtnBatchwritestr)
END_MESSAGE_MAP()


// ChwcgDlg ��Ϣ��������

BOOL ChwcgDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	m_sliderCon.SetRange(0,20);//���û�����Χ
	m_sliderCon.SetTicFreq(1);//ÿ10����λ��һ�̶�

	m_sliderVar.SetRange(0,20);//���û�����Χ
	m_sliderVar.SetTicFreq(1);//ÿ10����λ��һ�̶�

	m_sliderCon.SetPos(10);
	m_sliderVar.SetPos(10);

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	m_editChar="Character to learn or write";
	m_editPart="Part used to learn";
	m_editString="String to write";
	UpdateData(0);
	/*
	CEdit*  pEdit=(CEdit*)GetDlgItem(IDC_EDIT_CHAR);//��ȡ��Ӧ�ı༭��ID
	pEdit->SetWindowText(_T("Character to learn or write")); //����Ĭ����ʾ������

	pEdit=(CEdit*)GetDlgItem(IDC_EDIT_PART);//��ȡ��Ӧ�ı༭��ID
	pEdit->SetWindowText(_T("Input the part used to learn")); //����Ĭ����ʾ������

	pEdit=(CEdit*)GetDlgItem(IDC_EDIT_STRING);//��ȡ��Ӧ�ı༭��ID
	pEdit->SetWindowText(_T("Input the string to write")); //����Ĭ����ʾ������*/



	int icw=48;
	HICON hicon; 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_HENG_LR),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_heng_lr.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_HENG_RL),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_heng_rl.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_HENGHF_RL),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_henghf_rl.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_HENGHF_LR),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_henghf_lr.SetIcon(hicon);

	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_SHU_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_shu_tb.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_SHU_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_shu_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_SHUHF_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_shuhf_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_SHUHF_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_shuhf_tb.SetIcon(hicon);

	
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_PIE_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_pie_tb.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_PIE_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_pie_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_PIEHF_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_piehf_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_PIEHF_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_piehf_tb.SetIcon(hicon);

	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_NA_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_na_tb.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_NA_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_na_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_NAHF_BT),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_nahf_bt.SetIcon(hicon); 
	hicon = (HICON)LoadImage(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDI_ICON_NAHF_TB),IMAGE_ICON,icw,icw,LR_DEFAULTCOLOR|LR_CREATEDIBSECTION);
	m_btn_nahf_tb.SetIcon(hicon);


	AdjustWindowsSize();  
	Resize();  

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void ChwcgDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		AdjustWindowsSize();  
	    Resize();  
		CPaintDC dc(this);
		HDC mdc,bufdc;
		mdc=CreateCompatibleDC(dc);
		bufdc=CreateCompatibleDC(dc);
		HBITMAP bmp;
		HBITMAP m_curHBitmap;
		bmp=CreateCompatibleBitmap(dc,width,height);
		SelectObject(mdc,bmp);
		CString bgimgname;
		bgimgname.Format(L"C:\\Users\\admin\\Desktop\\dsk\\hwcg\\hwcg-hanzi-engstr\\hwcg\\res\\bg.bmp",bgimg_idx);
		m_curHBitmap=(HBITMAP)LoadImage(NULL,bgimgname,IMAGE_BITMAP,
			width,height,LR_LOADFROMFILE);
		
		SelectObject(bufdc,m_curHBitmap);
		BitBlt(mdc,0,0,width,height,bufdc,0,0,SRCCOPY);
		StretchBlt(dc,left,top,width,height,mdc,0,0,width,height,SRCCOPY);
		DeleteObject(bmp);
		DeleteObject(m_curHBitmap);
		::ReleaseDC(this->m_hWnd,mdc);
		::ReleaseDC(this->m_hWnd,bufdc);

		if(is_start_show)
		{
			int  CX=eachsize*rownum, CY=eachsize*rownum; // ���ֵ�����֪�������ȸ���
			int sz = CX * CY;
			BYTE *pData = new BYTE[sz*4];        // show in 32 bits
     
			for(int i=0; i< sz; i++)
			{
				pData[i*4+0] = showimg[i] ;
				pData[i*4+1] = showimg[i];
				pData[i*4+2] = showimg[i];
				pData[i*4+3] = 0;
			}
     
			CDC *pdc = GetDC(); 
			CDC memdc; 
			CBitmap bmp;
			CRect rt;
     
			memdc.CreateCompatibleDC(pdc);
			bmp.CreateBitmap(CX, CY , 1, 32,pData);
			CBitmap* pOldBitmap = memdc.SelectObject(&bmp); 
     
			pdc->BitBlt(left,top, CX, CY, &memdc, 0, 0, SRCCOPY); 
     
			memdc.SelectObject(pOldBitmap);
			memdc.DeleteDC();
				ReleaseDC(pdc);


		}
		if(m_has_seld_part && m_islbup)
		{
			int   penWidth   =   7; 
			CPen pen(PS_SOLID,   penWidth,   RGB(255,   0,   0)); 
			CPen *oldpen=(CPen*)dc.SelectObject(pen); 
			int i;
			/*for( i=0;i<m_cntPartPnt;i+=2)
			{
				dc.MoveTo(left+(m_partpnt[i].x-left)-3,top+(m_partpnt[i].y-top));
				dc.LineTo(left+(m_partpnt[i].x-left)+3,top+(m_partpnt[i].y-top));
			}*/
			dc.SelectObject(&oldpen);
			DeleteObject(pen);

			CPen pen2(PS_SOLID,   penWidth,   RGB(0,   0,   255)); 
			CPen *oldpen2=(CPen*)dc.SelectObject(pen2); 

			/*for( i=1;i<m_cntPartPnt;i+=2)
			{
				dc.MoveTo(left+(m_partpnt[i].x-left),top+(m_partpnt[i].y-top)-3);
				dc.LineTo(left+(m_partpnt[i].x-left),top+(m_partpnt[i].y-top)+3);
			}*/
			dc.SelectObject(&oldpen2);
			DeleteObject(pen2);	

			CPen pen3(PS_SOLID,   penWidth,   RGB(0,   0,   0)); 
			CPen *oldpen3=(CPen*)dc.SelectObject(pen3); 

			for( i=0;i<m_cntPartPnt;i+=2)
			{
				dc.MoveTo(left+(m_partpnt[i].x-left),top+(m_partpnt[i].y-top));
				dc.LineTo(left+(m_partpnt[i+1].x-left),top+(m_partpnt[i+1].y-top));
			}
			dc.SelectObject(&oldpen3);
			DeleteObject(pen3);	
		}
		

		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR ChwcgDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void ChwcgDlg::OnBnClickedBtnOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	delete []showimg;
	CDialog::OnOK(); 
	DestroyWindow();
}


void ChwcgDlg::OnBnClickedBtnHenghfLr()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_editPart="heng_lr_hf";
	sprintf(m_curpart,"%s","heng_lr_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);

}


void ChwcgDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if(m_has_seld_part & !m_has_det_part_pos)
	{
		down_point=point;
	}
	CDialogEx::OnLButtonDown(nFlags, point);
}


void ChwcgDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if(m_has_seld_part& !m_has_det_part_pos)
	{
		if(down_point.x<point.x)
		{
			m_grp[m_curGrp_num].left=down_point.x;
			m_grp[m_curGrp_num].right=point.x;
		}else
		{
			m_grp[m_curGrp_num].left=point.x;
			m_grp[m_curGrp_num].right=down_point.x;
		}

		if(down_point.y<point.y)
		{
			m_grp[m_curGrp_num].top=down_point.y;
			m_grp[m_curGrp_num].bot=point.y;
		}else
		{
			m_grp[m_curGrp_num].top=point.y;
			m_grp[m_curGrp_num].bot=down_point.y;
		}		

		if(strcmp(m_curpart,"heng_lr")==0 ||
			strcmp(m_curpart,"heng_rl")==0 ||
			strcmp(m_curpart,"heng_lr_hf")==0 ||
			strcmp(m_curpart,"heng_rl_hf")==0 )
		{
			m_grp[m_curGrp_num].top=down_point.y;
			m_grp[m_curGrp_num].bot=down_point.y;
		}
		if(strcmp(m_curpart,"shu_bt")==0 ||
			strcmp(m_curpart,"shu_tb")==0 ||
			strcmp(m_curpart,"shu_bt_hf")==0 ||
			strcmp(m_curpart,"shu_tb_hf")==0 )
		{
			m_grp[m_curGrp_num].left=down_point.x;
			m_grp[m_curGrp_num].right=down_point.x;
		}

		

		int rdptnum=ReadPartPts(m_curpart,m_cntPartPnt_Pre,&(m_grp[m_curGrp_num]));
		m_cntPartPnt=m_cntPartPnt_Pre+rdptnum;

		m_islbup=true;
		Invalidate();
	}

	CDialogEx::OnLButtonUp(nFlags, point);
}


void ChwcgDlg::OnBnClickedBtnSelpart()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(1); 
	if(m_editPart!="")
	{
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editPart,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editPart,-1,m_grp[m_curGrp_num].partname,nn,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editPart,-1,m_curpart,nn,0,NULL);

		
		char numfilename[1024]="";
		sprintf(numfilename,"%s\\learn_result\\%s_num.txt",rootpath,m_curpart);
		FILE *fpnum=fopen(numfilename,"r");
		if(fpnum!=NULL)
		{
			fclose(fpnum);
			m_has_seld_part=true;
			m_has_det_part_pos=false;
		}
		else
		{
			MessageBox(L"δ�ҵ��ò��׶�Ӧ�������ļ�������ѧϰ�ò��ס�");
		}
	}
}


void ChwcgDlg::OnBnClickedButtonFix()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if(m_has_seld_part)
	{
		//sprintf(m_grp[m_curGrp_num].partname,(char *)(m_editPart.GetBuffer(m_editPart.GetLength())));
		
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editPart,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editPart,-1,m_grp[m_curGrp_num].partname,nn,0,NULL);

		
		m_curGrp_num++;
		m_cntPartPnt_Pre=m_cntPartPnt;
		m_has_det_part_pos=true;
	}
}


void ChwcgDlg::OnBnClickedBtnStartlearning()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������	
	m_cntPartPnt_Pre=0;
	m_cntPartPnt=0;
	m_curGrp_num=0;
	m_has_seld_part=false;
	is_start_show=false;
	m_islbup=false;
	m_has_det_part_pos=false;
	UpdateData(TRUE); 
	if(m_editChar=="")
		MessageBox(L"���������ַ���");
	else
	{
		Invalidate();
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,m_curhanzi,nn,0,NULL);
	}
}


void ChwcgDlg::OnBnClickedBtnFinishlearning()
{
	// TODO: Add your control notification handler code here
	int i,j;
	m_has_seld_part=false;
	m_islbup=false;
	m_has_det_part_pos=false;

	int curnumber=1;
	char svnumfile[1024]="";
	sprintf(svnumfile,"%s\\learn_result\\%s_num.txt",rootpath,m_curhanzi);
	FILE *fpnum=fopen(svnumfile,"r");
	if(fpnum==NULL)
	{	}
	else
	{
		fscanf(fpnum,"%d",&(curnumber));
		fclose(fpnum);
	}

	sprintf(svnumfile,"%s\\learn_result\\%s_%d.txt",rootpath,m_curhanzi,curnumber);
	FILE *fpsv=fopen(svnumfile,"w");

	fprintf(fpsv,"%d %d\n",1,m_curGrp_num);

	for(i=0;i<m_curGrp_num;i++)
	{
		
		fprintf(fpsv,"%d %d %d %d %s\n",m_grp[i].left,m_grp[i].top,m_grp[i].right,m_grp[i].bot,m_grp[i].partname);
	}
	fclose(fpsv);

	sprintf(svnumfile,"%s\\learn_result\\%s_num.txt",rootpath,m_curhanzi);
	fpnum=fopen(svnumfile,"w");
	fprintf(fpnum,"%d",curnumber+1);
	fclose(fpnum);

	
}


int ChwcgDlg::ReadPartPts(char* m_editPart, int m_cntPartPnt_Pre, PART* tgtpart)
{
	int isusedpart;
	char numfilename[1024]="";
	sprintf(numfilename,"%s\\learn_result\\%s_1.txt",rootpath,m_editPart);
	FILE *fp=fopen(numfilename,"r");
	int partnum,type;
	fscanf(fp,"%d%d",&type,&(partnum));

	if(type==0)//only one stroke
	{	int strokenum=1;
		int i=0;
		fscanf(fp,"%d%d%d%d",
				&(m_partpnt[m_cntPartPnt_Pre+2*i].x),
				&(m_partpnt[m_cntPartPnt_Pre+2*i].y),
				&(m_partpnt[m_cntPartPnt_Pre+2*i+1].x),
				&(m_partpnt[m_cntPartPnt_Pre+2*i+1].y));	
		
		Scale_Shift_Part(m_partpnt,m_cntPartPnt_Pre,m_cntPartPnt_Pre+strokenum*2,tgtpart);	
		return strokenum*2;
	}
	else
	{
		PART tmppart;
		char curpartname[1000];
		int tmp_ptnum=m_cntPartPnt_Pre;
		for(int i=0;i<partnum;i++)
		{
			fscanf(fp,"%d%d%d%d%s",
				&(tmppart.left),
				&(tmppart.top),
				&(tmppart.right),
				&(tmppart.bot),	(curpartname));

			int curptnum=ReadPartPts(curpartname,tmp_ptnum,&tmppart);
			tmp_ptnum+=curptnum;
		}
		Scale_Shift_Part(m_partpnt,m_cntPartPnt_Pre,tmp_ptnum,tgtpart);	
		return tmp_ptnum-m_cntPartPnt_Pre;
	}
	return 0;
}


void ChwcgDlg::Scale_Shift_Part(CPoint * m_partpnt, int si, int ei, PART * curgrp)
{
	int curgrp_top=100000,curgrp_left=1000000,curgrp_bot=0,curgrp_right=0;
	for(int i=si;i<ei;i++)
	{
		if(m_partpnt[i].x<curgrp_left)curgrp_left=m_partpnt[i].x;
		if(m_partpnt[i].y<curgrp_top) curgrp_top=m_partpnt[i].y;
		if(m_partpnt[i].x>curgrp_right)curgrp_right=m_partpnt[i].x;
		if(m_partpnt[i].y>curgrp_bot) curgrp_bot=m_partpnt[i].y;
	}
	int oriwid=curgrp_right-curgrp_left;
	int orihei=curgrp_bot-curgrp_top;
	int tgtwid=curgrp->right-curgrp->left;
	int tgthei=curgrp->bot-curgrp->top;
	float prowid=tgtwid*1.0/oriwid;
	float prohei=tgthei*1.0/orihei;
	if(orihei<1)
		prohei=1;
	if(oriwid<1)
		prowid=1;
	//scale
	int i;
	for( i=si;i<ei;i++)
	{
		m_partpnt[i].x=(m_partpnt[i].x-curgrp_left)*prowid+curgrp_left;
		m_partpnt[i].y=(m_partpnt[i].y-curgrp_top) *prohei+curgrp_top;
	}
	//shift
	for( i=si;i<ei;i++)
	{
		m_partpnt[i].x=(m_partpnt[i].x+curgrp->left-curgrp_left);
		m_partpnt[i].y=(m_partpnt[i].y+curgrp->top-curgrp_top);
	}

}


void ChwcgDlg::OnBnClickedBtnWrite()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE); 
	if(m_editChar=="")
		MessageBox(L"���������ַ���");
	else
	{
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,m_curhanzi,nn,0,NULL);

		//sprintf(m_curhanzi,"%s",m_curChar.GetBuffer(m_curChar.GetLength()));
	}
	//srand(0);
	
	
	unsigned char *retimg=new unsigned char [eachsize*eachsize];
	memset(showimg,255,sizeof(unsigned char)*eachsize*rownum*eachsize*rownum);
	for(int i=0;i<rownum*rownum;i++)
	{
		bool issuc=writeHanzi(styleidx,i,m_curhanzi,rootpath,retimg,1,m_slider_var_val,m_slider_con_val);
		if(!issuc)
		{
			i--;continue;
		}
		int currow=i/rownum;
		int curcol=i%rownum;
		for(int r=currow*eachsize;r<currow*eachsize+eachsize;r++)
		{
			for(int c=curcol*eachsize;c<curcol*eachsize+eachsize;c++)
			{
				showimg[r*(eachsize*rownum)+c]=255-retimg[(r-currow*eachsize)*eachsize+c-curcol*eachsize];
			}
		}
	}
	delete []retimg;
	is_start_show=true;
	Invalidate();
}


void ChwcgDlg::OnBnClickedBtnHengLr()
{
	m_editPart="heng_lr";
	sprintf(m_curpart,"%s","heng_lr");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnHenghfRl()
{
	m_editPart="heng_rl_hf";
	sprintf(m_curpart,"%s","heng_rl_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnHengRl()
{
	m_editPart="heng_rl";
	sprintf(m_curpart,"%s","heng_rl");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnShuhfTb()
{
	m_editPart="shu_tb_hf";
	sprintf(m_curpart,"%s","shu_tb_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnShuTb()
{
	m_editPart="shu_tb";
	sprintf(m_curpart,"%s","shu_tb");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnShuhfBt()
{
	m_editPart="shu_bt_hf";
	sprintf(m_curpart,"%s","shu_bt_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnShuBt()
{
	m_editPart="shu_bt";
	sprintf(m_curpart,"%s","shu_bt");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnPiehfTb()
{
	m_editPart="pie_tb_hf";
	sprintf(m_curpart,"%s","pie_tb_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnPieTb()
{
	m_editPart="pie_tb";
	sprintf(m_curpart,"%s","pie_tb");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnPiehfBt()
{
	m_editPart="pie_bt_hf";
	sprintf(m_curpart,"%s","pie_bt_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnPieBt()
{
	m_editPart="pie_bt";
	sprintf(m_curpart,"%s","pie_bt");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnNahfTb()
{
	m_editPart="na_tb_hf";
	sprintf(m_curpart,"%s","na_tb_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnNaTb()
{
	m_editPart="na_tb";
	sprintf(m_curpart,"%s","na_tb");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnNahfBt()
{
	m_editPart="na_bt_hf";
	sprintf(m_curpart,"%s","na_bt_hf");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnNaBt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_editPart="na_bt";
	sprintf(m_curpart,"%s","na_bt");

	m_has_seld_part=true;
	m_has_det_part_pos=false;
	strcpy(m_grp[m_curGrp_num].partname,m_curpart);
}


void ChwcgDlg::OnBnClickedBtnBatchwrite()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	batch_write(0);
}


void ChwcgDlg::OnBnClickedBtnWritestring()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	memset(m_curstring,0,sizeof(char)*1024);
	UpdateData(TRUE); 
	if(m_editString=="")
		MessageBox(L"���������ַ���");
	else
	{
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editString,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editString,-1,m_curstring,nn,0,NULL);

		//sprintf(m_curhanzi,"%s",m_curChar.GetBuffer(m_curChar.GetLength()));
	}
	//srand(0);
	
	
	memset(showimg,255,sizeof(unsigned char)*eachsize*rownum*eachsize*rownum);
	for(int i=0;i<rownum;i++)
	{
		int retwid,rethei;
		//unsigned char *writeString_Eng(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val)
		unsigned char *retimg=writeString_Eng(m_curstring,retwid,rethei,rownum*2,m_slider_var_val,m_slider_con_val);

		for(int r=i*eachsize;r<i*eachsize+rethei;r++)
		{
			for(int c=0;c<retwid;c++)
			{
				showimg[r*(eachsize*rownum)+c]=255-retimg[(r-i*eachsize)*retwid+c];
			}
		}
		delete []retimg;
	}
	
	is_start_show=true;
	Invalidate();
}



void ChwcgDlg::AdjustWindowsSize(void)
{
	/*int cx = GetSystemMetrics(SM_CXFULLSCREEN);  
	int cy = GetSystemMetrics(SM_CYFULLSCREEN);  
	CRect rt;  
	SystemParametersInfo(SPI_GETWORKAREA,0,&rt,0);  //������湤������С�����������������Ĵ�С
	cy = rt.bottom;  
	MoveWindow(0, 0, cx,cy);

	CRect rect;    
	GetClientRect(&rect);     //ȡ�ͻ�����С    
	old.x=cx;  
	old.y=cy; 
	*/
}


void ChwcgDlg::Resize(void)
{
/*	float fsp[2];  
	POINT Newp; //��ȡ���ڶԻ���Ĵ�С  
	CRect recta;      
	GetClientRect(&recta);     //ȡ�ͻ�����С    
	Newp.x=recta.right-recta.left;  
	Newp.y=recta.bottom-recta.top;  
	fsp[0]=old.x*1.0/1366;  
	fsp[1]=old.y*1.0/728;   
	
	CRect Rect;  
	int woc;  
	CPoint OldTLPoint,TLPoint; //���Ͻ�  
	CPoint OldBRPoint,BRPoint; //���½�  
	HWND  hwndChild=::GetWindow(m_hWnd,GW_CHILD);  //�г����пؼ�   
	

	width=555*fsp[0];
	height=555*fsp[1];
	left=450*fsp[0];
	top=80*fsp[1];
	

	while(hwndChild)      
	{      
		woc=::GetDlgCtrlID(hwndChild);//ȡ��ID  
		GetDlgItem(woc)->GetWindowRect(Rect);    
		ScreenToClient(Rect);    
		OldTLPoint = Rect.TopLeft();    
		TLPoint.x = long(OldTLPoint.x*fsp[0]);    
		TLPoint.y = long(OldTLPoint.y*fsp[1]);    
		OldBRPoint = Rect.BottomRight();    
		BRPoint.x = long(OldBRPoint.x *fsp[0]);    
		BRPoint.y = long(OldBRPoint.y *fsp[1]); 
		Rect.SetRect(TLPoint,BRPoint);    
		GetDlgItem(woc)->MoveWindow(Rect,TRUE);  
		hwndChild=::GetWindow(hwndChild, GW_HWNDNEXT);      
	}  
	old=Newp;  */
	
}


//void ChwcgDlg::OnSize(UINT nType, int cx, int cy)
//{
//	/*CDialogEx::OnSize(nType, cx, cy);
//
//	// TODO: �ڴ˴�������Ϣ�����������
//	AdjustWindowsSize();
//	Resize();*/
//}


void ChwcgDlg::OnBnClickedBtnWriteEng()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
		UpdateData(TRUE); 
	if(m_editChar=="")
		MessageBox(L"���������ַ���");
	else
	{
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editChar,-1,m_curhanzi,nn,0,NULL);

		//sprintf(m_curhanzi,"%s",m_curChar.GetBuffer(m_curChar.GetLength()));
	}
	//srand(0);
	
	unsigned char *retimg=new unsigned char [eachsize*eachsize];
	memset(showimg,255,sizeof(unsigned char)*eachsize*rownum*eachsize*rownum);
	for(int i=0;i<rownum*rownum;i++)
	{
		bool issuc=writeHanzi(styleidx,i,m_curhanzi,rootpath,retimg,0,m_slider_var_val,m_slider_con_val);
		if(!issuc)
		{
			i--;continue;
		}
		int currow=i/rownum;
		int curcol=i%rownum;
		for(int r=currow*eachsize;r<currow*eachsize+eachsize;r++)
		{
			for(int c=curcol*eachsize;c<curcol*eachsize+eachsize;c++)
			{
				showimg[r*(eachsize*rownum)+c]=255-retimg[(r-currow*eachsize)*eachsize+c-curcol*eachsize];
			}
		}
	}
	delete []retimg;
	is_start_show=true;
	Invalidate();
}


void ChwcgDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	

	UpdateData(TRUE);

    CSliderCtrl   *pSlidCtrl=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_CON);
    m_slider_con_val=pSlidCtrl->GetPos();

	pSlidCtrl=(CSliderCtrl*)GetDlgItem(IDC_SLIDER_VAR);
    m_slider_var_val=pSlidCtrl->GetPos();

    CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);

    UpdateData(FALSE);

}


void ChwcgDlg::OnSetfocusEditChar()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(1);
	m_editChar="";
	UpdateData(0);
}


void ChwcgDlg::OnSetfocusEditPart()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(1);
	m_editPart="";
	UpdateData(0);
}


void ChwcgDlg::OnSetfocusEditString()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(1);
	m_editString="";
	UpdateData(0);
}

/*
void ChwcgDlg::OnBnClickedBtnOk2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	delete []showimg;
	CDialog::OnOK(); 
	DestroyWindow();
}
*/

void ChwcgDlg::OnBnClickedBtnBatchwrite2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	batch_write(1);
}


//void ChwcgDlg::OnBnClickedBtnWriteerrorstr()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
//}


void ChwcgDlg::OnBnClickedBtnWritechistr()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
		memset(m_curstring,0,sizeof(char)*1024);
	UpdateData(TRUE); 
	if(m_editString=="")
		MessageBox(L"���������ַ���");
	else
	{
		int nn=WideCharToMultiByte(CP_OEMCP,NULL,m_editString,-1,NULL,NULL,0,NULL);
		WideCharToMultiByte(CP_OEMCP,NULL,m_editString,-1,m_curstring,nn,0,NULL);

		//sprintf(m_curhanzi,"%s",m_curChar.GetBuffer(m_curChar.GetLength()));
	}
	//srand(0);
	
	

	memset(showimg,255,sizeof(unsigned char)*eachsize*rownum*eachsize*rownum);
	for(int i=0;i<rownum;i++)
	{
		int retwid,rethei;
		//unsigned char *writeString_Eng(char *curstring,int &retwid,int &rethei,int maxcharnum,int m_slider_var_val,int m_slider_con_val)
		unsigned char *retimg=writeString_Chi(m_curstring,retwid,rethei,rownum,m_slider_var_val,m_slider_con_val);

		for(int r=i*eachsize;r<i*eachsize+rethei;r++)
		{
			for(int c=0;c<retwid;c++)
			{
				showimg[r*(eachsize*rownum)+c]=255-retimg[(r-i*eachsize)*retwid+c];
			}
		}
		delete []retimg;
	}
	
	is_start_show=true;
	Invalidate();
}


void ChwcgDlg::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	bgimg_idx++;
	bgimg_idx=bgimg_idx%153;
	Invalidate();
}


void ChwcgDlg::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	styleidx++;
}


void ChwcgDlg::OnBnClickedBtnBatchwritestr()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	 batch_write_str();
}
